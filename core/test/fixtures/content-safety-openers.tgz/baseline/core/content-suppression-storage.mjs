import { createHmac, randomUUID } from 'node:crypto';
import { installedContentLayout } from './content-safety-schema.mjs';
import { fail, identifier } from './validation.mjs';

const boundary = ns => [ns.ownerId, ns.scope, ns.projectId ?? ''];
const reasons = new Set(['user_forget', 'correction_supersession', 'purge', 'privacy_erase', 'account_erasure']);
export const suppressionEpoch = row => (BigInt(row.epoch_hi) << 32n) + BigInt(row.epoch_lo);
export function requireSuppressionTransaction(db) {
  if (!db.isTransaction) fail('storage_error');
}
export function reserveContentIdentityInside(db, ns, kind, key, incarnation = key, origin = 'writer') {
  requireSuppressionTransaction(db);
  const values = [...boundary(ns), kind, key, incarnation];
  const previous = db.prepare(`SELECT incarnation FROM content_identity_reservations
    WHERE owner_id=? AND scope=? AND project_id=? AND kind=? AND stable_key=?`).get(...values.slice(0, 5));
  if (previous) {
    if (previous.incarnation !== incarnation) fail('unsupported_database');
    return;
  }
  db.prepare('INSERT INTO content_identity_reservations VALUES(?,?,?,?,?,?,?)').run(...values, origin);
}
/** Trusted internal seam. The caller owns the canonical tombstone transaction.
 * Retried causal actions retain their original epoch and first recorded time. */
export function writeContentSuppressionInside(db, { namespace: ns, kind, key = '', matchMode = 'incarnation',
  sourceVersion = '*', messageId = '', start = 0, end = 0, reason, actionId,
  recordedAt = new Date().toISOString(), origin = 'writer' }, installing = false) {
  requireSuppressionTransaction(db);
  if (!installing && !installedContentLayout(db).suppressionRevision) return null;
  if (!reasons.has(reason)) fail('invalid_input');
  identifier(ns.ownerId); identifier(actionId);
  if (ns.scope === 'project') identifier(ns.projectId);
  if (!['owner','namespace'].includes(matchMode)) identifier(key);
  if (matchMode === 'span') {
    identifier(messageId);
    if (![start,end].every(Number.isSafeInteger) || start < 0 || end <= start) fail('invalid_input');
  }
  const incarnation = ['owner', 'namespace'].includes(matchMode) ? '' : key;
  const target = [...boundary(ns), kind, key, incarnation, matchMode, sourceVersion, messageId, start, end, reason, actionId];
  const secret = db.prepare('SELECT store_id,cursor_secret FROM store_metadata WHERE singleton=1').get();
  const factId = createHmac('sha256', Buffer.from(secret.cursor_secret, 'hex'))
    .update(JSON.stringify(['content-suppression-s2h-v1', secret.store_id, target])).digest('hex');
  const previous = db.prepare('SELECT * FROM content_suppressions WHERE owner_id=? AND fact_id=?').get(ns.ownerId, factId);
  if (previous) {
    const fields = ['owner_id','scope','project_id','kind','stable_key','incarnation','match_mode','source_version',
      'message_key','span_start','span_end','reason','action_id'];
    if (fields.some((field, i) => previous[field] !== target[i]) || previous.evidence_origin !== origin) fail('unsupported_database');
    return { factId, epoch: suppressionEpoch(previous) };
  }
  if (!['owner', 'namespace'].includes(matchMode)) {
    reserveContentIdentityInside(db, ns, kind, key, incarnation, origin);
    if (matchMode === 'span') reserveContentIdentityInside(db, ns, 'raw-message', JSON.stringify([key, messageId]), key, origin);
  }
  db.prepare(`INSERT INTO owner_suppression_epochs SELECT ?,0,0
    WHERE NOT EXISTS(SELECT 1 FROM owner_suppression_epochs WHERE owner_id=?)`).run(ns.ownerId, ns.ownerId);
  const current = db.prepare('SELECT epoch_hi,epoch_lo FROM owner_suppression_epochs WHERE owner_id=?').get(ns.ownerId);
  const epoch = suppressionEpoch(current) + 1n;
  if (epoch > 0xffffffffffffffffn) fail('storage_error');
  db.prepare(`INSERT INTO content_suppressions(owner_id,fact_id,epoch_hi,epoch_lo,scope,project_id,kind,stable_key,
    incarnation,match_mode,source_version,message_key,span_start,span_end,reason,action_id,recorded_at,evidence_origin,cleanup_status,cleanup_attempt)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',0)`).run(ns.ownerId, factId, Number(epoch >> 32n), Number(epoch & 0xffffffffn),
    ...target.slice(1, 11), reason, actionId, recordedAt, origin);
  return { factId, epoch };
}
export function suppressOwnerInside(db, { ownerId, reason, actionId, recordedAt }) {
  return writeContentSuppressionInside(db, { namespace: { ownerId, scope: 'owner', projectId: '' },
    kind: 'owner', matchMode: 'owner', reason, actionId, recordedAt });
}
export function suppressReceiptsInside(db, ns, memoryId, options, ids) {
  requireSuppressionTransaction(db);
  if (!installedContentLayout(db).suppressionRevision) return;
  const rows = db.prepare('SELECT id FROM receipts WHERE memory_id=?').all(memoryId);
  for (const row of rows) if (!ids || ids.includes(row.id)) writeContentSuppressionInside(db,
    { namespace: ns, kind: 'receipt', key: row.id, ...options });
}

// Future owner-scoped pull readers plug into the immutable facts/domain/epochs;
// content delivery uses only this internal predicate, with no wire codec/cache.
export function contentSuppressionReasonInside(db, ns, { kind, key, revision, version, messageId, start, end } = {}) {
  const layout = installedContentLayout(db);
  if (!layout.suppressionRevision) return null;
  // Three indexed target ranges; never scan unrelated owner facts per item.
  const columns = 'match_mode,source_version,reason,message_key,span_start,span_end,epoch_hi,epoch_lo';
  const facts = db.prepare(`SELECT ${columns} FROM content_suppressions INDEXED BY content_suppression_target
    WHERE (owner_id,scope,project_id,kind,stable_key,incarnation)=(?,'owner','','owner','','')
    UNION ALL SELECT ${columns} FROM content_suppressions INDEXED BY content_suppression_target
    WHERE (owner_id,scope,project_id,kind,stable_key,incarnation)=(?,?,?,'namespace','','')
    UNION ALL SELECT ${columns} FROM content_suppressions INDEXED BY content_suppression_target
    WHERE (owner_id,scope,project_id,kind,stable_key,incarnation)=(?,?,?,?,?,?)
    ORDER BY epoch_hi,epoch_lo`).all(ns.ownerId, ...boundary(ns), ...boundary(ns), kind ?? '', key ?? '', key ?? '');
  for (const fact of facts) {
    if (['owner','namespace','incarnation'].includes(fact.match_mode)) return fact.reason;
    if (fact.match_mode === 'version') {
      if (version === undefined) return 'ineligible';
      const bound = JSON.parse(fact.source_version), tag = { memory: 'memory-revision-v1', 'submitted-note': 'note-v1' }[kind];
      if (tag && (bound.length !== 2 || bound[0] !== tag || !Number.isSafeInteger(bound[1]) || bound[1] < 1)) return 'ineligible';
      if (JSON.stringify(bound) === version) return fact.reason;
    }
    if (fact.match_mode === 'revision-through') {
      const bound = JSON.parse(fact.source_version);
      if (bound.length !== 2 || bound[0] !== 'memory-revision-through-v1' || !Number.isSafeInteger(bound[1]) || bound[1] < 1) fail('unsupported_database');
      if (!Number.isSafeInteger(revision)) return 'ineligible';
      if (revision <= bound[1]) return fact.reason;
    }
    if (fact.match_mode === 'span') {
      if (![fact.span_start,fact.span_end].every(Number.isSafeInteger)) return 'ineligible';
      if (messageId === fact.message_key && start < fact.span_end && end > fact.span_start) return fact.reason;
    }
  }
  if (layout.rawLineage && ['memory','receipt'].includes(kind)) {
    const ancestors = db.prepare(`SELECT DISTINCT l.conversation_id,l.message_id,l.start,l.end,c.owner_id,c.scope,c.project_id
      FROM raw_receipt_lineage l JOIN receipts r ON r.id=l.receipt_id
      LEFT JOIN raw_conversations c ON c.id=l.conversation_id WHERE ${kind === 'memory' ? 'r.memory_id' : 'r.id'}=?`).all(key);
    for (const ancestor of ancestors) {
      if (ancestor.owner_id !== ns.ownerId || ancestor.scope !== ns.scope || ancestor.project_id !== (ns.projectId ?? '')) return 'ineligible';
      const reason = contentSuppressionReasonInside(db, ns, { kind: 'raw', key: ancestor.conversation_id,
        messageId: ancestor.message_id, start: ancestor.start, end: ancestor.end });
      if (reason) return reason;
    }
  }
  return null;
}

// Allocate only against live keys and permanent referenced reservations. This
// deliberately creates no lifetime registry entry for an ordinary capture.
export function allocateContentKey(db, ns, kind) {
  const table = { memory: 'memories', receipt: 'receipts', 'submitted-note': 'card_notes', card: 'private_cards', raw: 'raw_conversations' }[kind];
  if (!table) fail('invalid_input');
  const safety = installedContentLayout(db).suppressionRevision;
  for (let attempt = 0; attempt < 32; attempt++) {
    const key = randomUUID();
    if (db.prepare(`SELECT 1 FROM ${table} WHERE id=?`).get(key)) continue;
    if (safety && db.prepare(`SELECT 1 FROM content_identity_reservations
      WHERE owner_id=? AND scope=? AND project_id=? AND kind=? AND stable_key=?`).get(...boundary(ns), kind, key)) continue;
    return key;
  }
  fail('storage_error');
}
