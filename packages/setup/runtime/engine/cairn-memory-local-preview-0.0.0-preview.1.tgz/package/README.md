# Cairn Memory local install preview

A locally installable, private npm artifact of the same public memory core and
stdio MCP host. No Cairn account is required. This archive is not published to
the npm registry; no public `npx` command or named-client compatibility is claimed.

The separate [`@cairn-ink/memory` setup helper](../packages/setup/README.md) is
prepared for a later npm release. It installs the hosted Claude Code plugin and
hooks, not this local SQLite preview. Other clients use MCP.

## Install directly from the source checkout

With Node >=22.16, npm and `tar`, run from the repository root:

Windows PowerShell users should follow the [Windows setup guide](../docs/windows-install.md),
which uses an absolute Windows target and the executable recorded in the private
receipt. The following example uses a Linux/WSL path.

```sh
npm run install:preview -- --directory /absolute/new/cairn-local --owner local-user
```

The target must not exist; its parent must already exist and have no symlink
components. Optional `--project PROJECT_ID` selects project scope. This creates
private `app/` and `data/` directories, builds the existing inspected artifact,
installs pinned dependencies from the public npm registry with lifecycle scripts
disabled, and runs the installed syntax-only configuration check. No model call
or database opening occurs. It does not modify any client configuration, shell
profile, global installation or ancestor npm project.

`installation-receipt.json` records the archive hash, installed executable,
database path, owner/project and generic `stdio.command`/`stdio.args`. Use those
settings in a local MCP client. Keys are never copied into this file. The receipt
and printed settings **do contain local paths and identity**; keep them private.
The runtime Node path is absolute; update your client settings if that Node
installation moves. Credential configuration remains a separate explicit step.

This is a fresh-install helper, not an upgrade or cleanup command. Re-running
against any existing target fails closed. If installation fails, its partial
directory is retained for inspection; choose another new path after inspecting
the failure. It does not recursively remove files. Never delete the whole target
to upgrade: preserve `data/` and backups, and operate on `app/` using the manual
upgrade instructions below. The preview trusts local process/filesystem access;
owner labels are not OS access control. POSIX permissions are not a Windows ACL
guarantee. See the [bounded native Windows check](../docs/evidence/windows-install.md);
cross-platform compatibility remains limited to recorded tests.

## Opt in to submitted source capture

For a fresh installation with the additional `capture_memory` tool, use:

```sh
npm run install:preview -- --directory /absolute/new/cairn-qualified --owner local-user --capture-qualification source-bound-v2
```

The installer also accepts `source-bound-v1`; omission keeps the eight-tool default configuration, including the three
preferred contextRead tools. See [defaults and off switches](../docs/defaults.md). The private receipt records the selected mode and includes it in
`stdio.args`. Copy the generated command and arguments unchanged into a local
MCP client. Supply `OPENAI_API_KEY` separately through that client's secret
environment for the server process; the installer never reads or stores it.
Installation and its configuration check make no model requests.

Once connected, explicitly call `capture_memory` with a batch ID and only the
messages you intend to save, for example:

```json
{"batchId":"synthetic-note-001","messages":[{"role":"user","content":"I am considering taking the train on Fridays."}]}
```

Then call `recall_memory` with source-only context selected on that call:

```json
{"query":"What did I say about Friday travel?","contextMode":"source-evidence"}
```

Use a returned memory ID with `inspect_memory` and `includeQualification: true`
to compare the retained passages against the stored model interpretation.
Source-only recall omits generated summaries and qualification labels from
ranking and returned context; it does not repair source selection or prove truth.
Without `contextMode`, this configured host retains its qualified-recall default.

Capture and semantic recall send selected text to the model provider and can
incur charges; there is no account-wide spending cap. V2 uses canonical retained
prefixes of at most 800 UTF-16 units per message and reports omitted tails in
`retainedSourceWindow`. Submitted roles are not authenticated identities, and
qualification can still misinterpret uncertainty or adoption. Reuse the same
batch ID and payload for replay; do not create fresh IDs to retry blindly.
See [capture limits](../docs/standalone-mcp.md#opt-in-submitted-source-qualified-capture)
and [source-only context boundaries](../docs/source-evidence-context.md).

This is explicit local MCP submission, not passive conversation capture, a
remote ChatGPT connector, or a claim of Hermes capture compatibility. No public
registry installation command is provided.

## Manual archive install and start

The private archive also contains an explicit Linux local capture host. Its
owner-operated profile, status/prepare/initialize/run grammar and refusal codes
are documented in [the local Raw guide](../docs/raw-local-journal.md#explicit-local-host-b4c).
This entry requires an existing schema29 store and separately recorded current
capture consent. That host entry itself does not install Claude/Codex hooks, create a
database, grant consent or configure an MCP Raw/Card review interface. The
bounded evidence uses synthetic sources and fake HTTP; no real-client activation
or semantic-quality claim follows from the archive checks.

The separate explicit `cairn-memory local` preview can initialize a brand-new
schema 29 store, prepare consent-bound installation state and activate foreground
native JSON hooks only after distinct consents and finite limits. Defaults stay
off; ordinary MCP/host startup does none of that. Inside an installed package,
read `docs/raw-local-journal.md` relative to that package's root; the guide is
included in the archive and `cairn-memory local --help` identifies the same path.
The [repository operator-guide link](../docs/raw-local-journal.md#explicit-standalone-foreground-setup-preview)
is for source-checkout readers. The guide covers the closed request, qualified
Codex prerequisite, 160-second foreground
latency, shared usage root, SQL-first disable and explicit rearm limitations.

Use Node >=22.16 and npm, with the downloaded local archive's SHA-256 verified
against its accompanying build report. Create a local installation directory,
then run there:

```sh
npm init -y
npm install --prefix . --ignore-scripts --no-audit --no-fund /absolute/path/cairn-memory-local-preview-0.0.0-preview.1.tgz
./node_modules/.bin/cairn-memory --help
./node_modules/.bin/cairn-memory --check-config --db /absolute/path/memory.sqlite --owner local-user
./node_modules/.bin/cairn-memory --db /absolute/path/memory.sqlite --owner local-user
```

Initialize the dedicated directory first and keep `--prefix .`: otherwise npm
can discover an ancestor project's package.json and install outside that directory.
The database's parent directory must already exist and be controlled by you.
Installation downloads pinned production dependencies from npm; it is not an
air-gapped install. No install lifecycle scripts or model requests are needed.
Optional `--project PROJECT_ID` binds the host to that project instead of personal
scope. The process waits for MCP JSON-RPC on stdin; stdout is protocol-only.
Configure an MCP client's local command to use that executable and those args.
This does not certify a specific named client or remote connector.

For the ordinary arguments above, `--check-config` must be the first argument.
It checks argument and key syntax,
prints a JSON report and exits without opening a database or making network
requests. It does not verify database readiness, credential validity or model
availability. Paths, owner/project IDs and keys are not printed in its report.
`--help` is standalone and needs no configuration. Neither mode starts MCP.

Without a model key, remember/inspect/correct/forget work and recall explicitly
returns `model_not_configured`. For model recall, supply `OPENAI_API_KEY` through
the host process environment or a secret manager, never command arguments or
committed configuration. Selected data is sent to OpenAI and may incur charges;
this host does not impose an account-wide spending cap. Memory storage is local,
but model recall is not offline. MCP does not capture conversations automatically.
The recall adapter uses the pinned default model `gpt-4.1-mini-2025-04-14`.
Explicit remember bypasses model extraction. The experimental extraction profile
is only a programmatic adapter option, not a CLI switch or a recall quality promise.

## Keyless retained Raw inspection and authored Cards

The same private archive has a separate Linux/WSL, Node >=22.16 path for an
already existing compatible schema 29 store. It is not the capture host above
or an installer-generated profile; it grants no capture consent, provider access,
permission change or quota reconfiguration. Keep the database outside `app/`.

Create the exact owner-selected profile described in the
[retained Raw/TTY walkthrough](../docs/private-card-terminal-review.md#retained-raw-profile):
own-UID regular profile/database files 0600 and immediate directories 0700,
canonical host ancestors, exact store ID obtained from trusted already-opened
host/SDK inspection, and an existing namespace. No store ID guessing or migration
for discovery is supported. Then configure the installed executable:

```sh
./node_modules/.bin/cairn-memory --check-config --retained-raw-profile /absolute/private/retained.json
./node_modules/.bin/cairn-memory --retained-raw-profile /absolute/private/retained.json
```

Do not combine this exclusive option with ordinary database/owner/model/capture
flags. Its syntax/runtime check reads no profile, database or API key. Actual
MCP negotiation validates readiness; an empty-stdin exit is not such a probe.
Default startup exposes eight tools; ordinary private Cards expose 25 with
contextRead enabled. This exclusive retained profile exposes 25 tools. Public discovery/read/resolve supplies actual Raw references
for explicit authored drafts without a fake Memory. MCP confirmation refuses;
the separate `review-card --retained-raw-profile ...` controlling-TTY command
reinspects and confirms only the exact displayed revision and bindings.

Only local-plain UTF-8 sources are decoded; gaps/skips remain visible, with no
provider fallback. A cold restart can inspect the same Card/source; deleting a
source cancels drafts and leaves confirmed text unsupported rather than erasing
that authored body. See the linked guide for exact arguments, limits and logical
deletion caveats. These offline synthetic archive checks do not establish
semantic quality, real-client activation, native macOS/Windows support or a
public registry release.

## Inspect, correct and delete

The five default tools are `remember_memory`, `recall_memory`, `inspect_memory`,
`correct_memory`, and `forget_memory`. Remember accepts content (<=600 characters)
and optional kind. Inspect without a memoryId lists metadata; inspect by memoryId
returns content, receipts and current revision. List pages use limit/cursor;
receipt pages use receiptLimit/receiptCursor. Defaults are 20; the maximum is 50.
Do not mix list and receipt controls.

Correct and forget require the inspected memoryId and expectedRevision. Reinspect
after `revision_conflict`; do not silently overwrite. Memory content and receipts
are untrusted evidence, not instructions. Receipts record the supplied assertion,
not proof of its truth. Supported secret patterns are redacted best-effort.
Forget is logical deletion; SQLite/WAL/backups may retain previous bytes.

## Backup, upgrade and uninstall

Stop every process using the selected database before making a filesystem backup.
Copy the database and any remaining `-wal`/`-shm` sidecars together into a protected
backup directory. Do not copy only a live SQLite file while a host is writing it.
Keep the backup and its path outside the npm installation directory.

For an upgrade, stop the host, make a backup, inspect the new version's migration
notes, and run the same local `npm install --prefix . --ignore-scripts --no-audit --no-fund`
command with the new archive. Restart with exactly the same `--db`, `--owner`
and optional `--project` arguments. This preview tests a same-schema package
version upgrade only; it does not promise future schema downgrades or migrations.

Uninstall with `npm uninstall --prefix . --ignore-scripts cairn-memory-local-preview` from
the installation directory after stopping the host. It does not delete the
external memory database or backups. Removing those is a separate explicit
decision; uninstall is not a secure-data-erasure operation.

## Troubleshooting and boundaries

- `cairn_mcp_start_failed`: check Node version, required --db/--owner arguments,
  writable database parent, and installed dependencies; do not paste your key.
  Use `--help` and `--check-config` first to separate syntax from runtime problems.
- `model_not_configured`: the host process has no model key; explicit tools remain usable.
- Empty list: verify the same database and exact owner/project startup identity.
- `revision_conflict`: inspect the latest revision before correcting or forgetting.
- No terminal output: normal for a stdio server waiting for a client request.

Incoming messages are capped at 64 KiB; tool output at 256 KiB. The host has no
HTTP listener, telemetry, authentication service, default-on automatic hooks, or
hosted UI. Native foreground hooks require the separate explicit `local setup`
and `local activate` consent flow; ordinary MCP startup does not install them.
Local process/database access is trusted; owner labels are not OS access control.
General semantic quality and actual named-client compatibility remain separate
gates. See THIRD_PARTY_NOTICES.md and npm-shrinkwrap.json for dependency provenance.
