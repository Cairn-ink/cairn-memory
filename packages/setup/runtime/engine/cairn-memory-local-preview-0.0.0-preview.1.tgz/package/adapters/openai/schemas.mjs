import { denseArray, identifier, revision } from '../../core/validation.mjs';
import { snapshotQualificationTextCatalog } from '../../core/qualification-text-catalog.mjs';

const string = { type: 'string' };
const integer = { type: 'integer', minimum: 0 };
const array = (items, maxItems) => ({ type: 'array', items, maxItems });
const object = (properties) => ({ type: 'object', properties,
  required: Object.keys(properties), additionalProperties: false });
const newTopic = { title: string, parentL2Ids: array(string, 3) };
const placement = { memoryId: string, parentIds: array(string, 3) };
const refs = object({ refs: array(object({ namespaceIndex: integer,
  memoryId: string, revision: { type: 'integer', minimum: 1 } }), 24) });

// This export is also the existing live guard's method allowlist. Reconcile
// qualification and checklist methods remain dynamic-only until a separately authorized guard extension exists.
export const schemas = {
  extract: object({ items: array(object({ content: { type: 'string', maxLength: 600 },
    kind: { type: 'string', enum: ['fact', 'preference', 'decision', 'instruction', 'context'] },
    confidence: { type: 'number', minimum: 0, maximum: 1 },
    sourceIndices: { ...array(integer, 4), minItems: 1 },
  }), 5) }),
  classify: object({ items: { ...array({ anyOf: [object(placement), object({ ...placement,
    newL1: { anyOf: [object(newTopic), object({ ...newTopic, newL2Title: string })] },
  })] }, 5), minItems: 1 } }),
  select: refs,
  rank: refs,
};

const invalid = () => { throw new Error('invalid_openai_request'); };
const id = (value) => { if (typeof value !== 'string' || !value.length) invalid(); return value; };
const index = (value) => { if (!Number.isSafeInteger(value) || value < 0) invalid(); return value; };
const positive = (value) => { if (!Number.isSafeInteger(value) || value < 1) invalid(); return value; };
const list = (value) => { if (!Array.isArray(value)) invalid(); return value; };
const sorted = (values) => [...new Set(values)].sort((a, b) => typeof a === 'number' ? a - b : a < b ? -1 : a > b ? 1 : 0);
const constrained = (base, values) => values.length ? { ...base, enum: sorted(values) } : { ...base };
const idArray = (values, maximum) => array(constrained(string, values), values.length ? Math.min(maximum, values.length) : 0);
const snapshotIndices = (values, maximum) => {
  const indices = list(values).map((value) => index(value?.index));
  if (indices.length > maximum || sorted(indices).length !== indices.length) invalid();
  return indices;
};
const qualificationSlot = itemIndex => `item_${itemIndex}`;
const qualificationSlots = (items, variants) => object(Object.fromEntries(
  items.map((item, position) => [qualificationSlot(item.itemIndex), variants[position]])));

// Episode schemas are separate from the exported legacy/live-guard allowlist.
// Optional fields use closed-object alternatives, so every object's properties
// remain required under the provider's strict structured-output contract.
export function episodeSchemasFor(method, input) {
  if (method === 'extract') {
    const schema = schemasFor(method, input);
    const plain = schema.properties.items.items;
    plain.properties.content.minLength = 1;
    schema.properties.items.items = { anyOf: [plain, object({ ...plain.properties,
      kind: { type: 'string', enum: ['preference', 'instruction'] },
      procedural: { type: 'boolean', enum: [true] } })] };
    return schema;
  }
  if (method === 'qualifyCandidates') {
    const schema = qualificationCandidatesInlineSchema(input);
    for (const item of input.items) {
      if (!['preference', 'instruction'].includes(item.kind)) continue;
      const name = qualificationSlot(item.itemIndex), plain = schema.properties.qualifications.properties[name];
      schema.properties.qualifications.properties[name] = { anyOf: [plain, object({ ...plain.properties,
        procedural: object({ evidenceIndices: { ...array(constrained(integer,
          item.candidates.map(candidate => candidate.candidateIndex)), 4), minItems: 1 } }) })] };
    }
    return schema;
  }
  if (method !== 'interpretEpisode') invalid();
  exactData(input, ['sources', 'classificationTarget', 'prior']);
  try { denseArray(input.sources, 1, 1552); } catch { invalid(); }
  input.sources.forEach((source, position) => {
    exactData(source, ['sourceIndex', 'role', 'text']);
    if (source.sourceIndex !== position || !['user', 'assistant'].includes(source.role) ||
        typeof source.text !== 'string' || !source.text.length || source.text.length > 800 || !source.text.isWellFormed()) invalid();
  });
  try { denseArray(input.classificationTarget, 1, 24); } catch { invalid(); }
  if (new Set(input.classificationTarget).size !== input.classificationTarget.length ||
      input.classificationTarget.some(value => index(value) >= input.sources.length)) invalid();
  if (!input.prior || typeof input.prior !== 'object' || Array.isArray(input.prior) ||
      Object.keys(input.prior).some(key => !['type', 'gist', 'outcome', 'nextStep'].includes(key))) invalid();
  const anchors = { ...array(object({ sourceIndex: { ...integer, maximum: input.sources.length - 1 },
    start: { ...integer, maximum: 799 }, end: { type: 'integer', minimum: 1, maximum: 800 } }), 4), minItems: 1 };
  const field = maximum => object({ value: { type: 'string', minLength: 1, maxLength: maximum }, anchors });
  const nullable = value => ({ anyOf: [value, { type: 'null' }] });
  const stepRef = input.prior.nextStep?.stepRef;
  if (stepRef !== undefined && stepRef !== 'prior-next-step') invalid();
  return object({ type: object({ value: { type: 'string', enum: [
    'work', 'research', 'meeting', 'diary', 'quick-one-off-question'] }, anchors }),
    language: { type: 'string', minLength: 2, maxLength: 35,
      pattern: '^(mixed|[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*)$' },
    gist: field(400), outcome: nullable(field(240)), nextStep: nullable(field(240)),
    disposition: stepRef === undefined ? { type: 'null' } : nullable(object({
      stepRef: { type: 'string', enum: [stepRef] },
      action: { type: 'string', enum: ['completed', 'cancelled', 'replaced'] }, anchors })) });
}

// Preserve the fully expanded candidate-ID schema for local validation after
// the named provider pool wire has been decoded back into this exact shape.
export function qualificationCandidatesInlineSchema(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) invalid();
  if (Object.hasOwn(input, 'inputMode')) invalid();
  const items = Array.from(list(input.items));
  if (!items.length || items.length > 5) invalid();
  const itemIndices = items.map(item => index(item?.itemIndex));
  if (sorted(itemIndices).length !== items.length) invalid();
  const allCandidateIndices = new Set();
  const variants = items.map(item => {
    const candidates = Array.from(list(item.candidates));
    if (!candidates.length) invalid();
    const candidateIndices = candidates.map(candidate => {
      const candidateIndex = index(candidate?.candidateIndex);
      if (allCandidateIndices.has(candidateIndex)) invalid();
      allCandidateIndices.add(candidateIndex);
      return candidateIndex;
    });
    // Core checks duplicate selections, aggregate anchor count and complete
    // item coverage. The provider schema restricts each field to this item's
    // candidates without claiming that a selected quote entails the value.
    const field = (known, unknown) => ({ anyOf: [
      object({ value: known, evidenceIndices: {
        ...array(constrained(integer, candidateIndices), 4), minItems: 1,
      } }),
      object({ value: unknown, evidenceIndices: {
        ...array(constrained(integer, candidateIndices), 4), minItems: 0,
      } }),
    ] });
    const descriptive = maximum => field({ type: 'string', minLength: 1, maxLength: maximum }, { type: 'null' });
    const categorical = values => field({ type: 'string', enum: values }, { type: 'string', enum: ['unknown'] });
    return object({ itemIndex: constrained(integer, [item.itemIndex]),
      subject: descriptive(160), property: descriptive(160),
      scope: descriptive(120), applies: descriptive(120), value: descriptive(160),
      attribution: categorical(['direct', 'reported', 'quoted', 'proposed']),
      commitment: categorical(['adopted', 'considered', 'rejected']),
    });
  });
  return object({ qualifications: qualificationSlots(items, variants) });
}

function qualificationEvidencePoolSchema(inline) {
  const evidenceSlots = minimum => ({ ...array({ type: 'integer', minimum: 0, maximum: 3 }, 4), minItems: minimum });
  const field = (known, unknown) => ({ anyOf: [
    object({ value: known, evidenceSlots: evidenceSlots(1) }),
    object({ value: unknown, evidenceSlots: evidenceSlots(0) }),
  ] });
  const descriptive = maximum => field({ type: 'string', minLength: 1, maxLength: maximum }, { type: 'null' });
  const categorical = values => field({ type: 'string', enum: values }, { type: 'string', enum: ['unknown'] });
  const definitions = { text160: descriptive(160), text120: descriptive(120),
    attribution: categorical(['direct', 'reported', 'quoted', 'proposed']),
    commitment: categorical(['adopted', 'considered', 'rejected']) };
  const slots = inline.properties.qualifications.properties;
  const entries = Object.fromEntries(Object.entries(slots).map(([name, slot]) => {
    const candidateIds = slot.properties.subject.anyOf[0].properties.evidenceIndices.items.enum;
    return [name, object({ itemIndex: slot.properties.itemIndex,
      pool: { ...array(constrained(integer, candidateIds), 4), minItems: 1 },
      subject: { $ref: '#/$defs/text160' }, property: { $ref: '#/$defs/text160' },
      scope: { $ref: '#/$defs/text120' }, applies: { $ref: '#/$defs/text120' },
      value: { $ref: '#/$defs/text160' }, attribution: { $ref: '#/$defs/attribution' },
      commitment: { $ref: '#/$defs/commitment' } })];
  }));
  return { ...object({ wireVersion: { type: 'string', enum: ['evidence-pool-v1'] },
    qualifications: object(entries) }), $defs: definitions };
}

/** Opt-in catalog schema; the ordinary schemasFor path remains guard-safe. */
export function schemasForQualificationInput(input) {
  if (!input || typeof input !== 'object' || !Object.hasOwn(input, 'inputMode')) {
    return schemasFor('qualifyCandidates', input);
  }
  try {
    const { expanded } = snapshotQualificationTextCatalog(input);
    return qualificationEvidencePoolSchema(qualificationCandidatesInlineSchema(expanded));
  } catch { invalid(); }
}

function exactData(value, fields) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(value)) ||
      Reflect.ownKeys(value).length !== fields.length) invalid();
  for (const field of fields) {
    const descriptor = Object.getOwnPropertyDescriptor(value, field);
    if (!descriptor?.enumerable || !Object.hasOwn(descriptor, 'value')) invalid();
  }
}

/** A detached indexed envelope, checked before serialization can erase bad fields. */
export function snapshotIndexedExtractInput(input) {
  exactData(input, ['inputMode', 'messages']);
  if (input.inputMode !== 'indexed-windows-v1') invalid();
  const messages = input.messages;
  try { denseArray(messages, 1, 64); } catch { invalid(); }
  if (Reflect.ownKeys(messages).length !== messages.length + 1) invalid();
  const copied = [];
  let messageIndex = -1, groupUnits = 0, totalUnits = 0, role;
  for (let position = 0; position < messages.length; position++) {
    const descriptor = Object.getOwnPropertyDescriptor(messages, String(position));
    if (!descriptor?.enumerable || !Object.hasOwn(descriptor, 'value')) invalid();
    const message = descriptor.value;
    exactData(message, ['index', 'messageIndex', 'role', 'content']);
    if (message.index !== position || !Number.isSafeInteger(message.messageIndex) ||
        message.messageIndex < 0 || message.messageIndex > 23 ||
        !['user', 'assistant'].includes(message.role) ||
        typeof message.content !== 'string' || !message.content.length ||
        !message.content.isWellFormed() || message.content.length > 800) invalid();
    if (message.messageIndex !== messageIndex) {
      if (message.messageIndex !== messageIndex + 1) invalid();
      messageIndex = message.messageIndex; groupUnits = 0; role = message.role;
    } else if (message.role !== role) invalid();
    groupUnits += message.content.length; totalUnits += message.content.length;
    if (groupUnits > 4000 || totalUnits > 20000) invalid();
    copied.push({ index: position, messageIndex, role: message.role, content: message.content });
  }
  return { inputMode: 'indexed-windows-v1', messages: copied };
}

function checklistRecord(value, fields) {
  exactData(value, fields);
}

function checklistSchema(input) {
  checklistRecord(input, ['query', 'maps', 'maxRefs']);
  if (typeof input.query !== 'string' || !input.query.trim() || !input.query.isWellFormed() ||
      input.query.length > 4000 || index(input.maxRefs) > 24) invalid();
  const rows = (value, maximum) => {
    denseArray(value, 0, maximum);
    if (Reflect.ownKeys(value).length !== value.length + 1) invalid();
    for (let i = 0; i < value.length; i++) {
      if (!Object.hasOwn(Object.getOwnPropertyDescriptor(value, String(i)), 'value')) invalid();
    }
    return value;
  };
  rows(input.maps, 2);
  const namespaces = [], memoryIds = [], revisions = [], seen = new Map();
  const label = (value, nullable = false) => {
    if (nullable && value === null) return;
    if (typeof value !== 'string' || !value.isWellFormed()) invalid();
  };
  for (const map of input.maps) {
    checklistRecord(map, ['namespaceIndex', 'items', 'exhausted']);
    if (![0, 1].includes(map.namespaceIndex) || namespaces.includes(map.namespaceIndex) ||
        typeof map.exhausted !== 'boolean') invalid();
    namespaces.push(map.namespaceIndex);
    rows(map.items, 24000);
    for (const item of map.items) {
      let memoryId, memoryRevision;
      if (item?.type === 'moc') {
        checklistRecord(item, ['type', 'moc']);
        checklistRecord(item.moc, ['id', 'level', 'title', 'revision']);
        identifier(item.moc.id); revision(item.moc.revision); label(item.moc.title, true);
        if (!['L1', 'L2'].includes(item.moc.level)) invalid();
        continue;
      }
      checklistRecord(item, ['type', 'ref', 'label']);
      label(item.label, item.type === 'ref');
      if (item.type === 'unfiled') {
        checklistRecord(item.ref, ['memoryId', 'revision']);
        memoryId = identifier(item.ref.memoryId); memoryRevision = revision(item.ref.revision);
      } else if (item.type === 'ref') {
        checklistRecord(item.ref, ['parentId', 'parentRevision', 'childType', 'childId', 'childRevision', 'relation']);
        identifier(item.ref.parentId); revision(item.ref.parentRevision);
        identifier(item.ref.childId); revision(item.ref.childRevision);
        if (!['memory', 'moc'].includes(item.ref.childType) || item.ref.relation !== 'contains') invalid();
        if (item.ref.childType === 'moc') continue;
        memoryId = item.ref.childId; memoryRevision = item.ref.childRevision;
      } else invalid();
      const key = JSON.stringify([map.namespaceIndex, memoryId]);
      if (seen.has(key) && seen.get(key) !== memoryRevision) invalid();
      seen.set(key, memoryRevision);
      memoryIds.push(memoryId); revisions.push(memoryRevision);
    }
  }
  if (Buffer.byteLength(JSON.stringify(input), 'utf8') > 24000) invalid();
  return object({ requests: array(object({ start: { ...integer, maximum: input.query.length - 1 },
    end: { ...integer, minimum: 1, maximum: input.query.length },
    refs: array(object({ namespaceIndex: constrained(integer, namespaces), memoryId: constrained(string, memoryIds),
      revision: constrained({ type: 'integer', minimum: 1 }, revisions) }), Math.min(input.maxRefs, seen.size)),
  }), 4) });
}

/** Request-scoped identifier constraints; core still validates correlated tuples. */
export function schemasFor(method, input) {
  if (method === 'selectChecklist') {
    try { return checklistSchema(input); } catch { invalid(); }
  }
  if (method === 'reviewBasis') {
    if (input && Object.hasOwn(input, 'inputMode') && !['source-context-v1', 'source-addressed-v1'].includes(input.inputMode)) invalid();
    const contextMode = input?.inputMode === 'source-context-v1';
    const addressed = input?.inputMode === 'source-addressed-v1';
    const memoryIndices = snapshotIndices(input?.memories, 6);
    if (!memoryIndices.length) invalid();
    const variants = input.memories.flatMap(memory => {
      const receipts = snapshotIndices(memory.receipts, 100);
      if (!receipts.length) invalid();
      if (addressed) return memory.receipts.map(receipt => {
        const parts = snapshotIndices(receipt.parts, 24000);
        if (!parts.length || parts.some((value, index) => value !== index)
          || receipt.parts.some(part => typeof part.text !== 'string' || !part.text.length)) invalid();
        const range = object({ startPart: { ...integer, maximum: parts.length - 1 },
          endPart: { ...integer, minimum: 1, maximum: parts.length } });
        return object({ memory: constrained(integer, [memory.index]), receipt: constrained(integer, [receipt.index]),
          ...range.properties, role: { type: 'string', enum: ['decision', 'premise', 'update', 'premise-update'] },
          context: object(Object.fromEntries(['subject', 'applies', 'scope', 'commitment']
            .map(field => [field, { anyOf: [range, { type: 'null' }] }]))) });
      });
      return object({ memory: constrained(integer, [memory.index]), receipt: constrained(integer, receipts),
        quote: { type: 'string', minLength: 1, maxLength: 200 },
        role: { type: 'string', enum: ['decision', 'premise', 'update'] },
        ...(contextMode ? { context: object(Object.fromEntries(
          ['subject', 'applies', 'scope', 'commitment'].map(field => [field,
            { anyOf: [{ type: 'string', minLength: 1, maxLength: 200 }, { type: 'null' }] }]))) } : {}) });
    });
    return object({ units: array({ anyOf: variants }, 8),
      links: array(object({ from: { ...integer, maximum: 7 }, to: { ...integer, maximum: 7 },
        relation: { type: 'string', enum: ['supports-decision', 'challenges-current-basis'] } }), 10) });
  }
  if (method === 'relateMemories') {
    if (!input || !Array.isArray(input.facts) || input.facts.length > 5 || !Array.isArray(input.candidates) || input.candidates.length !== input.facts.length) invalid();
    const ids = input.candidates.flatMap(rows => {
      if (!Array.isArray(rows) || rows.length > 8) invalid();
      return rows.map(row => id(row?.id));
    });
    return object({ facts: array(object({
      factIndex: constrained(integer, input.facts.map((fact, index) => { if (fact.factIndex !== index || typeof fact.content !== 'string') invalid(); return index; })),
      eventTime: { anyOf: [{ type: 'string', maxLength: 40 }, { type: 'null' }] },
      edges: array(object({ candidateId: constrained(string, ids), relation: { anyOf: [{ type: 'string', enum: ['supersedes','contradicts','refines','causes'] }, { type: 'null' }] },
        confidence: { type: 'number', minimum: 0, maximum: 1 }, reason: { anyOf: [{ type: 'string', maxLength: 600 }, { type: 'null' }] } }), ids.length ? 5 : 0),
    }), input.facts.length) });
  }
  if (method === 'relate') {
    const memoryIndices = snapshotIndices(input?.memories, 6);
    if (!memoryIndices.length) invalid();
    const receiptIndices = input.memories.flatMap(memory => {
      const indices = snapshotIndices(memory.receipts, 100);
      if (!indices.length) invalid();
      return indices;
    });
    // Endpoint/receipt correlation is checked by core after strict parsing.
    return object({ edges: array(object({ from: constrained(integer, memoryIndices), to: constrained(integer, memoryIndices),
      relation: { type: 'string', enum: ['supports-decision', 'challenges-premise'] },
      fromReceipt: constrained(integer, receiptIndices), toReceipt: constrained(integer, receiptIndices) }), 10) });
  }
  if (method === 'qualifyCandidates') {
    return qualificationEvidencePoolSchema(qualificationCandidatesInlineSchema(input));
  }
  if (method === 'qualify') {
    if (!input || typeof input !== 'object' || Array.isArray(input)) invalid();
    const items = list(input.items);
    if (!items.length || items.length > 5) invalid();
    const itemIndices = items.map(item => index(item?.itemIndex));
    if (sorted(itemIndices).length !== items.length) invalid();
    const nullable = maximum => ({ type: ['string', 'null'], minLength: 1, maxLength: maximum });
    const variants = items.map(item => {
      const sources = list(item.sources);
      const receiptIndices = sources.map(source => index(source?.receiptIndex));
      if (!sources.length || sources.length > 4 || sorted(receiptIndices).length !== sources.length) invalid();
      return object({ itemIndex: constrained(integer, [item.itemIndex]), qualification: object({
        version: { type: 'integer', enum: [1] },
        slot: object({ subject: nullable(160), property: nullable(160), scope: nullable(120), applies: nullable(120) }),
        value: nullable(160),
        attribution: { type: 'string', enum: ['direct', 'reported', 'quoted', 'proposed', 'unknown'] },
        commitment: { type: 'string', enum: ['adopted', 'considered', 'rejected', 'unknown'] },
        anchors: { ...array(object({ receiptIndex: constrained(integer, receiptIndices),
          start: { ...integer, maximum: 799 }, end: { type: 'integer', minimum: 1, maximum: 800 },
          text: { type: 'string', minLength: 1, maxLength: 200 },
          fields: { ...array({ type: 'string', enum: ['subject', 'property', 'scope', 'applies', 'value',
            'attribution', 'commitment'] }, 7), minItems: 1 },
        }), 4), minItems: 1 },
      }) });
    });
    return object({ qualifications: { ...array({ anyOf: variants }, items.length), minItems: items.length } });
  }
  if (method === 'reconcile') {
    if (!input || typeof input !== 'object' || Array.isArray(input)) invalid();
    const messageIndices = snapshotIndices(input.messages, 24);
    const replacementIndices = snapshotIndices(input.items, 5);
    const predecessorIndices = snapshotIndices(input.candidates, 12);
    const transitionMaximum = replacementIndices.length && messageIndices.length
      ? Math.min(5, predecessorIndices.length) : 0;
    return object({ transitions: array(object({
      relation: { type: 'string', enum: ['supersedes', 'reaffirms', 'historical_context', 'compatible', 'unresolved'] },
      valueChange: { type: 'string', enum: ['changed', 'unchanged', 'unknown'] },
      adoption: { type: 'string', enum: ['explicit', 'not_adopted', 'uncertain'] },
      replacementIndex: constrained(integer, replacementIndices),
      predecessorIndex: constrained(integer, predecessorIndices),
      evidenceIndices: { ...array(constrained(integer, messageIndices),
        Math.max(1, Math.min(4, messageIndices.length))), minItems: 1 },
    }), transitionMaximum) });
  }
  if (!Object.hasOwn(schemas, method)) invalid();
  if (method === 'extract') {
    if (!input || typeof input !== 'object' || Array.isArray(input)) invalid();
    if (Object.hasOwn(input, 'inputMode')) {
      const indexed = snapshotIndexedExtractInput(input);
      const schema = structuredClone(schemas.extract);
      schema.properties.items.items.properties.sourceIndices.items.maximum = indexed.messages.length - 1;
      return schema;
    }
    const messages = list(input.messages);
    if (messages.length > 24) invalid();
    for (let position = 0; position < messages.length; position++) {
      const message = messages[position];
      if (!Object.hasOwn(messages, position) || index(message?.index) !== position ||
          !['user', 'assistant'].includes(message.role) || typeof message.content !== 'string') invalid();
    }
    const schema = structuredClone(schemas.extract);
    if (messages.length) schema.properties.items.items.properties.sourceIndices.items.maximum = messages.length - 1;
    else schema.properties.items.maxItems = 0;
    return schema;
  }
  if (!input || typeof input !== 'object' || Array.isArray(input)) invalid();
  if (method === 'classify') {
    const memories = list(input.memories);
    if (memories.length > 5 || Object.keys(memories).length !== memories.length) invalid();
    const memoryIds = memories.map((memory) => id(memory?.id));
    if (new Set(memoryIds).size !== memoryIds.length) invalid();
    const l1 = []; const l2 = [];
    if (typeof input.mapExhausted !== 'boolean') invalid();
    for (const item of list(input.map)) {
      if (item?.type !== 'moc') continue;
      if (!['L1', 'L2'].includes(item.moc?.level)) invalid();
      (item.moc.level === 'L1' ? l1 : l2).push(id(item.moc.id));
    }
    const existing = { memoryId: constrained(string, memoryIds), parentIds: idArray(sorted(l1), 3) };
    const topic = { title: { ...string }, parentL2Ids: idArray(sorted(l2), 3) };
    const variants = [object(existing)];
    if (input.mapExhausted) variants.push(object({ ...existing,
      newL1: { anyOf: [object(topic), object({ ...topic, newL2Title: { ...string } })] } }));
    return object({ items: { ...array({ anyOf: variants }, memoryIds.length),
      minItems: memoryIds.length } });
  }
  const namespaces = []; const memoryIds = []; const revisions = [];
  let maximum;
  const candidate = (namespaceIndex, memoryId, revision) => {
    namespaces.push(index(namespaceIndex)); memoryIds.push(id(memoryId)); revisions.push(positive(revision));
  };
  if (method === 'select') {
    maximum = index(input.maxRefs);
    if (maximum > 24) invalid();
    for (const map of list(input.maps)) {
      namespaces.push(index(map?.namespaceIndex));
      for (const item of list(map.items)) {
        if (item?.type === 'unfiled') candidate(map.namespaceIndex, item.ref?.memoryId, item.ref?.revision);
        else if (item?.type === 'ref' && item.ref?.childType === 'memory') {
          candidate(map.namespaceIndex, item.ref.childId, item.ref.childRevision);
        }
      }
    }
  } else {
    maximum = positive(input.limit);
    if (maximum > 24) invalid();
    for (const item of list(input.candidates)) candidate(item?.namespaceIndex, item?.memory?.id, item?.memory?.revision);
  }
  return object({ refs: array(object({ namespaceIndex: constrained(integer, namespaces),
    memoryId: constrained(string, memoryIds), revision: constrained({ type: 'integer', minimum: 1 }, revisions) }),
  memoryIds.length ? Math.min(maximum, memoryIds.length) : 0) });
}
