import { constants,openSync,closeSync } from 'node:fs';
import { isAbsolute,dirname,basename,extname } from 'node:path';
import { PATH_FLAGS,fdPath,sameFile,inspectFile,methodEntryName,probeMethodFileEnvironment,BINARY_MEDIA } from './method-package-files.mjs';
import { isolatedFileRead } from '../../core/isolated-file-read.mjs';
import { fail } from '../../core/validation.mjs';

/** Separate explicit input channels; descriptors and original names survive review. */
export function prepareAssetFiles() {
  probeMethodFileEnvironment();
  const fds=[],pins=[];
  const hold=fd=>{fds.push(fd);return fd;};
  const close=()=>{
    let first;
    for(const fd of fds.splice(0).reverse())try{closeSync(fd);}catch(error){first??=error;}
    if(first)throw first;
  };
  function read(path,maximum,{binary=false,json=false}={}) {
    if(typeof path!=='string'||!isAbsolute(path)||path.includes('\0'))fail('invalid_path');
    const name=methodEntryName(basename(path)),parent=hold(openSync(dirname(path),PATH_FLAGS|constants.O_DIRECTORY));
    const root=inspectFile(parent,undefined,'directory');
    const fd=hold(openSync(`${fdPath(parent)}/${name}`,PATH_FLAGS)),saved={fd,parent,name,...inspectFile(fd,root.mount,'file')};
    if(saved.stat.size>BigInt(maximum))fail('invalid_input');
    const verify=()=>{if(!sameFile(saved.stat,inspectFile(fd,root.mount,'file').stat))fail('invalid_input');};
    verify();
    const {bytes,stat}=isolatedFileRead(`/proc/${process.pid}/fd/${fd}`,maximum,{expected:saved.stat});
    if(!sameFile(saved.stat,stat))fail('invalid_input');
    verify();pins.push(saved);
    if(binary)return bytes;
    let text;try{text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);}catch{fail('invalid_input');}
    if(!json)return text;
    try{return JSON.parse(text);}catch{fail('invalid_input');}
  }
  function validate(){
    for(const saved of pins){
      if(!sameFile(saved.stat,inspectFile(saved.fd,saved.mount,'file').stat))fail('invalid_input');
      const current=openSync(`${fdPath(saved.parent)}/${saved.name}`,PATH_FLAGS);
      try{if(!sameFile(saved.stat,inspectFile(current,saved.mount,'file').stat))fail('invalid_input');}finally{closeSync(current);}
    }
  }
  return {read,validate,close};
}
export function assetMedia(path){const media=BINARY_MEDIA.get(extname(path).toLowerCase());if(!media)fail('unsupported_media');return media;}
