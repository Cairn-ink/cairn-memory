// Frozen from schemas/ by integrations/client/bundle.mjs. Do not edit.
export const HOSTED_SCHEMAS = {
  "capture-request": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/capture-request.schema.json",
    "title": "Cairn Memory capture request",
    "type": "object",
    "additionalProperties": false,
    "required": [
      "client",
      "event_id",
      "session_id",
      "messages"
    ],
    "properties": {
      "client": {
        "enum": [
          "claude-code",
          "codex"
        ]
      },
      "event_id": {
        "type": "string",
        "minLength": 8,
        "maxLength": 200
      },
      "session_id": {
        "type": "string",
        "minLength": 1,
        "maxLength": 200
      },
      "project_id": {
        "type": "string",
        "minLength": 16,
        "maxLength": 128
      },
      "messages": {
        "type": "array",
        "minItems": 1,
        "maxItems": 24,
        "items": {
          "type": "object",
          "additionalProperties": false,
          "required": [
            "id",
            "role",
            "content"
          ],
          "properties": {
            "id": {
              "type": "string",
              "minLength": 1,
              "maxLength": 200
            },
            "role": {
              "enum": [
                "user",
                "assistant"
              ]
            },
            "content": {
              "type": "string",
              "minLength": 1,
              "maxLength": 20000
            },
            "occurred_at": {
              "type": "string",
              "format": "date-time",
              "maxLength": 40,
              "description": "Optional record timestamp, preserved exactly by the client."
            }
          }
        }
      },
      "sent_at": {
        "type": "string",
        "format": "date-time",
        "description": "Client clock at this send attempt; not part of event identity."
      },
      "window": {
        "$comment": "Semantic validation in hosted-contract.mjs additionally requires slice <= slices.",
        "type": "object",
        "additionalProperties": false,
        "required": [
          "id",
          "slice",
          "slices",
          "initial"
        ],
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 128
          },
          "slice": {
            "type": "integer",
            "minimum": 1,
            "maximum": 4096
          },
          "slices": {
            "type": "integer",
            "minimum": 1,
            "maximum": 4096
          },
          "initial": {
            "type": "boolean"
          }
        }
      }
    }
  },
  "capture-response": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/capture-response.schema.json",
    "title": "Cairn Memory capture response",
    "oneOf": [
      {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "duplicate",
          "memoryCount"
        ],
        "properties": {
          "duplicate": {
            "type": "boolean"
          },
          "processing": {
            "type": "boolean"
          },
          "memoryCount": {
            "type": "integer",
            "minimum": 0
          }
        }
      },
      {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "error"
        ],
        "properties": {
          "error": {
            "const": "quota_reached"
          },
          "resetAt": {
            "type": "string",
            "format": "date-time",
            "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
          }
        }
      }
    ]
  },
  "recall-request": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/recall-request.schema.json",
    "title": "Cairn Memory recall request (protocol 0.3.0)",
    "type": "object",
    "additionalProperties": false,
    "required": [
      "query"
    ],
    "properties": {
      "query": {
        "type": "string",
        "minLength": 1,
        "maxLength": 4000
      },
      "session_id": {
        "type": "string",
        "minLength": 1,
        "maxLength": 200,
        "pattern": "^[A-Za-z0-9._:-]{1,200}$",
        "description": "Optional host conversation/session id from a trusted client, never invented by a model. Use the same wire representation as capture. The server stores only an owner-scoped SHA-256 hash. Invalid or unavailable host ids are omitted by clients."
      },
      "project_id": {
        "type": "string",
        "minLength": 16,
        "maxLength": 128
      },
      "limit": {
        "type": "integer",
        "minimum": 1,
        "maximum": 12,
        "default": 6
      }
    }
  },
  "recall-response": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/recall-response.schema.json",
    "title": "Cairn Memory recall response",
    "$defs": {
      "receipt": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "client",
          "sessionId",
          "eventId",
          "role",
          "excerpt",
          "createdAt"
        ],
        "properties": {
          "client": {
            "type": "string"
          },
          "sessionId": {
            "type": "string"
          },
          "eventId": {
            "type": "string"
          },
          "role": {
            "enum": [
              "user",
              "assistant"
            ]
          },
          "excerpt": {
            "type": "string"
          },
          "createdAt": {
            "type": "string",
            "format": "date-time"
          }
        }
      },
      "memory": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "id",
          "content",
          "kind",
          "scope",
          "projectId",
          "origin",
          "confidence",
          "createdAt",
          "updatedAt",
          "receipts"
        ],
        "properties": {
          "id": {
            "type": "string",
            "format": "uuid"
          },
          "content": {
            "type": "string"
          },
          "kind": {
            "enum": [
              "fact",
              "preference",
              "decision",
              "instruction",
              "context"
            ]
          },
          "scope": {
            "enum": [
              "personal",
              "project"
            ]
          },
          "projectId": {
            "type": [
              "string",
              "null"
            ]
          },
          "origin": {
            "enum": [
              "explicit",
              "agent-inferred"
            ]
          },
          "confidence": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "createdAt": {
            "type": "string",
            "format": "date-time"
          },
          "updatedAt": {
            "type": "string",
            "format": "date-time"
          },
          "receipts": {
            "type": "array",
            "minItems": 1,
            "items": {
              "$ref": "#/$defs/receipt"
            }
          }
        }
      }
    },
    "oneOf": [
      {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "memories"
        ],
        "properties": {
          "memories": {
            "type": "array",
            "items": {
              "$ref": "#/$defs/memory"
            }
          }
        }
      },
      {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "error"
        ],
        "properties": {
          "error": {
            "const": "quota_reached"
          },
          "resetAt": {
            "type": "string",
            "format": "date-time",
            "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
          }
        }
      }
    ]
  },
  "session-start-request": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/session-start-request.schema.json",
    "title": "Cairn Memory session-start-request (protocol 0.2.0)",
    "type": "object",
    "additionalProperties": false,
    "required": [
      "version"
    ],
    "properties": {
      "version": {
        "const": 1
      },
      "project_id": {
        "type": "string",
        "minLength": 16,
        "maxLength": 128
      },
      "max_tokens": {
        "type": "integer",
        "minimum": 1,
        "maximum": 2000,
        "default": 1500
      },
      "max_chars": {
        "type": "integer",
        "minimum": 1,
        "maximum": 8000,
        "default": 6000
      }
    }
  },
  "session-start-response": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/session-start-response.schema.json",
    "title": "Cairn Memory session-start-response (protocol 0.2.0)",
    "type": "object",
    "additionalProperties": false,
    "required": [
      "version",
      "framing",
      "namespace",
      "indexRevision",
      "groups"
    ],
    "properties": {
      "version": {
        "const": 1
      },
      "framing": {
        "type": "string",
        "minLength": 1
      },
      "namespace": {
        "oneOf": [
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "ownerId",
              "scope",
              "projectId"
            ],
            "properties": {
              "ownerId": {
                "type": "string",
                "minLength": 1,
                "maxLength": 200
              },
              "scope": {
                "const": "personal"
              },
              "projectId": {
                "type": "null"
              }
            }
          },
          {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "ownerId",
              "scope",
              "projectId"
            ],
            "properties": {
              "ownerId": {
                "type": "string",
                "minLength": 1,
                "maxLength": 200
              },
              "scope": {
                "const": "project"
              },
              "projectId": {
                "type": "string",
                "minLength": 1
              }
            }
          }
        ]
      },
      "indexRevision": {
        "type": "integer",
        "minimum": 0,
        "maximum": 9007199254740991
      },
      "groups": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "nextSteps",
          "procedural",
          "background",
          "commitments"
        ],
        "properties": {
          "nextSteps": {
            "oneOf": [
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 1
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "complete"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 1,
                    "items": {
                      "$ref": "#/$defs/nextStep"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 1
                  },
                  "complete": {
                    "const": false
                  },
                  "budget_exhausted": {
                    "const": true
                  },
                  "status": {
                    "const": "budget_exhausted"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 1,
                    "items": {
                      "$ref": "#/$defs/nextStep"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": false
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 0
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "disabled"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 0,
                    "items": {
                      "$ref": "#/$defs/nextStep"
                    }
                  }
                }
              }
            ]
          },
          "procedural": {
            "oneOf": [
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "complete"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": false
                  },
                  "budget_exhausted": {
                    "const": true
                  },
                  "status": {
                    "const": "budget_exhausted"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": false
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 0
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "disabled"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 0,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              }
            ]
          },
          "background": {
            "oneOf": [
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "complete"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": false
                  },
                  "budget_exhausted": {
                    "const": true
                  },
                  "status": {
                    "const": "budget_exhausted"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": false
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 0
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "disabled"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 0,
                    "items": {
                      "$ref": "#/$defs/contextMemory"
                    }
                  }
                }
              }
            ]
          },
          "commitments": {
            "oneOf": [
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "complete"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/commitment"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": true
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 6
                  },
                  "complete": {
                    "const": false
                  },
                  "budget_exhausted": {
                    "const": true
                  },
                  "status": {
                    "const": "budget_exhausted"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 6,
                    "items": {
                      "$ref": "#/$defs/commitment"
                    }
                  }
                }
              },
              {
                "type": "object",
                "additionalProperties": false,
                "required": [
                  "enabled",
                  "returned",
                  "complete",
                  "budget_exhausted",
                  "status",
                  "items"
                ],
                "properties": {
                  "enabled": {
                    "const": false
                  },
                  "returned": {
                    "type": "integer",
                    "minimum": 0,
                    "maximum": 0
                  },
                  "complete": {
                    "const": true
                  },
                  "budget_exhausted": {
                    "const": false
                  },
                  "status": {
                    "const": "disabled"
                  },
                  "items": {
                    "type": "array",
                    "minItems": 0,
                    "maxItems": 0,
                    "items": {
                      "$ref": "#/$defs/commitment"
                    }
                  }
                }
              }
            ]
          }
        }
      }
    },
    "description": "Entire serialized success <= requested token and UTF-16 budgets, 24000 UTF-8 bytes, <=12 items overall. returned equals items.length; procedural/background enabled agree. See docs/protocol.md.",
    "$defs": {
      "nextStep": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "episodeId",
          "revision",
          "client",
          "nextStep",
          "semanticSupport",
          "sources"
        ],
        "properties": {
          "episodeId": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200
          },
          "revision": {
            "type": "integer",
            "minimum": 0,
            "maximum": 9007199254740991
          },
          "client": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200
          },
          "nextStep": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "id",
              "text",
              "status",
              "anchors",
              "receiptOrdinal"
            ],
            "properties": {
              "id": {
                "type": "string",
                "minLength": 1,
                "maxLength": 200
              },
              "text": {
                "type": "string"
              },
              "status": {
                "const": "open"
              },
              "anchors": {
                "type": "array",
                "minItems": 1,
                "items": {
                  "type": "object",
                  "additionalProperties": false,
                  "required": [
                    "sourceId",
                    "digest",
                    "start",
                    "end"
                  ],
                  "properties": {
                    "sourceId": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 200
                    },
                    "digest": {
                      "type": "string",
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "start": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 9007199254740991
                    },
                    "end": {
                      "type": "integer",
                      "minimum": 1,
                      "maximum": 9007199254740991
                    }
                  }
                }
              },
              "receiptOrdinal": {
                "type": "integer",
                "minimum": 0,
                "maximum": 9007199254740991
              }
            }
          },
          "semanticSupport": {
            "const": "unassessed"
          },
          "sources": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "object",
              "additionalProperties": false,
              "required": [
                "id",
                "digest",
                "role",
                "text",
                "truncated"
              ],
              "properties": {
                "id": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 200
                },
                "digest": {
                  "type": "string",
                  "pattern": "^[a-f0-9]{64}$"
                },
                "role": {
                  "enum": [
                    "user",
                    "assistant"
                  ]
                },
                "text": {
                  "type": "string"
                },
                "truncated": {
                  "type": "boolean"
                }
              }
            }
          }
        }
      },
      "memory": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "id",
          "revision",
          "content",
          "kind",
          "origin",
          "confidence",
          "state",
          "filingStatus",
          "createdAt",
          "updatedAt"
        ],
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200
          },
          "revision": {
            "type": "integer",
            "minimum": 0,
            "maximum": 9007199254740991
          },
          "content": {
            "type": "string"
          },
          "kind": {
            "enum": [
              "fact",
              "preference",
              "decision",
              "instruction",
              "context"
            ]
          },
          "origin": {
            "enum": [
              "explicit",
              "agent-inferred"
            ]
          },
          "confidence": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "state": {
            "const": "active"
          },
          "filingStatus": {
            "enum": [
              "filed",
              "unfiled"
            ]
          },
          "reviewState": {
            "enum": [
              "none",
              "confirmed"
            ]
          },
          "createdAt": {
            "type": "string",
            "format": "date-time",
            "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
          },
          "updatedAt": {
            "type": "string",
            "format": "date-time",
            "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
          }
        }
      },
      "contextMemory": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "memory",
          "receipts",
          "semanticSupport"
        ],
        "properties": {
          "memory": {
            "$ref": "#/$defs/memory"
          },
          "receipts": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "object",
              "additionalProperties": false,
              "required": [
                "id",
                "role",
                "excerpt"
              ],
              "properties": {
                "id": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 200
                },
                "role": {
                  "enum": [
                    "user",
                    "assistant"
                  ]
                },
                "excerpt": {
                  "type": "string"
                }
              }
            }
          },
          "procedural": {
            "type": "object",
            "additionalProperties": false,
            "required": [
              "tagRevision",
              "procedural",
              "origin",
              "anchors"
            ],
            "properties": {
              "tagRevision": {
                "type": "integer",
                "minimum": 0,
                "maximum": 9007199254740991
              },
              "procedural": {
                "type": "boolean"
              },
              "origin": {
                "anyOf": [
                  {
                    "enum": [
                      "explicit",
                      "agent-inferred"
                    ]
                  },
                  {
                    "type": "null"
                  }
                ]
              },
              "anchors": {
                "type": "array",
                "minItems": 0,
                "maxItems": 4,
                "items": {
                  "type": "object",
                  "additionalProperties": false,
                  "required": [
                    "receiptId",
                    "digest",
                    "start",
                    "end"
                  ],
                  "properties": {
                    "receiptId": {
                      "type": "string",
                      "minLength": 1,
                      "maxLength": 200
                    },
                    "digest": {
                      "type": "string",
                      "pattern": "^[a-f0-9]{64}$"
                    },
                    "start": {
                      "type": "integer",
                      "minimum": 0,
                      "maximum": 9007199254740991
                    },
                    "end": {
                      "type": "integer",
                      "minimum": 1,
                      "maximum": 9007199254740991
                    }
                  }
                }
              }
            }
          },
          "semanticSupport": {
            "const": "unassessed"
          }
        }
      },
      "commitment": {
        "type": "object",
        "additionalProperties": false,
        "required": [
          "id",
          "title",
          "dueAt",
          "collectionId",
          "acceptedAt",
          "semanticSupport",
          "receipts"
        ],
        "properties": {
          "id": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200
          },
          "title": {
            "type": "string"
          },
          "dueAt": {
            "anyOf": [
              {
                "type": "string",
                "format": "date-time",
                "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
              },
              {
                "type": "null"
              }
            ]
          },
          "collectionId": {
            "type": "string",
            "minLength": 1,
            "maxLength": 200
          },
          "acceptedAt": {
            "type": "string",
            "format": "date-time",
            "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
          },
          "semanticSupport": {
            "const": "unassessed"
          },
          "receipts": {
            "type": "array",
            "minItems": 1,
            "items": {
              "type": "object",
              "additionalProperties": false,
              "required": [
                "candidateId",
                "recordId",
                "recordKind",
                "recordTitle",
                "occurredAt",
                "excerpt",
                "sourceUrl"
              ],
              "properties": {
                "candidateId": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 200
                },
                "recordId": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 200
                },
                "recordKind": {
                  "type": "string",
                  "minLength": 1,
                  "maxLength": 200
                },
                "recordTitle": {
                  "type": "string"
                },
                "occurredAt": {
                  "type": "string",
                  "format": "date-time",
                  "pattern": "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}(?:\\.\\d+)?(?:Z|\\+00:00)$"
                },
                "excerpt": {
                  "type": "string"
                },
                "sourceUrl": {
                  "anyOf": [
                    {
                      "type": "string"
                    },
                    {
                      "type": "null"
                    }
                  ]
                }
              }
            }
          }
        }
      }
    }
  },
  "pause-state": {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "https://github.com/Cairn-ink/cairn-memory/schemas/pause-state.schema.json",
    "title": "Cairn Memory pause-state (protocol 0.2.0)",
    "type": "object",
    "additionalProperties": false,
    "required": [
      "paused",
      "generation",
      "enforced"
    ],
    "properties": {
      "paused": {
        "type": "boolean"
      },
      "generation": {
        "type": "integer",
        "minimum": 0,
        "maximum": 9007199254740991
      },
      "enforced": {
        "type": "boolean"
      }
    }
  }
};
