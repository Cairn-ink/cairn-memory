import { setTimeout as delay } from 'node:timers/promises';
import { markSessionStart,hasSessionStart,readSessionStartAttempt,sweepSessionStartAttempt } from './local-session-start.mjs';
import { readConfigurationSnapshot } from '../../../adapters/local/configuration.mjs';
import { localAuthorityInput } from '../../../core/local-authority-input.mjs';
import { stateLock } from '../state-lock.mjs';
import { workerOptions, workerContext, workerOperation, summary, fault } from './local-worker-input.mjs';
import { loadIdentity, bindRoot, readSession, initializeSession } from './local-worker-state.mjs';
import { runProgress } from './local-worker-progress.mjs';
import { sourceBudget, openWorkerSource, qualifySource, sourceSize, completeBoundary, cursorSource, verifyCursorSource, sourceReason } from './local-worker-source.mjs';
import { checkHostPermission } from './local-host-permission.mjs';

const hostOperations = new WeakMap();
export function trackWorkerHostOperation(options,operation,observeStart) {
  const observation = { operation,observeStart,permissionReason:null };
  hostOperations.set(options,observation);
  return observation;
}

async function sweepWithinBudget(identity,context,operation,host) {
  const margin = 3000;
  const spare = () => Math.min(operation.remaining()-2000,host?.untilCutoff() ?? Infinity)-margin;
  if (operation.signal.aborted || spare() <= 0) return;
  const controller = new AbortController();
  const signal = AbortSignal.any([operation.signal,controller.signal]);
  const allowed = () => !signal.aborted && spare() > 0;
  try {
    // Leave time for the ordinary source close, lock release and host result.
    // A read still pending when the wait ends cannot proceed to unlink.
    const limit = delay(Math.min(margin,spare()),undefined,{ signal }).catch(() => {});
    await Promise.race([limit,sweepSessionStartAttempt(identity,context,allowed)]);
  } finally { controller.abort(); }
}

export function createLocalRawWorker(value) {
  const options = workerOptions(value);
  async function execute(value, callOptions, initialize, mark = false) {
    let operation, identity, opened, cursor, bytes;
    try {
      const context = workerContext(value,options.authority.client,initialize);
      operation = workerOperation(callOptions); operation.check();
      let config;
      try { config = (await readConfigurationSnapshot(options.transport.configPath)).config; }
      catch { fault('config_invalid'); }
      operation.check();
      if (JSON.stringify(localAuthorityInput(config.authority)) !== JSON.stringify(options.authority)) fault('authority_changed');
      identity = await loadIdentity(options,context,operation);
      await bindRoot(options,identity,initialize,operation);
      const tracked = hostOperations.get(callOptions);
      const workerStopReason = () => {
        try { operation.check(); return null; } catch (error) { return error.reason; }
      };
      return await stateLock(identity.lockPath,async () => {
        let observePermission = false;
        try {
          config = (await readConfigurationSnapshot(options.transport.configPath)).config;
          if (JSON.stringify(localAuthorityInput(config.authority)) !== JSON.stringify(options.authority)) fault('authority_changed');
          // A stop that happened while acquiring the lock or rereading config
          // belongs to that earlier work, even if the next check sees it.
          observePermission = tracked?.observeStart && !tracked.operation.stopReason() && !workerStopReason();
          await checkHostPermission(config);
        } catch (error) {
          if (observePermission) tracked.permissionReason = tracked.operation.stopReason() ??
            (['cancelled','work_limit'].includes(error.reason) ? error.reason : workerStopReason());
          if (['cancelled','work_limit','authority_changed'].includes(error.reason)) throw error;
          fault(error.reason === 'capture_disabled' ? 'authority_changed':error.reason === 'store_invalid' || error.code === 'invalid_local_capture_configuration' ? 'config_invalid':'state_invalid');
        }
        if (observePermission) tracked.permissionReason = tracked.operation.stopReason();
        try { operation.check(); }
        catch (error) {
          if (observePermission) tracked.permissionReason ??= error.reason;
          throw error;
        }
        cursor = await readSession(identity,options.authority.client);
        if (mark) {
          if (options.authority.client !== 'claude-code') fault('invalid_input');
          if (!cursor) await markSessionStart(identity,context);
          return summary('ready','initialized',cursor);
        }
        let fromStart = false;
        if (!initialize && !cursor) {
          if (options.authority.client !== 'claude-code') fault('state_invalid');
          fromStart = await hasSessionStart(identity,context);
          if (!fromStart) {
            const attempt = await readSessionStartAttempt(identity,context);
            if (attempt === 'fresh') {
              await markSessionStart(identity,context);
              fromStart = true;
            } else if (attempt !== 'present') fault('state_invalid');
          }
        }
        bytes = sourceBudget(operation);
        try {
          opened = await openWorkerSource(context,operation,bytes);
          await qualifySource(options,context,opened,operation);
          if (cursor) {
            await verifyCursorSource(identity,opened,cursor); operation.check();
            if (initialize) return cursor.blockedReason ? summary('blocked',cursor.blockedReason,cursor)
              : summary('ready',cursor.selection.awaitingUserBoundary ? 'awaiting_user_boundary' : null,cursor);
            const result = await runProgress({ options,identity,context,opened,cursor,operation,bytes });
            if (options.authority.client === 'claude-code') await sweepWithinBudget(identity,context,operation,tracked?.operation);
            return result;
          }
          const size = await sourceSize(opened);
          if (context.start === 'eof' && !(await completeBoundary(opened,size))) return summary('waiting','partial_record');
          const offset = options.authority.client === 'claude-code' && (fromStart || context.start === 'beginning') ? 0 : size;
          cursor = { version:'local-raw-cursor-v1',sessionKey:identity.sessionKey,wireSessionId:identity.wireSessionId,
            authorityCommitment:identity.authorityCommitment,epoch:0,offset,issuedOrdinal:0,
            source:await cursorSource(identity,opened,offset),
            selection:options.authority.client === 'claude-code' ? { ownSkillTurn:!fromStart && context.start === 'eof',awaitingUserBoundary:!fromStart && context.start === 'eof' } : {},
            pending:null,blockedReason:null };
          operation.check(); await initializeSession(identity,cursor);
          if (fromStart) return await runProgress({ options,identity,context,opened,cursor,operation,bytes });
          return summary('ready','initialized',cursor);
        } catch (error) { fault(sourceReason(error,bytes)); }
        finally { const closing = opened; opened = undefined; await closing?.close(); }
      });
    } catch (error) {
      let reason = error.message === 'state_busy' ? 'state_busy' : error.reason ?? 'state_invalid';
      try { operation?.check(); } catch (stopped) { reason = stopped.reason; }
      return summary(reason === 'state_busy' ? 'busy' : 'blocked',reason,cursor);
    } finally {
      try { await opened?.close(); }
      finally { identity?.key.fill(0); operation?.close(); }
    }
  }
  return Object.freeze({ markStart:(context, options = {}) => execute(context,options,true,true), initialize:(context, options = {}) => execute(context,options,true),
    run:(context, options = {}) => execute(context,options,false) });
}
