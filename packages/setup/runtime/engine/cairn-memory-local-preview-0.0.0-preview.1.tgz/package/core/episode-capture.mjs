import { dispatchCommit, hasCommitDispatcher, dispatchSynchronousCommit } from './commit-dispatch.mjs';
import { setTimeout as delay } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { isStorageBusy, STORAGE_BUSY_TIMEOUT_MS } from './database.mjs';
import { isCaptureSourceBusy } from './capture-source-safety.mjs';
import { episodeSnapshot } from './episode-input.mjs';
import { captureMessages, checkExtractionFits, extractionRequest } from './capture.mjs';
import { callModel } from './model-call.mjs';
import { countTokens } from './model-budget.mjs';
import { fail, MemoryStoreError, object } from './validation.mjs';

const system = readFileSync(new URL('./prompts/interpret-episode.md', import.meta.url), 'utf8');
const promptDigest = createHash('sha256').update(system).digest('hex');
const errorCode = error => isStorageBusy(error) ? 'storage_busy'
  : error instanceof MemoryStoreError && error.code === 'model_timeout' ? 'episode_timeout'
  : error instanceof MemoryStoreError &&
    ['context_budget_exceeded', 'invalid_model_output'].includes(error.code)
    ? error.code : 'episode_failed';

/** Pack current evidence first, then newest undrafted evidence, then prior cited context. */
export function episodeRequest(model, snapshot) {
  const target = snapshot.events.find(event => event.eventId === snapshot.targetEventId);
  if (!target) fail(snapshot.missingReason ?? 'missing_evidence');
  const sources = [], refs = [], receipts = [], counts = new Map();
  let prior = {};
  const request = () => ({
    sources: sources.map((source, sourceIndex) => ({ sourceIndex, ...source })),
    classificationTarget: refs.flatMap((ref, index) =>
      ref.eventId === target.eventId ? [index] : []), prior });
  const fits = () => countTokens(model, JSON.stringify({
    system, input: request(), maxOutputTokens: 1024 })) <= 6000;
  const add = (event, message) => {
    sources.push({ role: message.role, text: message.content });
    refs.push({ eventId: event.eventId, messageId: message.id });
    receipts.push({ client: snapshot.client, sessionId: snapshot.sessionKey,
      eventId: message.id, role: message.role, excerpt: message.content });
  };
  const eligibleMessages = event => event.sourceIndices === undefined ? event.view.messages
    : event.sourceIndices.map(index => event.view.messages[index]);
  for (const message of eligibleMessages(target)) add(target, message);
  if (!sources.length) fail('source_excluded');
  if (!fits()) fail('context_budget_exceeded');
  counts.set(target.eventId, sources.length);
  for (const event of snapshot.events) {
    if (event === target) continue;
    let count = 0;
    for (const message of [...eligibleMessages(event)].reverse()) {
      add(event, message);
      if (!fits()) { sources.pop(); refs.pop(); receipts.pop(); } else count++;
    }
    counts.set(event.eventId, count);
  }
  const included = new Map();
  // Newest first is equivalent to dropping the oldest prefix until whole sources fit.
  for (const source of [...snapshot.sources].reverse()) {
    sources.push({ role: source.role, text: source.text }); refs.push({ sourceId: source.id });
    receipts.push(source.receipt);
    if (!fits()) { sources.pop(); refs.pop(); receipts.pop(); break; } else included.set(source.id, refs.length - 1);
  }
  for (const field of ['type','gist','outcome','nextStep']) {
    const value = snapshot.record[field];
    const anchors = snapshot.record.anchors[field];
    if (field === 'nextStep' && value?.status !== 'open') continue;
    if (!value || !anchors?.length || anchors.some(anchor => !included.has(anchor.sourceId))) continue;
    prior[field] = { value: field === 'nextStep' ? value.text : value,
      ...(field === 'nextStep' && value.status === 'open' && !snapshot.record.editor?.nextStep?.pinned
        ? { stepRef: 'prior-next-step' } : {}),
      anchors: anchors.map(anchor => ({ sourceIndex: included.get(anchor.sourceId),
        start: anchor.start, end: anchor.end })) };
    if (!fits()) delete prior[field];
  }
  return { input: request(), refs, receipts,
    stepGuard: prior.nextStep?.stepRef ? { stepId: snapshot.record.nextStep.id, expectedRevision: snapshot.revision } : null,
    priorOmitted: (snapshot.priorSourceCount ?? snapshot.sources.length) - included.size,
    dispositions: snapshot.events.map(event => ({ eventId: event.eventId,
      omitted: event.view.messages.length - counts.get(event.eventId),
      omittedIndices: event.view.messages.flatMap((message, index) =>
        refs.some(ref => ref.eventId === event.eventId && ref.messageId === message.id)
          ? [] : [index]) })) };
}

function recordDraftFailure(runtime, ns, failure) {
  const deadline = performance.now() + Math.min(250, failure.busyTimeoutMs ?? 250);
  const written = runtime.failEpisodeDraft(ns, failure);
  if (written?.revision !== undefined) return failure.code;
  // Recovery may have finalized this token before a later attempt changed the
  // episode-wide state. Read only this attempt, within the remaining budget.
  const remaining = Math.max(0, Math.floor(deadline - performance.now()));
  return runtime.episodeDraftOutcome(ns, { episodeId: failure.episodeId,
    token: failure.token, busyTimeoutMs: remaining });
}

async function recordDraftFailureAsync(runtime, ns, failure) {
  const deadline = performance.now() + Math.min(250, failure.busyTimeoutMs ?? 250);
  const written = await dispatchCommit(runtime, () => runtime.failEpisodeDraft(ns, failure),
    undefined, { compensating: true });
  if (written?.revision !== undefined) return failure.code;
  // Recovery may have finalized this token before a later attempt changed the
  // episode-wide state. Read only this attempt, within the remaining budget.
  const remaining = Math.max(0, Math.floor(deadline - performance.now()));
  return runtime.episodeDraftOutcome(ns, { episodeId: failure.episodeId,
    token: failure.token, busyTimeoutMs: remaining });
}

async function interpret({ runtime, ns, model, episodeId, generation, writerToken,
  trigger, watermark, staging, onPendingFailure, deadline }) {
  let owned, started = false, retryable = false;
  try {
    deadline?.check();
    const claim = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.claimEpisodeDraft(ns, { episodeId, generation, writerToken,
      trigger, watermark, deferAttempt: true }, deadline), deadline) : runtime.claimEpisodeDraft(ns, { episodeId, generation, writerToken,
      trigger, watermark, deferAttempt: true }, deadline));
    if (claim.consumed) return { id: episodeId, status: 'not-run', reason: 'consumed' };
    owned = { episodeId, token: claim.token };
    if (claim.skipReason) fail(claim.skipReason);
    if (staging === 'not-staged') fail('capacity');
    const snapshot = runtime.episodeDraftSnapshot(ns, owned);
    const planned = episodeRequest(model, snapshot);
    let checks = 0;
    const output = await callModel(model, 'interpretEpisode', system, planned.input, {
      failureCode: 'episode_failed', deadline, validateFresh: () => {
        // Check the actual prepared request, not a freshly filtered replacement.
        runtime.assertCaptureSources(ns, planned.receipts);
        runtime.episodeDraftSnapshot(ns, owned);
        // callModel checks once during preparation and again immediately before
        // invoking the port. Consume only at that second check, with no await.
        if (++checks === 2 && !started) {
          if (hasCommitDispatcher(runtime)) dispatchSynchronousCommit(runtime, () => {
            runtime.assertCaptureSources(ns, planned.receipts);
            runtime.episodeDraftSnapshot(ns, owned);
            return runtime.startEpisodeAttempt(ns, owned, deadline);
          }); else runtime.startEpisodeAttempt(ns, owned, deadline);
          started = true;
        }
      },
    });
    let committed;
    try {
      object(output, ['type','language','gist','outcome','nextStep','disposition']);
      let result = output;
      if (output.disposition !== null) {
        object(output.disposition, ['stepRef','action','anchors']);
        if (!planned.stepGuard || output.disposition.stepRef !== 'prior-next-step') fail('invalid_model_output');
        result = { ...output, disposition: { ...planned.stepGuard,
          action: output.disposition.action, anchors: output.disposition.anchors } };
      }
      deadline?.check();
      committed = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.commitEpisodeDraft(ns, { ...owned, result, sources: planned.refs,
        dispositions: planned.dispositions, priorOmitted: planned.priorOmitted,
        ...(trigger === 'batch' ? { classificationEventId: snapshot.targetEventId } : {}),
        modelMetadata: { adapter: null, model: null, profile: null, ...model.episodeMetadata,
          promptVersion: 'interpret-episode-v1', digest: promptDigest, portVersion: 'episode-v1' } }, deadline), deadline) : runtime.commitEpisodeDraft(ns, { ...owned, result, sources: planned.refs,
        dispositions: planned.dispositions, priorOmitted: planned.priorOmitted,
        ...(trigger === 'batch' ? { classificationEventId: snapshot.targetEventId } : {}),
        modelMetadata: { adapter: null, model: null, profile: null, ...model.episodeMetadata,
          promptVersion: 'interpret-episode-v1', digest: promptDigest, portVersion: 'episode-v1' } }, deadline));
    } catch (error) {
      if (['invalid_input', 'invalid_text', 'episode_step_conflict'].includes(error.code)) {
        fail('invalid_model_output');
      }
      throw error;
    }
    return { id: episodeId, status: 'interpreted', revision: committed.revision,
      type: output.type.value, classificationTarget: snapshot.targetEventId };
  } catch (error) {
    const code = ['capacity', 'expired', 'missing_evidence', 'generation_conflict']
      .includes(error.code) ? error.code : isCaptureSourceBusy(error) ? 'storage_busy' : errorCode(error);
    retryable = code === 'storage_busy' && !started;
    const outcome = started && code === 'storage_busy' ? 'episode_failed' : code;
    let pendingFailure = false, reportedCode = outcome;
    if (owned && !retryable) {
      pendingFailure = true;
      // One immediate write and at most 20 retries within five seconds.
      // SQLite LOCKED may return without waiting: space retries as well as
      // bounding SQLite BUSY waits, so neither code exhausts the count early.
      const deadline = performance.now() + STORAGE_BUSY_TIMEOUT_MS;
      for (let tries = 0; tries <= 20; tries++) {
        const retryAt = Math.min(deadline, performance.now() + 250);
        try {
          const failure = { ...owned, code: outcome,
            busyTimeoutMs: Math.min(250, Math.max(0, deadline - performance.now())) };
          reportedCode = hasCommitDispatcher(runtime) ? await recordDraftFailureAsync(runtime, ns, failure)
            : recordDraftFailure(runtime, ns, failure);
          pendingFailure = !reportedCode;
          break;
        } catch (failure) {
          if (!isStorageBusy(failure)) throw failure;
          if (tries === 20 || performance.now() >= deadline) break;
          await delay(Math.max(0, retryAt - performance.now()));
        }
      }
    }
    if (pendingFailure) onPendingFailure?.({ ...owned, code: outcome });
    return { id: episodeId, status: 'failed', error: pendingFailure
      ? { code: 'episode_outcome_pending', retryable: false }
      : { code: error.code === 'source_excluded' ? 'source_excluded' : reportedCode, retryable } };
  } finally {
    try { if (owned && retryable) (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.settleEpisodeAttempt(ns, { ...owned, retryable }), undefined, { compensating: true }) : runtime.settleEpisodeAttempt(ns, { ...owned, retryable })); }
    catch (error) { if (!isStorageBusy(error)) throw error; }
  }
}

async function auxiliary({ runtime, ns, model, episodeId, generation, trigger, deadline }) {
  deadline?.check();
  const state = runtime.episodeCaptureState(ns, { episodeId });
  if (!state || (state.observed <= state.attempted && !state.unfinishedAttempt)) {
    return { id: episodeId, status: 'not-run', reason: 'no-undrafted-evidence' };
  }
  const writer = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.claimEpisodeWriter(ns, { episodeId, generation }, deadline), deadline) : runtime.claimEpisodeWriter(ns, { episodeId, generation }, deadline));
  if (writer.processing) return { id: episodeId, status: 'processing' };
  try {
    // Acquiring the writer recovers expired attempts even when there is no new draft.
    if (state.observed <= state.attempted) {
      return { id: episodeId, status: 'not-run', reason: 'no-undrafted-evidence' };
    }
    return await interpret({ runtime, ns, model, episodeId, generation, writerToken: writer.token,
      trigger, watermark: state.observed, deadline });
  } finally { (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.releaseEpisodeWriter(ns, { episodeId, token: writer.token }), undefined, { compensating: true }) : runtime.releaseEpisodeWriter(ns, { episodeId, token: writer.token })); }
}

export async function endEpisode({ runtime, ns, model, input }) {
  // Validate controls even when no session/evidence exists. End IDs are host metadata only.
  const control = runtime.getCaptureControl(ns);
  if (control.generation !== input.generation) fail('generation_conflict');
  if (control.paused || !control.enabled) fail('capture_disabled');
  const state = runtime.episodeCaptureState(ns, { client: input.client, sessionId: input.sessionId });
  if (!state) return { episode: { status: 'not-run', reason: 'no-undrafted-evidence' } };
  return { episode: await auxiliary({ runtime, ns, model, episodeId: state.episodeId,
    generation: input.generation, trigger: 'end' }) };
}

export async function captureEpisodeMessages(options) {
  const { runtime, ns, model, input, startAdmission, captureQualification, captureSourcePolicy } = options;
  const sharedDeadline = options.rawRegistration ? options.deadline : undefined;
  const snapshot = episodeSnapshot(input);
  // Before staging, lazy interpretation or any claim: an oversized batch is an input error.
  checkExtractionFits(model, extractionRequest(snapshot, { captureQualification, captureSourcePolicy, episode: true }));
  const batch = { client: snapshot.client, sessionId: snapshot.sessionId, eventId: snapshot.eventId,
    payloadDigest: snapshot.payloadDigest, ...snapshot.episodeContext, view: snapshot.view,
    messages: snapshot.messages, eventStart: snapshot.eventStart, eventEnd: snapshot.eventEnd,
    eventTimeCoverage: snapshot.eventTimeCoverage };
  delete batch.origin;
  // Raw registration and the existing episode/admission reservation precede
  // every duplicate/processing return and any lazy provider work.
  let registered = options.rawRegistration
    ? (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.reserveEpisodeBatch(ns, { ...batch, acquireWriter: true }, options.rawRegistration)) : runtime.reserveEpisodeBatch(ns, { ...batch, acquireWriter: true }, options.rawRegistration)) : undefined;
  try {
    if (registered?.rawReplay) return registered.rawReplay;
    const checked = registered ?? (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.validateEpisodeBatch(ns, batch)) : runtime.validateEpisodeBatch(ns, batch));
    if (checked.processing) return { processing: true,
      episode: { status: 'processing' }, admission: { status: 'processing' } };
    if (checked.overlap) return { duplicate: true, overlap: true,
      episode: { id: checked.episodeId, status: 'not-run', reason: 'overlap' },
      admission: { status: 'covered' } };
    let lazy;
    if (!checked.duplicate) {
      const pending = runtime.pendingEpisodeSession(ns, batch);
      if (pending) lazy = await auxiliary({ runtime, ns, model, episodeId: pending,
        generation: batch.generation, trigger: 'lazy', deadline: sharedDeadline });
    }
    registered ??= (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.reserveEpisodeBatch(ns, { ...batch, acquireWriter: true })) : runtime.reserveEpisodeBatch(ns, { ...batch, acquireWriter: true }));
    const episodeId = registered.episodeId;
    if (registered.processing) return { processing: true,
      episode: { id: episodeId, status: 'processing' }, admission: { status: 'processing' } };
    if (registered.overlap) return { duplicate: true, overlap: true,
      episode: { id: episodeId, status: 'not-run', reason: 'overlap' },
      admission: { status: 'covered' } };
    if (registered.messageIds?.length) {
      snapshot.messages = snapshot.messages.filter(message => registered.messageIds.includes(message.id));
    }
    const writerToken = registered.token;
    let pendingFailure;
    const state = runtime.episodeCaptureState(ns, {
      episodeId, client: batch.client, eventId: batch.eventId });
    let episode = registered.draftProcessing ? { id: episodeId, status: 'processing' }
      : { id: episodeId, status: 'not-run', reason: registered.duplicate ? 'replay' : 'debounced' };
    const due = !state.draftConsumed && state.admission !== 'completed' && (state.attempted === 0 ||
      registered.position - state.attempted >= state.draftEvery ||
      snapshot.episodeContext.origin === 'precompact');
    if (due && writerToken) episode = await interpret({ runtime, ns, model, episodeId,
      generation: batch.generation,
      writerToken, trigger: 'batch', watermark: registered.position, staging: registered.staging,
      onPendingFailure: failure => { pendingFailure = failure; }, deadline: sharedDeadline });
    const deadline = startAdmission?.();
    const claim = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.claimAdmission(ns, { client: batch.client, eventId: batch.eventId,
      payloadDigest: batch.payloadDigest, leaseMs: 125000 }, sharedDeadline), sharedDeadline) : runtime.claimAdmission(ns, { client: batch.client, eventId: batch.eventId,
      payloadDigest: batch.payloadDigest, leaseMs: 125000 }, sharedDeadline));
    // Only the HMAC session identity can enter newly admitted receipts.
    snapshot.sessionId = registered.sessionKey;
    const result = await captureMessages({ ...options, deadline,
      episodeRun: { snapshot, claim, skip: claim.episodePolicy === 'skip-quick' } });
    if (pendingFailure && !result.processing) {
      // Admission has made progress since finalization exhausted its budget.
      // Try once more without another model call or another retry loop.
      try {
        const recorded = hasCommitDispatcher(runtime)
          ? await recordDraftFailureAsync(runtime, ns, { ...pendingFailure, busyTimeoutMs: 250 })
          : recordDraftFailure(runtime, ns, { ...pendingFailure, busyTimeoutMs: 250 });
        episode.error = { code: recorded ?? 'episode_outcome_pending', retryable: false };
      } catch (error) {
        if (!isStorageBusy(error)) throw error;
      }
    }
    return { ...result, episode, ...(lazy ? { lazyEpisode: lazy } : {}),
      ...(result.duplicate ? { admission: { status: 'completed',
        memoryIds: result.memoryIds, suppressedCount: result.suppressedCount } }
        : result.processing ? { admission: { status: 'processing' } } : {}) };
  } finally {
    if (registered?.token) (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.releaseEpisodeWriter(ns, { episodeId: registered.episodeId, token: registered.token }), undefined, { compensating: true }) : runtime.releaseEpisodeWriter(ns, { episodeId: registered.episodeId, token: registered.token }));
  }
}

export async function keepEpisodeCapture(options) {
  const { runtime, ns, keepInput, startAdmission } = options;
  const kept = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.prepareEpisodeKeep(ns, keepInput)) : runtime.prepareEpisodeKeep(ns, keepInput));
  if (kept.failure) fail(kept.failure);
  const claim = (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.claimAdmission(ns, { ...kept.key, leaseMs: 125000 })) : runtime.claimAdmission(ns, { ...kept.key, leaseMs: 125000 }));
  if (claim.duplicate || claim.processing) return { ...claim,
    episode: { id: keepInput.episodeId, policy: 'explicit-keep', sourceCoverage: kept.coverage },
    admission: { status: claim.duplicate ? 'completed' : 'processing', memoryIds: claim.memoryIds } };
  kept.admissionToken = claim.token;
  const deadline = startAdmission?.();
  const snapshot = { namespace: options.input.namespace, client: kept.client, eventId: kept.key.eventId,
    payloadDigest: kept.key.payloadDigest, sessionId: kept.sessionKey,
    messages: kept.sources.map(source =>
      ({ id: source.message_id, role: source.role, content: source.text })),
    sourceReceipts: kept.sources.map(source => ({ client: source.originClient, sessionId: source.originSessionKey })),
    captureQualification: 'source-bound-v2', sessionEpisodes: 'episode-v1' };
  const operations = { ...options.operations,
    assertCaptureEvidence: value => {
      runtime.assertEpisodeKeep(ns, kept);
      return options.operations.assertCaptureEvidence(value);
    },
    finishAdmission: value => {
      runtime.assertEpisodeKeep(ns, kept);
      // The runtime completion guard repeats the check inside the admission transaction.
      return options.operations.finishAdmission(value);
    } };
  try {
    const result = await captureMessages({ ...options, operations, deadline,
      episodeRun: { snapshot, claim, skip: false, keep: true } });
    return { ...result, episode: {
      id: keepInput.episodeId, policy: 'explicit-keep', sourceCoverage: kept.coverage } };
  } catch (error) {
    const code = error instanceof MemoryStoreError ? error.code : 'storage_error';
    try { (hasCommitDispatcher(runtime) ? await dispatchCommit(runtime, () => runtime.failEpisodeKeep(ns, kept, code), undefined, { compensating: true }) : runtime.failEpisodeKeep(ns, kept, code)); } catch { /* Preserve the original failure. */ }
    throw error;
  }
}
