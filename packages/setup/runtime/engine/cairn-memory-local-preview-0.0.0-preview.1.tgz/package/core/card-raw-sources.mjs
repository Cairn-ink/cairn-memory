import { createHash, createHmac } from 'node:crypto';
import { CARD_DEPENDENCY_LIMIT } from './private-card-schema.mjs';
import { fail } from './validation.mjs';
import { rawSourceKey } from './raw-source-input.mjs';
import { cardLineageRevision, cachedContentLayout } from './content-safety-schema.mjs';

const boundary = ns => [ns.ownerId, ns.scope, ns.projectId ?? ''];
const partKey = row => JSON.stringify([row.conversation_id,row.message_id,row.part_index]);
const columns = `conversation_id,message_id,part_index,start,end,byte_count,digest,event_id,saved,reason,format,key_version,length(sealed) AS sealed_length`;
const sameSpan = (a,b) => a.conversation_id === b.conversationId && a.message_id === b.messageId && a.start < b.span.end && a.end > b.span.start;
const mutations = new WeakMap();

/** Read-only local deletion preflight; enforcement remains in the cascade.
 * Model the outer mutation's namespace context without inserting it. Every
 * candidate query and the in-memory union stop at limit + 1 distinct Cards. */
export function checkRawCardDeletion(db, ns, conversationId, memories, fallback = []) {
  const tables = new Set(db.prepare(`SELECT name FROM sqlite_master WHERE type='table'
    AND name IN ('private_cards','card_memory_bindings','card_raw_bindings',
      'card_raw_mutation_context','card_raw_pending_invalidations')`).all().map(row => row.name));
  if (!tables.has('private_cards')) return;
  const raw = ['card_raw_bindings','card_raw_mutation_context','card_raw_pending_invalidations'].every(name => tables.has(name));
  const pending = new Set();
  const check = rows => {
    if (rows.length > CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
    return rows;
  };
  const enqueue = rows => {
    for (const row of check(rows)) {
      pending.add(row.id);
      if (pending.size > CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
    }
  };
  if (raw) {
    enqueue(db.prepare(`SELECT card_id AS id FROM card_raw_pending_invalidations LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all());
    if (conversationId) enqueue(db.prepare(`SELECT DISTINCT c.id FROM card_raw_bindings b JOIN private_cards c ON c.id=b.card_id
      WHERE c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed') AND b.conversation_id=?
      LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all(...boundary(ns),conversationId));
  }
  if (raw) for (const [id,messageId,sourceKey,whole,totalUnits] of fallback) {
    enqueue(db.prepare(`SELECT DISTINCT c.id FROM card_raw_bindings b JOIN private_cards c ON c.id=b.card_id
      WHERE c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed')
        AND b.conversation_id=? AND b.message_id=? AND ((? AND b.start<? AND b.end>0) OR EXISTS(
          SELECT 1 FROM raw_source_maps m WHERE m.conversation_id=b.conversation_id AND m.message_id=b.message_id
            AND m.source_key=? AND b.start<m.end AND b.end>m.start)) LIMIT ${CARD_DEPENDENCY_LIMIT+1}`)
      .all(...boundary(ns),id,messageId,whole,totalUnits,sourceKey));
  }
  for (const memory of memories) {
    if (raw && memory.forget) {
      // excludeMemory also collects stored receipt spans, including spans in a
      // different conversation. Legacy fallback spans are counted above too,
      // even when an episode root has no exact-key Raw conversation.
      enqueue(db.prepare(`SELECT DISTINCT c.id FROM receipts r JOIN raw_receipt_lineage l ON l.receipt_id=r.id
        JOIN card_raw_bindings b ON b.conversation_id=l.conversation_id AND b.message_id=l.message_id
          AND b.start<l.end AND b.end>l.start JOIN private_cards c ON c.id=b.card_id
        WHERE r.memory_id=? AND c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed')
        LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all(memory.id,...boundary(ns)));
    }
    if (!tables.has('card_memory_bindings')) continue;
    check(db.prepare(`SELECT DISTINCT c.id FROM private_cards c JOIN card_memory_bindings b ON b.card_id=c.id
      WHERE b.memory_id=? AND c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed')
      LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all(memory.id,...boundary(ns)));
    if (raw) enqueue(db.prepare(`SELECT DISTINCT c.id FROM card_memory_bindings b INDEXED BY card_memory_dependents
      CROSS JOIN private_cards c ON c.id=b.card_id
      WHERE b.memory_id=? AND c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed')
        AND (EXISTS(SELECT 1 FROM card_raw_mutation_context x WHERE x.owner_id=c.owner_id AND x.scope=c.scope AND x.project_id=c.project_id)
          OR NOT EXISTS(SELECT 1 FROM card_raw_mutation_context))
        AND EXISTS(SELECT 1 FROM card_raw_bindings r WHERE r.card_id=c.id)
      LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all(memory.id,...boundary(ns)));
  }
}

/** One source mutation, including nested Memory cascades, invalidates each Card once. */
export function createRawCardInvalidation(db) {
  let available;
  const enabled = () => available === true || (available = Boolean(db.prepare(
    "SELECT 1 FROM sqlite_master WHERE name='card_raw_bindings'").get()));
  function collect(ns, values) {
    if (!enabled()) return;
    const context = mutations.get(db);
    if (!context || !db.isTransaction) fail('raw_transaction_required');
    for (const value of values) {
      const rows = db.prepare(`SELECT DISTINCT c.id,c.revision FROM card_raw_bindings b JOIN private_cards c ON c.id=b.card_id
        WHERE c.owner_id=? AND c.scope=? AND c.project_id=? AND c.state IN ('draft','confirmed') AND b.conversation_id=?
        ${value.messageId ? 'AND b.message_id=? AND b.start<? AND b.end>?' : ''} ORDER BY c.id LIMIT ${CARD_DEPENDENCY_LIMIT+1}`)
        .all(...boundary(ns),value.conversationId,...(value.messageId ? [value.messageId,value.end,value.start] : []));
      if (rows.length > CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
      const queue = db.prepare('INSERT OR IGNORE INTO card_raw_pending_invalidations(card_id,revision) VALUES(?,?)');
      for (const row of rows) queue.run(row.id,row.revision);
      if (db.prepare(`SELECT card_id FROM card_raw_pending_invalidations LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all().length > CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
    }
  }
  function mutate(ns, actionId, work) {
    if (!enabled()) return work();
    if (!db.isTransaction) fail('raw_transaction_required');
    const owner = !mutations.has(db);
    if (owner) {
      db.prepare('INSERT INTO card_raw_mutation_context VALUES(1,?,?,?,?)').run(...boundary(ns),actionId);
      mutations.set(db,{ namespace: boundary(ns),actionId });
    }
    const context = mutations.get(db);
    try {
      if (JSON.stringify(context.namespace) !== JSON.stringify(boundary(ns))) fail('raw_transaction_required');
      const result = work();
      if (owner) {
        let changed = false;
        const pending = db.prepare(`SELECT card_id,revision FROM card_raw_pending_invalidations ORDER BY card_id LIMIT ${CARD_DEPENDENCY_LIMIT+1}`).all();
        if (pending.length > CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
        for (const { card_id: id,revision } of pending) {
          const row = db.prepare('SELECT state,revision FROM private_cards WHERE id=?').get(id);
          // Receipt triggers defer these Cards into the same SQL queue, so
          // every original revision produces at most one effect and update.
          if (!row || !['draft','confirmed'].includes(row.state) || row.revision !== revision) continue;
          const timestamp = new Date().toISOString();
          db.prepare(cardLineageRevision(cachedContentLayout(db)) ? 'UPDATE private_cards SET revision=revision+1,updated_at=? WHERE id=?' : `UPDATE private_cards SET revision=revision+1,updated_at=?,
            title=CASE WHEN state='draft' THEN NULL ELSE title END,body=CASE WHEN state='draft' THEN NULL ELSE body END,
            state=CASE WHEN state='draft' THEN 'cancelled' ELSE state END WHERE id=?`).run(timestamp,id);
          db.prepare(`INSERT INTO card_effects VALUES(lower(hex(randomblob(16))),?,?,?,?,?,?,?,?,
            (SELECT coalesce(max(ordinal),0)+1 FROM card_effects))`)
            .run(...boundary(ns),'evidence_invalidated','card',id,revision+1,context.actionId);
          changed = true;
        }
        if (changed) db.prepare(`INSERT INTO card_epochs VALUES(?,?,?,2) ON CONFLICT(owner_id,scope,project_id)
          DO UPDATE SET generation=generation+1`).run(...boundary(ns));
      }
      return result;
    } finally {
      if (owner) {
        mutations.delete(db);
        // Cleanup is part of the caller's write transaction too. A cleanup
        // failure must abort it rather than leave a committed suppression fence.
        if (db.isTransaction) {
          db.prepare('DELETE FROM card_raw_pending_invalidations').run();
          db.prepare('DELETE FROM card_raw_mutation_context').run();
        }
      }
    }
  }
  return { collect,mutate };
}

/** Canonical metadata only. No port, source plaintext or host callback is used. */
export function createCardRawSources(db, identity, { mutableRevision = true } = {}) {
  const bind = (purpose, value) => createHmac('sha256', identity.cursorSecret)
    .update(JSON.stringify([purpose,[identity.storeId,value]])).digest('base64url');
  let available;
  const enabled = () => available === true || (available = Boolean(db.prepare(
    "SELECT 1 FROM sqlite_master WHERE name='card_raw_bindings'").get()));
  const budget = (bytes = 64000, rows = 1024) => ({ bytes, rows, scanned: 0, used: 0, parts: new Map(), payloads: new Map() });
  function metadata(ns, anchor, state) {
    if (!enabled()) fail('source_unavailable');
    const revision = mutableRevision || anchor.expectedRevision !== undefined ? 'c.revision' : '0 AS revision';
    const row = db.prepare(`SELECT c.client,c.session_key,${revision},m.ordinal,m.role,m.occurred_at,m.total_units,m.total_bytes
      FROM raw_conversations c JOIN raw_messages m ON m.conversation_id=c.id WHERE c.owner_id=? AND c.scope=? AND c.project_id=?
      AND c.id=? AND m.message_id=?`).get(...boundary(ns), anchor.conversationId, anchor.messageId);
    if (!row || anchor.span.end > row.total_units || anchor.span.precision === 'whole-message' &&
        (anchor.span.start !== 0 || anchor.span.end !== row.total_units)) fail('source_unavailable');
    if (anchor.expectedRevision !== undefined && row.revision !== anchor.expectedRevision) fail('revision_conflict');
    if (db.prepare(`SELECT 1 FROM raw_source_exclusions WHERE conversation_id=? AND message_id=? AND start<? AND end>?`)
      .get(anchor.conversationId, anchor.messageId, anchor.span.end, anchor.span.start)) fail('source_excluded');
    return row;
  }
  function parts(anchor, state) {
    const selected = []; let next = anchor.span.start;
    while (next < anchor.span.end) {
      const cached = [...state.parts.values()].filter(part => sameSpan(part, anchor)).sort((a,b) => a.start-b.start);
      const known = cached.find(part => part.start <= next && part.end > next);
      if (known) { selected.push(known); next = known.end; continue; }
      // Seek only an uncovered interval. Extending a cached anchor left/right
      // or bridging cached islands must not scan/charge the covered rows again.
      const stop = Math.min(anchor.span.end,cached.find(part => part.start > next)?.start ?? anchor.span.end);
      const first = selected.length ? { start: next } : db.prepare(`SELECT start FROM raw_parts INDEXED BY raw_source_part_start
        WHERE conversation_id=? AND message_id=? AND start<=? ORDER BY start DESC LIMIT 1`)
        .get(anchor.conversationId, anchor.messageId, next);
      if (!first) fail('source_unavailable');
      const rows = db.prepare(`SELECT ${columns} FROM raw_parts INDEXED BY raw_source_part_start
        WHERE conversation_id=? AND message_id=? AND start>=? AND start<? ORDER BY start LIMIT ?`)
        .all(anchor.conversationId,anchor.messageId,first.start,stop,state.rows-state.scanned+1);
      if (rows.length > state.rows-state.scanned) fail('source_budget_exceeded');
      state.scanned += rows.length;
      for (const part of rows) {
        if (!part.saved || part.start > next || part.end <= next || !Number.isSafeInteger(part.byte_count) ||
            part.byte_count < 1 || part.byte_count > 16000 || part.end-part.start > 4000) fail('source_unavailable');
        const overhead = part.format === 'local-plain-v1' ? 0 : part.format === 'envelope-aes-256-gcm-v1' ? 28 : null;
        if (overhead === null || part.sealed_length !== part.byte_count+overhead) fail('raw_crypto_unavailable');
        if (state.used+part.byte_count > state.bytes) fail('source_budget_exceeded');
        state.used += part.byte_count; state.parts.set(partKey(part),part);
        selected.push(part); next = part.end;
      }
      if (next < stop) fail('source_unavailable');
    }
    return selected;
  }
  function inspect(ns, anchor, state = budget()) {
    const message = metadata(ns, anchor, state), selected = parts(anchor, state);
    const manifest = selected.map(part => {
      const key = partKey(part);
      const sealed = state.payloads.get(key) ?? db.prepare('SELECT sealed FROM raw_parts WHERE conversation_id=? AND message_id=? AND part_index=?')
        .get(part.conversation_id,part.message_id,part.part_index)?.sealed;
      if (!sealed || sealed.length !== part.sealed_length) fail('raw_crypto_unavailable');
      state.payloads.set(key,Buffer.from(sealed));
      return { ...part, fingerprint: createHash('sha256').update(sealed).digest('hex') };
    });
    const { revision, ...immutable } = message;
    return { message, parts: selected, manifest: { message: immutable, parts: manifest } };
  }
  const refFor = (ns, anchor, view) => ({ type: 'raw', namespace: { ...ns }, conversationId: anchor.conversationId,
    messageId: anchor.messageId, span: { ...anchor.span }, contentIdentity: bind('raw-source-content-v1', [ns,rawSourceKey(anchor),anchor.span.precision,view.manifest]) });
  function resolve(ns, ref, state = budget()) {
    const view = inspect(ns, ref, state);
    if (refFor(ns, ref, view).contentIdentity !== ref.contentIdentity) fail('source_unavailable');
    return view;
  }
  function checkFanout(refs, cardId) {
    for (const id of new Set(refs.filter(ref => ref.type === 'raw').map(ref => ref.conversationId))) {
      const rows = db.prepare(`SELECT DISTINCT c.id FROM card_raw_bindings b JOIN private_cards c ON c.id=b.card_id
        WHERE b.conversation_id=? AND c.state IN ('draft','confirmed') AND c.id!=? LIMIT ${CARD_DEPENDENCY_LIMIT}`).all(id,cardId);
      if (rows.length >= CARD_DEPENDENCY_LIMIT) fail('dependency_limit_reached');
    }
  }
  const bindingId = ref => bind('raw-card-binding-v1', [ref.namespace,rawSourceKey(ref)]);
  const refs = id => enabled() ? db.prepare('SELECT source_ref,position FROM card_raw_bindings WHERE card_id=?').all(id) : [];
  function put(id, refs) {
    if (!enabled()) return;
    db.prepare('DELETE FROM card_raw_bindings WHERE card_id=?').run(id);
    const insert = db.prepare('INSERT INTO card_raw_bindings VALUES(?,?,?,?,?,?,?,?)');
    refs.forEach((ref,position) => { if (ref.type === 'raw') insert.run(id,bindingId(ref),ref.conversationId,ref.messageId,
      ref.span.start,ref.span.end,JSON.stringify(ref),position); });
  }
  return { enabled, budget, inspect, refFor, resolve, checkFanout, bindingId, refs, put, bind };
}
