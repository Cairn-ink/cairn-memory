import { bindCommitRuntime, dispatchCommit, dispatchSynchronousCommit, hasCommitDispatcher, withCommitBinding } from './commit-dispatch.mjs';
import { AsyncLocalStorage } from 'node:async_hooks';
import { cardLineageItemInside, cardLineageNamespaceInside } from './card-lineage.mjs';
import { withContentSuppressionRequest, inContentSuppressionRequestInside, assertContentSuppressionRequestInside, contentSuppressionRequestInside, cachedContentSuppressionRequestInside, hasContentSuppressionRequestInside, contentSuppressionMayMatchInside, contentSuppressionReasonInside } from './content-suppression-storage.mjs';
import { contentScopeEpochGuard, assertContentScopes, contentSafetyFacade, assertContentPort, contentAuthorityPort, inertContentPortValue } from './content-safety-boundary.mjs';
import { receiptEventTimeEnabled, cachedContentLayout } from './content-safety-schema.mjs';
import { contentReadSafety, createContentReadMemo } from './content-safety.mjs';
import { digest, hasLedgerCue, ledgerNamespace, parseWindow, readIntent } from './quantity-ledger.mjs';
import { resolveContentLayout } from './content-safety-layout.mjs';
import { sampleLocalStatus } from './context-read-local-status.mjs';
import { createHash, createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { isAbsolute, resolve } from 'node:path';
import { performance } from 'node:perf_hooks';
import { validateContextProductLayout } from './context-product-schema.mjs';
import { openReadDatabase } from './read-database.mjs';
import { readTransaction, isConnectionDiscarded, isStorageBusy, busyTimeoutOption } from './database.mjs';
import { ownData } from './local-authority-input.mjs';
import { deepFreeze, withEngineCardDelivery } from './private-card-input.mjs';
import { verifyPrivateGrant } from './private-card-facade.mjs';
import { cardDependencyFence } from './card-current-storage.mjs';
import { createPrivateCardStorage } from './private-card-storage.mjs';
import { createPrivateEvidenceStorage } from './private-evidence-storage.mjs';
import { createCardReceiptSources } from './card-receipt-sources.mjs';
import { MemoryStoreError, fail } from './validation.mjs';
import { openContextReadSidecar, assertContextReadReadOnlyAuxiliaries, assertContextReadCanonicalDelete, contextSourceFences } from './context-read-sidecar.mjs';
import { createSourceContext, expandRelations, relationDiagnostic, sourceReader, sourceBudget, sourceStateBytes, validateRelationWitness, SourceStop } from './context-read-relations.mjs';
import { rankMoc, mocDiagnostic } from './context-read-moc.mjs';
import { fuseCandidates, RRF_PRESETS, COMPACT_RRF_PRESETS } from './context-read-fusion.mjs';
import { REPRESENTATION_VERSION, TOKENIZER_VERSION } from './context-read-tokenize.mjs';
import { countTokens } from './model-budget.mjs';
import { createRawSourceRoots } from './raw-source-roots.mjs';
import { DOCUMENT_CARD_CHANNEL, DOCUMENT_CARD_PRECEDENCE, documentCardPort, documentLexicalScore, documentPiece } from './document-card.mjs';
import { cosine, validateVector } from './context-read-embedder.mjs';
import { contextBudget } from './context-read-budget.mjs';
import { receiptEventDate, completeResponseBytes, cardPackSources, receiptSourceRows, resolveMemorySourceDates } from './context-read-assembly.mjs';
import { readRawChannel, citedRawTurns, assembleThreeLayerContext } from './context-read-three-layer.mjs';
import { validateSourceReceipt } from './source-evidence.mjs';
import { CONTEXT_VERSION, CONTEXT_METHODS, CONTEXT_LIMITS, SOURCE_LIMITS, ASSEMBLY_LIMITS, ASSEMBLY_POLICIES, ASSEMBLY_REPRESENTATIONS, ASSEMBLY_DEFAULTS, DEFAULT_ASSEMBLY_POLICY,
  COMPACT_MEMORY_REPRESENTATION, COMPACT_MEMORY_MAX_ITEMS, contextOptions, contextInput, assertCompactContextInput, contextRefs, namespaceKey } from './context-read-input.mjs';

const compactPresets = {
  'rrf-k60-d12': 'rrf-k60-d64-compact',
  'rrf-k60-d12-moc-v1': 'rrf-k60-d64-moc-compact',
  'rrf-k10': 'rrf-k10-d64-compact',
};

const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const bytes = envelope => Buffer.byteLength(JSON.stringify(envelope));
const success = value => ({ ok: true, value });
const states = new Set(['ready', 'unavailable', 'disabled', 'absent', 'timeout', 'provider_error', 'rate_limited',
  'budget_denied', 'stale_index', 'dimension_mismatch', 'partial_coverage', 'namespace_paused']);
const channel = (state, causes = state === 'ready' ? [] : [state]) => ({ state, causes: [...new Set(causes)] });
const maintenanceReasons = new Map([['missing', 'missing'], ['corrupt', 'corrupt'], ['wrong_store', 'wrong-store'],
  ['wrong-store', 'wrong-store'], ['incompatible', 'incompatible']]);
const knownErrors = new Set(['invalid_input', 'invalid_read_set', 'authority_required', 'scope_changed', 'invalid_cursor',
  'cursor_stale', 'revision_conflict', 'evidence_unavailable', 'invalid_snapshot', 'snapshot_stale',
  'context_item_too_large', 'token_count_unavailable', 'index_unavailable', 'storage_busy', 'storage_error', 'store_closed']);
function failure(error, details) {
  let code = isStorageBusy(error) ? 'storage_busy' : knownErrors.has(error?.code) ? error.code : 'storage_error';
  if (['invalid_identifier', 'invalid_revision', 'invalid_text'].includes(error?.code)) code = 'invalid_input';
  return { ok: false, error: { code, retryable: code === 'storage_busy', ...(details ? { details: structuredClone(details) } : {}) } };
}
function degradation(error) {
  if (['scope_changed', 'store_closed'].includes(error?.code)) throw error;
  const causes = [];
  if (error?.name === 'AbortError' || error?.code === 'timeout' || error?.reason === 'timeout') causes.push('timeout');
  if (error?.status === 429 || error?.code === 'rate_limited') causes.push('rate_limited');
  if (states.has(error?.code)) causes.push(error.code);
  if (error?.code === 'index_unavailable') causes.push('stale_index');
  if (error?.code === 'context_item_too_large') causes.push('provider_error', 'context_item_too_large');
  if (!causes.length) causes.push('provider_error');
  return channel(causes[0], causes);
}
function metadata(port) {
  if (!port) return null;
  const { id, revision, dimensions, normalization } = port;
  return { id, revision, dimensions, normalization };
}

// Hosts keep this opaque key for the connection lifetime. No key selects the
// legacy single partition; the key is not serialized into engine cursors.
const rankingPartition = new AsyncLocalStorage();
const maintenanceObservation = new AsyncLocalStorage();
// Private upkeep seam. A host retains only a fence checker for its enum view;
// ordinary reads/refreshes do not acquire or retain an observation.
export async function observeContextMaintenance(work, { host = false, previous } = {}) {
  const observation = { host, previous };
  const result = await maintenanceObservation.run(observation, work);
  return { result, current: observation.current };
}
export function withContextReadRankingPartition(key, work) {
  if (!key || typeof key !== 'object') throw TypeError('invalid_ranking_partition');
  return rankingPartition.run(key, work);
}

export function openContextCore(baseOptions, contextRead, openBase) {
  const busyTimeoutMs = busyTimeoutOption(baseOptions);
  const busyOptions = busyTimeoutMs === undefined ? {} : { busyTimeoutMs };
  const options = { ...contextOptions(contextRead), ledgerPort: baseOptions.ledgerPort, cardPort: baseOptions.cardPort };
  const readOnly = Boolean(baseOptions.existingStore);
  // Managed-existing construction uses the retained managed opener, with its
  // journal refusal performed before that opener can touch either database.
  if (readOnly) {
    const probe = openReadDatabase(baseOptions.path, { contextRead: true, ...busyOptions,
      preflight: () => assertContextReadReadOnlyAuxiliaries(baseOptions.path) });
    probe.db.close();
  }
  let context;
  const base = openBase(typeof baseOptions.model?.consolidate === 'function' && baseOptions.cardVectors === undefined ? { ...baseOptions,
    cardVectors: { read: request => context?.cardVectors(request) ?? [] },
  } : baseOptions);
  try {
    context = createContextFacade(baseOptions.path === ':memory:' ? ':memory:' : resolve(baseOptions.path), options, { readOnly, ...busyOptions });
    if (!base.maintainCards) return Object.freeze({ ...base, ...context.methods, close() { context.close(); return base.close(); } });
    const engineMethods = {
      ...Object.fromEntries(Object.keys(context.methods).map(method => [method, (...args) => context.methods[method](...args)])),
      async maintainCards(input) {
        const result = await base.maintainCards(input);
        if (result.ok && result.value.built?.length && !context.productCapabilities.types.includes('card')) {
          context.close();
          context = withCommitBinding(context, () => createContextFacade(resolve(baseOptions.path), options, { readOnly, ...busyOptions }));
        }
        return result;
      },
    };
    return withEngineCardDelivery(Object.freeze({ ...base, ...context.methods, ...engineMethods, close() { context.close(); return base.close(); } }), base);
  } catch (error) { try { base.close(); } catch { /* Preserve the initialization refusal. */ } throw error; }
}
export function openContextReader(value) {
  const input = ownData(value, ['path', 'contextRead', 'busyTimeoutMs', 'cardPort']);
  const busyTimeoutMs = busyTimeoutOption(input);
  const busyOptions = busyTimeoutMs === undefined ? {} : { busyTimeoutMs };
  if (typeof input.path !== 'string' || !isAbsolute(input.path) || input.path.includes('\0')) fail('invalid_path');
  const options = { ...contextOptions(input.contextRead), cardPort: documentCardPort(input.cardPort) };
  const context = createContextFacade(input.path, options, { readOnly: true, ...busyOptions });
  return Object.freeze({ ...context.methods, close() { context.close(); return success(null); } });
}

// Internal Worker-only entry. Legacy configuration never selects this branch.
export function openContextProductFacade(path, product) {
  const options = { family: 'local', preset: 'rrf-k60-d12', authority: null, embedder: null, counter: null,
    policy: { maxConcurrent: 1 }, budgetConfigured: false, product };
  const context = createContextFacade(path, options, { readOnly: true });
  return { fetchCandidateEvidence: context.methods.fetchCandidateEvidence, close: context.close,
    capabilities: context.productCapabilities, fileIdentity: context.fileIdentity, port: context.productPort };
}

function createContextFacade(path, options, { readOnly, ...busyOptions }) {
  let database;
  try {
    if (path !== ':memory:') database = openReadDatabase(path, { contextRead: true, ...busyOptions,
      nativeObserver: options.product?.observer,
      productSqlite: options.product?.sqlite,
      validateProduct: options.product ? validateContextProductLayout : undefined,
      preflight: () => { if (readOnly && !options.product?.sqlite) (options.product ? assertContextReadCanonicalDelete : assertContextReadReadOnlyAuxiliaries)(path, options.product?.observer); } });
    return bindCommitRuntime(initializeContextFacade(path, options, { readOnly, database }), database?.db);
  } catch (error) {
    try { if (database?.db.isOpen) database.db.close(); } catch { /* Preserve the initialization refusal. */ }
    throw error;
  }
}
function initializeContextFacade(path, options, { readOnly, database }) {
  if(options.authority)options={...options,authority:contentAuthorityPort(options.authority)};
  let closed = false;
  const defaultRankings = { rankings: new Map(), retainedSourceBytes: 0 };
  let rankingPartitions = new WeakMap();
  const rankingState = () => {
    const key = rankingPartition.getStore();
    if (!key) return defaultRankings;
    let state = rankingPartitions.get(key);
    if (!state) rankingPartitions.set(key, state = { rankings: new Map(), retainedSourceBytes: 0 });
    return state;
  };
  const controllers = new Set(), indexes = new Map(), dispatch = contextBudget(options);
  const memoryOnly = path === ':memory:';
  const guardTimeouts = new WeakSet();
  const guardAuxiliaries = () => {
    try { if (readOnly && !options.product?.sqlite) (options.product ? assertContextReadCanonicalDelete : assertContextReadReadOnlyAuxiliaries)(path, options.product?.observer); }
    catch (error) { if (options.product && error?.code === 'read_timeout') guardTimeouts.add(error); throw error; }
  };
  const facadeFailure = error => guardTimeouts.has(error)
    ? { ok: false, error: { code: 'read_timeout', retryable: false } } : failure(error);
  const db = database?.db;
  function ready() {
    if (closed || db && (!db.isOpen || isConnectionDiscarded(db))) fail('store_closed');
    if (database) { database.assertFile(); guardAuxiliaries(); }
  }
  const read = (work, acquisition) => { ready(); return acquisition ? acquisition.transaction(db, work, readTransaction) : readTransaction(db, () => inContentSuppressionRequestInside(db,work)); };
  const documentChannel = db && options.cardPort && createDocumentChannel(db, options, read, dispatch, controllers);
  const info = memoryOnly ? { storeId: null, cursorSecret: null, cards: false, raw: false } : read(() => {
    const row = db.prepare('SELECT store_id,cursor_secret FROM store_metadata WHERE singleton=1').get();
    if (!row) fail('unsupported_database');
    const has = table => Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(table));
    return { storeId: row.store_id, cursorSecret: row.cursor_secret,
      cards: (!options.product || resolveContentLayout(db.prepare('PRAGMA user_version').get().user_version).base >= 23) && has('private_cards') && has('card_memory_bindings') && has('card_applicability_reviews'), raw: has('card_raw_bindings'),
      ...(options.sources ? { organization: ['card_mocs', 'card_moc_epochs', 'card_moc_title_sources', 'card_moc_refs', 'card_moc_edges'].every(has),
        reviews: has('card_applicability_reviews'), receipts: has('card_memory_bindings') } : {}) };
  });
  const supportedTypes = ['memory', ...(info.cards ? ['card'] : [])];
  const bind = (purpose, value) => createHmac('sha256', info.cursorSecret ?? 'unavailable')
    .update(JSON.stringify([...(options.product && purpose !== 'snapshot-item' ? ['context-read-product-v1.1'] : []), CONTEXT_VERSION, purpose, info.storeId, value])).digest('base64url');
  const configuration = deepFreeze({ family: options.family, preset: options.preset, embedder: metadata(options.embedder),
    tokenizer: TOKENIZER_VERSION, representation: REPRESENTATION_VERSION,
    ...(options.sources ? { sources: options.sources } : {}) });
  function encode(purpose, value, maximum) {
    const body = Buffer.from(JSON.stringify(value)).toString('base64url'), token = `${body}.${bind(purpose, body)}`;
    if (token.length > maximum) fail('context_item_too_large');
    return token;
  }
  function decode(purpose, token, maximum, code) {
    if (typeof token !== 'string' || token.length > maximum) fail(code);
    const [body, signature, extra] = token.split('.');
    if (!body || !signature || extra !== undefined || !/^[A-Za-z0-9_-]+$/.test(body)) fail(code);
    const expected = Buffer.from(bind(purpose, body)), supplied = Buffer.from(signature);
    if (expected.length !== supplied.length || !timingSafeEqual(expected, supplied)) fail(code);
    try {
      const buffer = Buffer.from(body, 'base64url');
      if (buffer.toString('base64url') !== body) fail(code);
      return JSON.parse(buffer.toString('utf8'));
    } catch { fail(code); }
  }
  function authorize(method, input, payload, token) {
    ready();
    if (options.product) return options.product.authorize(method, payload, token);
    if (!token || typeof token !== 'object') fail('authority_required');
    const grants = input.readSet.map(namespace => {
      const request = deepFreeze({ method, namespace, actionClass: 'read', actionId: null, targetId: null,
        expectedRevision: null, payloadBinding: bind('request', [method, payload]), input: payload });
      let grant, generation;
      try {
        grant = options.authority.authorize(request, token);
        if (!grant || typeof grant !== 'object' || typeof grant.then === 'function') fail('authority_required');
        generation = verifyPrivateGrant(options.authority.isCurrent(grant, request), request);
      } catch { fail('authority_required'); }
      return { grant, request, generation };
    });
    const check = () => {
      ready();
      for (const value of grants) {
        let current;
        try { current = verifyPrivateGrant(options.authority.isCurrent(value.grant, value.request), value.request); }
        catch { fail('scope_changed'); }
        if (current !== value.generation) fail('scope_changed');
      }
    };
    check();
    return { check, accessGenerations: grants.map(value => value.generation) };
  }
  function selected(input, access) {
    return { readSet: input.readSet, types: input.types, intent: input.intent, accessGenerations: access.accessGenerations };
  }
  function acquireSidecar(projection, access) {
    access.check();
    if (memoryOnly) throw Object.assign(new MemoryStoreError('index_unavailable'), { reason: 'memory_store' });
    const key = JSON.stringify([projection.readSet, projection.types, projection.intent]);
    let entry = indexes.get(key);
    if (entry) {
      let error;
      try { entry.storage.assertFile(); } catch (failure) { error = failure; }
      if (entry.invalid || error && ['missing', 'replaced'].includes(error.reason)) {
        if (entry.users) throw error ?? new MemoryStoreError('index_unavailable');
        entry.storage.close(); indexes.delete(key); entry = undefined;
      } else if (error) throw error;
    }
    if (!entry) {
      entry = { storage: openContextReadSidecar({ path, db, readOnly, authorizedProjection: projection }), users: 0 };
      indexes.set(key, entry);
    }
    entry.users++;
    return { storage: entry.storage, invalidate(error) {
      if (error?.code === 'ERR_SQLITE_ERROR' && [1, 11, 26].includes(error.errcode & 0xff)) entry.invalid = true;
    }, release() {
      entry.users--;
      if (entry.invalid && !entry.users) { entry.storage.close(); indexes.delete(key); }
      // Active asynchronous operations retain their connection. Only idle
      // projections are evicted, so another scope cannot invalidate a request.
      for (const [id, candidate] of indexes) {
        if (indexes.size <= 8) break;
        if (!candidate.users) { candidate.storage.close(); indexes.delete(id); }
      }
    } };
  }
  function canonicalFence(readSet, types) {
    return readSet.map(ns=>{
      const proof=cachedContentSuppressionRequestInside(db,ns.ownerId);
      let memory;
      if(proof?.layout.suppressionRevision){
        const row=db.prepare(`SELECT n.epoch,coalesce(f.epoch_hi,0) epoch_hi,coalesce(f.epoch_lo,0) epoch_lo
          FROM (SELECT 1) anchor LEFT JOIN namespace_epochs n ON n.owner_id=? AND n.scope=? AND n.project_id=?
          LEFT JOIN owner_suppression_epochs f ON f.owner_id=?`).get(ns.ownerId,ns.scope,ns.projectId??'',ns.ownerId);
        if(`${row.epoch_hi}:${row.epoch_lo}`!==proof.epoch)fail('evidence_unavailable');
        memory=row.epoch??1;
      }else memory=db.prepare('SELECT epoch FROM namespace_epochs WHERE owner_id=? AND scope=? AND project_id=?')
        .get(ns.ownerId,ns.scope,ns.projectId??'')?.epoch??1;
      return {memory,...(types.includes('card')?{card:db.prepare('SELECT generation FROM card_epochs WHERE owner_id=? AND scope=? AND project_id=?')
        .get(ns.ownerId,ns.scope,ns.projectId??'')?.generation??1,...cardLineageNamespaceInside(db,ns)}:{})};
    });
  }
  function unknownCoverage(input) {
    return { status: 'unavailable', byType: Object.fromEntries((input?.types ?? supportedTypes).map(type =>
      [type, { eligible: null, indexed: null, embedded: null, scanned: null, embeddedFraction: null, scannedFraction: null }])),
    freshness: 'unverified', maintenance: { available: !readOnly && !memoryOnly, state: 'rebuilding', buildState: 'rebuilding', reason: null, progress: null },
    depths: { lexical: 0, semantic: 0 }, omitted: { lexical: null, semantic: null, horizon: null }, stops: { deadline: false, budget: false } };
  }
  function maintenanceCoverage(value, maintenance, { deadlineAt, maxItems } = {}) {
    if (maintenance) {
      value.maintenance.reason = maintenanceReasons.get(maintenance.reason) ?? null;
      value.maintenance.buildState = ['rebuilding', 'rebuilt', 'ready'].includes(maintenance.buildState) ? maintenance.buildState : 'rebuilding';
      value.maintenance.state = maintenance.status === 'complete' ? 'ready' : 'rebuilding';
      value.maintenance.progress = maintenance.progress;
    }
    value.stops.deadline ||= Boolean(maintenance?.stops?.deadline) || deadlineAt !== undefined && performance.now() >= deadlineAt;
    value.stops.budget ||= Boolean(maintenance?.stops?.budget) || maxItems !== undefined && (maintenance?.metrics.transformed ?? 0) >= maxItems;
    return value;
  }
  function coverage(input, state, preflight, mode, matched, unionSize, maintenance, semanticState,
    { preset = options.preset, horizon = CONTEXT_LIMITS.horizon } = {}) {
    const value = unknownCoverage(input); value.status = 'complete'; value.freshness = 'current';
    value.maintenance.state = 'ready'; value.maintenance.buildState = 'ready'; value.maintenance.progress = state.progress;
    maintenanceCoverage(value, maintenance ?? { ...state, status: 'complete' });
    const semanticUsed = mode === 'hybrid' && (!options.sources || semanticState === 'ready');
    for (const type of input.types) {
      const counts = state.byType[type], semantic = preflight?.byType?.[type];
      const scanned = semanticUsed ? semantic?.scanned ?? 0 : 0;
      value.byType[type] = { ...counts, embedded: semantic?.embedded ?? null, scanned,
        embeddedFraction: semantic ? counts.eligible ? semantic.embedded / counts.eligible : 1 : null,
        scannedFraction: counts.eligible ? scanned / counts.eligible : 1 };
    }
    const depth = mode === 'hybrid' ? (COMPACT_RRF_PRESETS[preset] ?? RRF_PRESETS[preset]).depth : horizon;
    value.depths = { lexical: depth, semantic: semanticUsed ? depth : 0 };
    value.omitted = { lexical: matched === null ? null : Math.max(0, matched - depth),
      semantic: semanticUsed ? Math.max(0, preflight.eligible - depth) : null, horizon: Math.max(0, unionSize - horizon) };
    return value;
  }
  function sampleTrace(value) {
    if (options.localStatus) value.localEmbedder = sampleLocalStatus(options.localStatus);
  }
  function trace(input) {
    return { requested: input.semantic ? 'hybrid' : 'lexical', effective: 'lexical', ...configuration,
      timings: { maintenanceMs: 0, lexicalMs: 0, semanticPreflightMs: 0, embeddingMs: 0, fusionMs: 0 } };
  }
  // U5c-2 retained state includes identities, witnesses, fences and diagnostics;
  // the scan corpora never enter a ranking. Oldest eviction never renews TTL.
  function dropRanking(id) {
    const state = rankingState();
    state.retainedSourceBytes -= state.rankings.get(id)?.sourceBytes ?? 0; state.rankings.delete(id);
  }
  function expireRankings() {
    for (const [id, ranking] of rankingState().rankings) if (Date.now() >= ranking.expires) dropRanking(id);
  }
  const requestBinding = input => bind('ranking-request', [input.readSet, input.query, input.types, input.intent, input.semantic, ...(options.sources ? [input.sources] : [])]);
  const accessBinding = access => bind('access', access.accessGenerations);
  const stateBinding = state => bind('index', [state.fence, state.sequence, state.checkpoint, state.incarnation]);
  function captureSources(input) {
    return input.sources?.length ? contextSourceFences(db, input.readSet, input.types, input.sources, info) : [];
  }
  function assertSourcesInside(input, sourceState, code) {
    if (sourceState && !same(captureSources(input), sourceState.fences)) fail(code);
  }
  function witnessInside(input, path, code, budget = sourceBudget(Infinity)) {
    try {
      const reader = sourceReader(db, { storeId: info.storeId, cursorSecret: info.cursorSecret }, info, input, budget);
      if (validateRelationWitness(reader, path)) fail(code);
    } catch (error) { if (error instanceof SourceStop) fail(code); throw error; }
  }
  function deliverPage(input, ranking, position, limit) {
    return read(() => {
      const result = page(ranking, position, limit);
      const safetyMemo=cachedContentLayout(db)?.suppressionRevision&&!options.sources?createContentReadMemo(db):undefined;
      for (const candidate of result.items) evidence.itemsInside(candidate.ref.namespace, [candidate.ref], input.intent, input.readSet,
        safetyMemo?{safetyMemo,batchRefs:result.items.map(candidate=>candidate.ref)}:options.sources?{legacyEvidence:true}:undefined);
      if (!options.sources) return result;
      assertSourcesInside(input, ranking.sourceState, 'cursor_stale');
      const budget = sourceBudget(Infinity);
      for (const path of ranking.sourceState.witnesses) witnessInside(input, path, 'cursor_stale', budget);
      return result;
    });
  }
  const rankingConfiguration = (trace, sourceState, items) => bind('ranking-config', [configuration, trace.requested, trace.effective,
    ...(sourceState ? [sourceState, items] : [])]);
  function page(ranking, position, limit) {
    let end = Math.min(ranking.items.length, position + limit);
    while (end > position || ranking.items.length === 0) {
      const value = { version: CONTEXT_VERSION, items: ranking.items.slice(position, end), channels: ranking.channels,
        coverage: ranking.coverage, trace: ranking.trace,
        nextCursor: end >= ranking.items.length ? null : encode('cursor', { v: 1, r: ranking.id, b: ranking.request,
          c: ranking.configuration, a: ranking.access, g: ranking.index, e: ranking.expires, p: end }, 8192) };
      if (bytes(success(value)) <= 65536) return structuredClone(value);
      end--;
    }
    fail('context_item_too_large');
  }
  function continuation(input, access) {
    if (options.localStatus) sampleLocalStatus(options.localStatus);
    const token = decode('cursor', input.cursor, 8192, 'invalid_cursor');
    try {
      ownData(token, ['v', 'r', 'b', 'c', 'a', 'g', 'e', 'p']);
      if (Object.keys(token).length !== 8 || !['r', 'b', 'c', 'a', 'g'].every(key => typeof token[key] === 'string') ||
          !Number.isSafeInteger(token.e)) fail('invalid_cursor');
    } catch { fail('invalid_cursor'); }
    if (!token || token.v !== 1 || token.b !== requestBinding(input) || !Number.isInteger(token.p) || token.p < 1 || token.p > (options.sources ? 32 : 24)) fail('invalid_cursor');
    expireRankings();
    const ranking = rankingState().rankings.get(token.r);
    if (!ranking || token.e !== ranking.expires || token.c !== ranking.configuration || token.a !== accessBinding(access) ||
        token.g !== ranking.index || token.p >= ranking.items.length || Date.now() >= token.e) fail('cursor_stale');
    if (ranking.configuration !== rankingConfiguration(ranking.trace, ranking.sourceState, ranking.items)) fail('cursor_stale');
    access.check();
    const projection = selected(input, access), lease = acquireSidecar(projection, access);
    try {
      const current = lease.storage.state(projection);
      if (!current.ready || stateBinding(current) !== ranking.index) fail('cursor_stale');
      const finalRanking = options.localStatus ? { ...ranking, trace: { ...ranking.trace, localEmbedder: sampleLocalStatus(options.localStatus) } } : ranking;
      access.check(); lease.storage.assertState(projection, current);
      return deliverPage(input, finalRanking, token.p, input.limit);
    } catch (error) { lease.invalidate(error); throw error; }
    finally { lease.release(); }
  }
  async function searchCandidates(input, access, deadlineAt, internal = false, onQueryVector) {
    let diagnostics, controller, lease, sourceState;
    try {
      const compact = input.representation === COMPACT_MEMORY_REPRESENTATION;
      const horizon = compact ? COMPACT_MEMORY_MAX_ITEMS : CONTEXT_LIMITS.horizon;
      const preset = compact ? compactPresets[options.preset] : options.preset;
      diagnostics = { channels: { lexical: channel('unavailable'), semantic: channel(input.semantic ? options.embedder ? 'unavailable' : 'absent' : 'disabled',
        !input.semantic && !options.embedder ? ['disabled', 'absent'] : undefined) }, coverage: unknownCoverage(input), trace: trace(input) };
      diagnostics.trace.preset = preset;
      sampleTrace(diagnostics.trace);
      if (options.sources) diagnostics.trace.sources = Object.fromEntries(options.sources.map(id => {
        const reason = !input.sources.includes(id) ? 'disabled' : id === 'relations-one-hop-v1' && input.intent === 'history' ? 'unsupported_intent' : 'index_unavailable';
        return [id, id === 'moc-v1' ? mocDiagnostic(reason) : relationDiagnostic(reason)];
      }));
      if (input.semantic && (!options.embedder || !dispatch)) {
        if (options.embedder) diagnostics.channels.semantic = channel('budget_denied');
        throw new MemoryStoreError('invalid_input');
      }
      const projection = selected(input, access); lease = acquireSidecar(projection, access); const storage = lease.storage;
      let maintenance;
      if (!readOnly) {
        const time = performance.now();
        const remaining = Math.floor(deadlineAt - time);
        if (remaining < 1) throw Object.assign(new MemoryStoreError('index_unavailable'), { reason: 'timeout' });
        maintenance = hasCommitDispatcher(db)
          ? await storage.reconcileAsync({ ...projection, budget: { maxItems: 1024, maxMs: remaining } }, { isCurrent: access.check })
          : storage.reconcile({ ...projection, budget: { maxItems: 1024, maxMs: remaining } }, { isCurrent: access.check });
        diagnostics.trace.timings.maintenanceMs = performance.now() - time;
        diagnostics.trace.maintenance = maintenance.metrics;
      }
      access.check();
      const current = storage.state(projection);
      diagnostics.coverage.maintenance.progress = maintenance?.progress ?? current.progress;
      maintenanceCoverage(diagnostics.coverage, maintenance, { deadlineAt, maxItems: readOnly ? undefined : 1024 });
      if (!current.ready) fail('index_unavailable');
      diagnostics.coverage = coverage(input, current, null, 'lexical', null, 0, maintenance, undefined, { preset, horizon });
      let time = performance.now();
      const lexical = storage.lexicalPage(projection, input.query, horizon, { deadlineAt });
      diagnostics.trace.timings.lexicalMs = performance.now() - time;
      diagnostics.channels.lexical = channel('ready');
      let moc = [];
      const sourceContext = options.sources ? createSourceContext() : undefined;
      if (options.sources) {
        access.check();
        const collected = read(() => {
          const fences = captureSources(input), sources = {};
          for (const id of options.sources) sources[id] = id === 'moc-v1' ? mocDiagnostic('disabled') : relationDiagnostic('disabled');
          if (input.sources.includes('moc-v1')) {
            const ranked = rankMoc(db, { storeId: info.storeId, cursorSecret: info.cursorSecret }, info, input, deadlineAt, sourceContext);
            moc = ranked.rows; sources['moc-v1'] = ranked.diagnostic;
          }
          return { fences, sources };
        });
        sourceState = { fences: collected.fences, witnesses: [] };
        diagnostics.trace.sources = collected.sources;
      }
      let preflight, semantic = [];
      if (input.semantic) {
        time = performance.now();
        try { preflight = storage.semanticPreflight(projection, options.embedder, { deadlineAt }); }
        catch (error) { diagnostics.channels.semantic = degradation(error); }
        diagnostics.trace.timings.semanticPreflightMs = performance.now() - time;
        if (preflight) diagnostics.channels.semantic = channel(preflight.state);
        // fp32 residency never crosses an await. Validate coverage/capacity
        // before paid dispatch, then refetch/revalidate synchronously to score.
        // Concurrent scopes therefore share the per-handle byte ceiling without
        // changing one another's eligibility, coverage or ranking.
        preflight?.release?.();
        if (preflight?.state === 'ready' && preflight.eligible > 0) {
          controller = new AbortController(); controllers.add(controller);
          const embeddingGuard = storage.embeddingGuard(input.readSet, deadlineAt);
          const guard = (phase = 'pre-send') => { access.check();
            if (sourceState) read(() => assertSourcesInside(input, sourceState, internal ? 'snapshot_stale' : 'cursor_stale'));
            storage.assertState(projection, current);
            embeddingGuard(phase); };
          time = performance.now();
          try {
            embeddingGuard();
            let vectors,invoked=false;
            assertContentPort({before:true});
            try { vectors = await dispatch(options.embedder, [input.query], { budgetClass: 'query', signal: controller.signal, deadlineAt, guard,onInvoke:()=>{invoked=true;} }); }
            finally { try { guard('post-send'); } finally { if(invoked)assertContentPort(); } }
            if (!Array.isArray(vectors) || vectors.length !== 1) throw Object.assign(new Error(), { code: 'provider_error' });
            const query = validateVector(vectors[0], options.embedder);
            onQueryVector?.(query);
            const scoring = storage.semanticPreflight(projection, options.embedder, { deadlineAt });
            try {
              if (scoring.state !== 'ready') { preflight = scoring; diagnostics.channels.semantic = channel(scoring.state); }
              else { semantic = scoring.score(query, { deadlineAt, limit: horizon }); preflight = scoring; }
            } finally { scoring.release?.(); }
          } catch (error) { diagnostics.channels.semantic = degradation(error); }
          diagnostics.trace.timings.embeddingMs = performance.now() - time;
        }
      }
      access.check();
      if (sourceState) read(() => assertSourcesInside(input, sourceState, internal ? 'snapshot_stale' : 'cursor_stale'));
      time = performance.now();
      const fused = fuseCandidates(lexical.rows, semantic, { preset, limit: horizon,
        semanticState: diagnostics.channels.semantic.state, coverageComplete: preflight?.state === 'ready', ...(options.sources ? { moc } : {}) });
      diagnostics.trace.timings.fusionMs = performance.now() - time; diagnostics.trace.effective = fused.mode;
      diagnostics.coverage = coverage(input, current, preflight, fused.mode, lexical.matched, fused.unionSize, maintenance,
        diagnostics.channels.semantic.state, { preset, horizon });
      diagnostics.coverage.stops = { deadline: diagnostics.channels.semantic.causes.includes('timeout'),
        budget: diagnostics.channels.semantic.causes.includes('budget_denied') };
      let candidateItems = fused.rows.map((row, i) => ({ ref: row.ref, rank: i + 1, fusionScore: row.fusionScore, channels: row.channels }));
      const proof=cachedContentSuppressionRequestInside(db,input.readSet[0].ownerId);
      const noFacts=proof?.facts?.length===0&&input.readSet.every(ns=>proof.readSet.some(selected=>
        selected.scope==='owner'||selected.scope===ns.scope&&(selected.projectId??'')===(ns.projectId??'')));
      // Final delivered evidence retains its canonical ancestry decision.
      // Only a possibly matching fact needs this additional evidence predicate,
      // and it runs inside that transaction rather than opening another one.
      storage.assertState(projection,current,{validate:()=>{
        if(cachedContentLayout(db)?.suppressionRevision&&!noFacts&&candidateItems.length){
          const safetyMemo=createContentReadMemo(db);
          candidateItems=candidateItems.filter(candidate=>{
            if(!contentSuppressionMayMatchInside(db,candidate.ref.namespace,{kind:candidate.ref.type,key:candidate.ref.memoryId??candidate.ref.cardId}))return true;
            try {evidence.itemsInside(candidate.ref.namespace,[candidate.ref],input.intent,input.readSet,{safetyMemo,batchRefs:candidateItems.map(candidate=>candidate.ref)});return true;}
            catch(error){if(['evidence_unavailable','revision_conflict'].includes(error.code))return false;throw error;}
          });
        }
      }});
      if (sourceState) {
        access.check();
        read(() => {
          assertSourcesInside(input, sourceState, internal ? 'snapshot_stale' : 'cursor_stale');
          if (input.sources.includes('relations-one-hop-v1')) {
            const expanded = expandRelations(db, { storeId: info.storeId, cursorSecret: info.cursorSecret }, info,
              { ...input, mocPreset: options.preset === 'rrf-k60-d12-moc-v1' }, candidateItems, deadlineAt, sourceContext);
            candidateItems = expanded.items.map((item, i) => ({ ...item, rank: i + 1 }));
            sourceState.witnesses = expanded.witnesses;
            diagnostics.trace.sources['relations-one-hop-v1'] = expanded.diagnostic;
          }
        });
      }
      if (sourceState) diagnostics.coverage.stops.deadline ||= Object.values(diagnostics.trace.sources).some(source => source.reasons.includes('deadline'));
      if (internal) {
        sampleTrace(diagnostics.trace);
        access.check(); storage.assertState(projection, current);
        const horizon = deepFreeze({ items: candidateItems, ...diagnostics });
        return { ok: true, horizon, ...(sourceState ? { sourceState } : {}), check() {
          access.check();
          if (sourceState) read(() => assertSourcesInside(input, sourceState, 'snapshot_stale'));
          const resumed = acquireSidecar(projection, access);
          try { resumed.storage.assertState(projection, current);
            if (sourceState) read(() => assertSourcesInside(input, sourceState, internal ? 'snapshot_stale' : 'cursor_stale')); }
          finally { resumed.release(); }
        } };
      }
      sampleTrace(diagnostics.trace);
      const ranking = deepFreeze({ id: randomUUID(), expires: Date.now() + 300000, request: requestBinding(input),
        configuration: rankingConfiguration(diagnostics.trace, sourceState, candidateItems), access: accessBinding(access),
        index: stateBinding(current), items: candidateItems,
        ...(sourceState ? { sourceState, sourceBytes: sourceStateBytes({ items: candidateItems, sourceState, sources: diagnostics.trace.sources }) } : {}),
        ...diagnostics });
      expireRankings();
      const sourceBytes = ranking.sourceBytes ?? 0;
      if (sourceBytes > SOURCE_LIMITS.retainedBytes) fail('context_item_too_large');
      // Evict before transferring request-local state into retained ownership.
      const state = rankingState();
      while (state.rankings.size >= 128 || state.retainedSourceBytes + sourceBytes > SOURCE_LIMITS.retainedBytes) dropRanking(state.rankings.keys().next().value);
      state.rankings.set(ranking.id, ranking); state.retainedSourceBytes += sourceBytes;
      access.check();
      if (sourceState) read(() => assertSourcesInside(input, sourceState, 'cursor_stale'));
      storage.assertState(projection, current);
      return success(deliverPage(input, ranking, 0, input.limit));
    } catch (error) {
      if (diagnostics && !['scope_changed', 'authority_required', 'store_closed'].includes(error.code)) sampleTrace(diagnostics.trace);
      lease?.invalidate(error);
      if (diagnostics && (error.code === 'index_unavailable' || error.reason === 'timeout')) {
        diagnostics.coverage.maintenance.reason ??= maintenanceReasons.get(error.reason) ?? null;
        diagnostics.channels.lexical = channel(error.reason === 'timeout' ? 'timeout' : 'unavailable');
        diagnostics.coverage.stops.deadline ||= error.reason === 'timeout' || performance.now() >= deadlineAt;
        return failure(new MemoryStoreError('index_unavailable'), diagnostics);
      }
      return failure(error, diagnostics && ['invalid_input', 'index_unavailable'].includes(error.code) ? diagnostics : undefined);
    } finally { lease?.release(); if (controller) { assertContentPort({invoke:()=>controller.abort()}); controllers.delete(controller); } }
  }
  async function findCandidates(original, token) {
    try {
      ready();
      const { payload, input } = contextInput('findCandidates', original, supportedTypes, options.sources);
      const deadlineAt = performance.now() + input.deadlineMs;
      const access = authorize('findCandidates', input, payload, token);
      if (input.cursor !== undefined) return success(continuation(input, access));
      return searchCandidates(input, access, deadlineAt);
    } catch (error) { return failure(error); }
  }
  async function refreshContextIndex(original, token) {
    // Coordinator 11-14 (A): preserve main's ordinary refresh statements.
    return hasCommitDispatcher(db) || maintenanceObservation.getStore()?.host
      ? refreshHostContextIndex(original, token) : refreshUnboundContextIndex(original, token);
  }
  async function refreshUnboundContextIndex(original, token) {
    let controller, diagnostics, lease, deadlineAt;
    try {
      ready();
      if (readOnly) fail('invalid_input');
      const { payload, input } = contextInput('refreshContextIndex', original, supportedTypes), access = authorize('refreshContextIndex', input, payload, token);
      diagnostics = { channels: { lexical: channel('unavailable'), semantic: channel(options.embedder ? 'unavailable' : 'absent') },
        coverage: unknownCoverage(input), trace: trace({ semantic: Boolean(options.embedder) }) };
      sampleTrace(diagnostics.trace);
      if (options.embedder && !dispatch) { diagnostics.channels.semantic = channel('budget_denied'); fail('invalid_input'); }
      deadlineAt = performance.now() + input.budget.maxMs; const projection = selected(input, access);
      lease = acquireSidecar(projection, access); const storage = lease.storage;
      const remaining = Math.floor(deadlineAt - performance.now());
      if (remaining < 1) { diagnostics.coverage.stops.deadline = true; fail('index_unavailable'); }
      const maintenance = storage.reconcile({ ...projection, budget: { ...input.budget, maxMs: remaining } }, { isCurrent: access.check });
      diagnostics.trace.maintenance = maintenance.metrics;
      access.check();
      let vectorProgress = { attempted: 0, embedded: 0 }, preflight, current = storage.state(projection);
      maintenanceCoverage(diagnostics.coverage, maintenance, { deadlineAt, maxItems: input.budget.maxItems });
      if (!current.ready) {
        diagnostics.coverage.maintenance.progress = maintenance.progress;
        sampleTrace(diagnostics.trace); access.check();
        return success({ status: 'rebuilding', progress: { lexical: maintenance.progress, transformed: maintenance.metrics.transformed,
          embeddingAttempts: 0, embedded: 0 }, coverage: diagnostics.coverage, channels: diagnostics.channels,
          ...(options.localStatus ? { trace: { localEmbedder: diagnostics.trace.localEmbedder } } : {}) });
      }
      diagnostics.channels.lexical = channel('ready');
      if (options.embedder) {
        controller = new AbortController(); controllers.add(controller);
        const remainingItems = input.budget.maxItems - maintenance.metrics.transformed, remainingMs = Math.floor(deadlineAt - performance.now());
        try {
          if (remainingItems > 0 && remainingMs > 0) vectorProgress = await storage.refreshVectors({ ...projection,
            budget: { maxItems: remainingItems, maxMs: remainingMs } }, dispatch.port(options.embedder,{budgetClass:'maintenance',signal:controller.signal,deadlineAt,
            guard:()=>{access.check();storage.assertState(projection,current,{checkpoint:false});}}), { signal: controller.signal, maxBatchDocuments: options.policy.maxBatchDocuments,
            isCurrent: () => { access.check(); return true; },
            onProgress: progress => { vectorProgress = progress; } });
          access.check();
          preflight = storage.semanticPreflight(projection, options.embedder, { deadlineAt });
          preflight.release?.();
          diagnostics.channels.semantic = channel(preflight.state);
        } catch (error) { diagnostics.channels.semantic = degradation(error); }
      }
      sampleTrace(diagnostics.trace);
      access.check(); current = storage.state(projection);
      if (!current.ready) fail('index_unavailable');
      diagnostics.coverage = coverage(input, current, preflight, 'lexical', 0, 0, maintenance);
      diagnostics.coverage.stops = { deadline: performance.now() >= deadlineAt,
        budget: maintenance.metrics.transformed + vectorProgress.attempted >= input.budget.maxItems || diagnostics.channels.semantic.causes.includes('budget_denied') };
      return success({ status: !options.embedder || diagnostics.channels.semantic.state === 'ready' ? 'complete' : 'partial',
        progress: { lexical: maintenance.progress, transformed: maintenance.metrics.transformed,
          embeddingAttempts: vectorProgress.attempted, embedded: vectorProgress.embedded }, coverage: diagnostics.coverage, channels: diagnostics.channels,
          ...(options.localStatus ? { trace: { localEmbedder: diagnostics.trace.localEmbedder } } : {}) });
    } catch (error) {
      if (diagnostics && !['scope_changed', 'authority_required', 'store_closed'].includes(error.code)) sampleTrace(diagnostics.trace);
      lease?.invalidate(error);
      if (diagnostics && deadlineAt !== undefined) diagnostics.coverage.stops.deadline ||= performance.now() >= deadlineAt;
      if (diagnostics) diagnostics.coverage.maintenance.reason ??= maintenanceReasons.get(error.reason) ?? null;
      return failure(error, ['scope_changed', 'authority_required', 'store_closed'].includes(error.code) ? undefined : diagnostics);
    }
    finally { lease?.release(); if (controller) { assertContentPort({invoke:()=>controller.abort()}); controllers.delete(controller); } }
  }
  async function refreshHostContextIndex(original, token) {
    let controller, diagnostics, lease, deadlineAt;
    try {
      ready();
      if (readOnly) fail('invalid_input');
      const { payload, input } = contextInput('refreshContextIndex', original, supportedTypes), access = authorize('refreshContextIndex', input, payload, token);
      // A host's all-idle combined turn can reuse only a complete maintenance
      // result, after rechecking its entire canonical/sidecar fence. This is
      // content-free upkeep state; failures always take the normal refresh path.
      const retained = maintenanceObservation.getStore();
      if (retained?.host && retained.previous && await retained.previous.current()) {
        access.check();
        retained.current = retained.previous.current;
        return retained.previous.result;
      }
      diagnostics = { channels: { lexical: channel('unavailable'), semantic: channel(options.embedder ? 'unavailable' : 'absent') },
        coverage: unknownCoverage(input), trace: trace({ semantic: Boolean(options.embedder) }) };
      sampleTrace(diagnostics.trace);
      if (options.embedder && !dispatch) { diagnostics.channels.semantic = channel('budget_denied'); fail('invalid_input'); }
      deadlineAt = performance.now() + input.budget.maxMs; const projection = selected(input, access);
      lease = acquireSidecar(projection, access); const storage = lease.storage;
      const remaining = Math.floor(deadlineAt - performance.now());
      if (remaining < 1) { diagnostics.coverage.stops.deadline = true; fail('index_unavailable'); }
      const maintenance = hasCommitDispatcher(db)
        ? await storage.reconcileAsync({ ...projection, budget: { ...input.budget, maxMs: remaining } }, { isCurrent: access.check })
        : storage.reconcile({ ...projection, budget: { ...input.budget, maxMs: remaining } }, { isCurrent: access.check });
      diagnostics.trace.maintenance = maintenance.metrics;
      access.check();
      let vectorProgress = { attempted: 0, embedded: 0 }, preflight, current = storage.state(projection);
      maintenanceCoverage(diagnostics.coverage, maintenance, { deadlineAt, maxItems: input.budget.maxItems });
      if (!current.ready) {
        diagnostics.coverage.maintenance.progress = maintenance.progress;
        sampleTrace(diagnostics.trace); access.check();
        return success({ status: 'rebuilding', progress: { lexical: maintenance.progress, transformed: maintenance.metrics.transformed,
          embeddingAttempts: 0, embedded: 0 }, coverage: diagnostics.coverage, channels: diagnostics.channels,
          ...(options.localStatus ? { trace: { localEmbedder: diagnostics.trace.localEmbedder } } : {}) });
      }
      diagnostics.channels.lexical = channel('ready');
      if (options.embedder) {
        controller = new AbortController(); controllers.add(controller);
        const remainingItems = input.budget.maxItems - maintenance.metrics.transformed, remainingMs = Math.floor(deadlineAt - performance.now());
        try {
          if (remainingItems > 0 && remainingMs > 0) vectorProgress = await storage.refreshVectors({ ...projection,
            budget: { maxItems: remainingItems, maxMs: remainingMs } }, dispatch.port(options.embedder,{budgetClass:'maintenance',signal:controller.signal,deadlineAt,
            guard:()=>{access.check();storage.assertState(projection,current,{checkpoint:false});}}), { signal: controller.signal, maxBatchDocuments: options.policy.maxBatchDocuments,
            isCurrent: () => { access.check(); return true; },
            onProgress: progress => { vectorProgress = progress; } });
          access.check();
          preflight = storage.semanticPreflight(projection, options.embedder, { deadlineAt });
          preflight.release?.();
          diagnostics.channels.semantic = channel(preflight.state);
        } catch (error) { diagnostics.channels.semantic = degradation(error); }
      }
      sampleTrace(diagnostics.trace);
      access.check(); current = storage.state(projection);
      if (!current.ready) fail('index_unavailable');
      diagnostics.coverage = coverage(input, current, preflight, 'lexical', 0, 0, maintenance);
      diagnostics.coverage.stops = { deadline: performance.now() >= deadlineAt,
        budget: maintenance.metrics.transformed + vectorProgress.attempted >= input.budget.maxItems || diagnostics.channels.semantic.causes.includes('budget_denied') };
      const observation = maintenanceObservation.getStore();
      if (observation && (observation.host || hasCommitDispatcher(db))) {
        const expected = current;
        observation.current = async () => {
          const check = () => {
            ready(); access.check();
            // This is the sidecar's complete canonical/index fence, including
            // Card dependencies, lineage and the owner suppression epoch.
            storage.assertState(projection, expected, { checkpoint: false });
            return true;
          };
          try {
            // Both connections keep 5 ms native waits for this synchronous
            // probe. Only the rolled-back probe retries, outside transactions.
            return hasCommitDispatcher(db) ? await dispatchCommit(storage, () => dispatchSynchronousCommit(db, check))
              : withContentSuppressionRequest(check, { fresh: true });
          } catch { return false; }
        };
      }
      return success({ status: !options.embedder || diagnostics.channels.semantic.state === 'ready' ? 'complete' : 'partial',
        progress: { lexical: maintenance.progress, transformed: maintenance.metrics.transformed,
          embeddingAttempts: vectorProgress.attempted, embedded: vectorProgress.embedded }, coverage: diagnostics.coverage, channels: diagnostics.channels,
          ...(options.localStatus ? { trace: { localEmbedder: diagnostics.trace.localEmbedder } } : {}) });
    } catch (error) {
      if (diagnostics && !['scope_changed', 'authority_required', 'store_closed'].includes(error.code)) sampleTrace(diagnostics.trace);
      lease?.invalidate(error);
      if (diagnostics && deadlineAt !== undefined) diagnostics.coverage.stops.deadline ||= performance.now() >= deadlineAt;
      if (diagnostics) diagnostics.coverage.maintenance.reason ??= maintenanceReasons.get(error.reason) ?? null;
      return failure(error, ['scope_changed', 'authority_required', 'store_closed'].includes(error.code) ? undefined : diagnostics);
    }
    finally { lease?.release(); if (controller) { assertContentPort({invoke:()=>controller.abort()}); controllers.delete(controller); } }
  }

  const identity = { storeId: info.storeId, cursorSecret: info.cursorSecret };
  const cards = info.cards ? createPrivateCardStorage({ db, identity, ready, rawSources: info.raw }) : null;
  const receipt = memoryOnly ? null : createCardReceiptSources(db, (purpose, value) =>
    createHmac('sha256', info.cursorSecret).update(JSON.stringify([purpose, [info.storeId, value]])).digest('base64url'));
  // context-read facade: memo receipt projection
  const evidence = memoryOnly ? null : createPrivateEvidenceStorage({ db, identity,
    memoReceiptEventTime: receiptEventTimeEnabled(cachedContentLayout(db)),
    cardDetailInside: (ns, id, readSet, options) => cards.cardDetailInside(ns, id, readSet, options), receiptRefInside: (ns, memory, row) => receipt.refInside(ns, memory, row) });
  // context-read facade: end memo receipt projection
  async function contextRead(original, token) {
    let candidates;
    try {
      ready();
      const { payload, input } = contextInput('contextRead', original, supportedTypes, options.sources);
      const compact = input.representation === 'memory-compact-v1';
      const deadlineAt = performance.now() + input.deadlineMs;
      const access = authorize('contextRead', input, payload, token);
      if (!options.counter) return failure(new MemoryStoreError('invalid_input'), { counter: 'absent' });
      let queryVector;
      const cardChannel = documentChannel && input.types.includes('memory') ? documentChannel : null;
      const searched = await searchCandidates(input, access, deadlineAt, true,
        cardChannel ? vector => { queryVector = vector; } : undefined);
      access.check();
      if (!searched.ok) {
        return deepFreeze({ ...searched, error: { ...searched.error,
          ...(searched.error.details ? { details: { candidates: searched.error.details } } : {}) } });
      }
      const rawChannel = options.rawSearch && input.raw
        ? await readRawChannel(options.rawSearch, input, token, deadlineAt) : { items: [], coverage: 'unavailable' };
      if (options.rawSearch && input.raw) access.check();
      const ledger = options.ledgerPort && input.types.includes('memory') && hasLedgerCue(input.query) && performance.now() < deadlineAt
        ? collectLedgerChannel(db, read, options.ledgerPort, input, deadlineAt, canonicalFence) : null;
      const document = cardChannel && performance.now() < deadlineAt
        ? await cardChannel.collect(input, access, deadlineAt, queryVector) : null;
      candidates = searched.horizon;
      searched.check(); // The horizon's search fences also cross the outer await.
      let deadline = performance.now() >= deadlineAt;
      access.check();
      deadline ||= performance.now() >= deadlineAt;
      const prepared = read(() => {
        // Inspect the authorized projection in this same transaction. This is
        // dispatch metadata, never a cached currentness decision.
        const dependencyAware = input.types.includes('card') && input.readSet.some(ns =>
          Object.keys(cardDependencyFence(db, ns, input.readSet)).length > 0);
        if (dependencyAware && performance.now() >= deadlineAt) {
          deadline = true;
          return { generations: [], items: [], unavailable: candidates.items.length };
        }
        const generations = canonicalFence(input.readSet, input.types), items = [], dateEntries = [];
        const safetyMemo=cachedContentLayout(db)?.suppressionRevision&&!options.sources?createContentReadMemo(db):undefined;
        const dated = input.representation === 'representation-v2-dated' || compact;
        if (safetyMemo && dated) safetyMemo.sourceDates = true;
        if (searched.sourceState) assertSourcesInside(input, searched.sourceState, 'snapshot_stale');
        let unavailable = 0;
        const witnessBudget = searched.sourceState ? sourceBudget(dependencyAware ? deadlineAt : Infinity) : null;
        for (const [position, candidate] of candidates.items.entries()) {
          if (dependencyAware && performance.now() >= deadlineAt) {
            deadline = true; unavailable += candidates.items.length - position; break;
          }
          let item;
          try {
            if (candidate.via) {
              const path = searched.sourceState.witnesses.find(value => same(value.ref, candidate.ref));
              try { witnessInside(input, path, 'evidence_unavailable', witnessBudget); }
              catch (error) { if (error.code === 'evidence_unavailable') { unavailable++; continue; } throw error; }
            }
            if (dependencyAware && performance.now() >= deadlineAt) { deadline = true; unavailable++; continue; }
            item = evidence.itemsInside(candidate.ref.namespace, [candidate.ref], input.intent, input.readSet, { deadlineAt: dependencyAware ? deadlineAt : Infinity, legacyEvidence:Boolean(options.sources), ...(safetyMemo?{safetyMemo,batchRefs:candidates.items.map(candidate=>candidate.ref)}:{}) })[0];
            if (dependencyAware && performance.now() >= deadlineAt) { deadline = true; unavailable++; continue; }
          }
          catch (error) {
            if (!['evidence_unavailable', 'revision_conflict'].includes(error.code)) throw error;
            unavailable++; continue;
          }
          const { type, ref, state, origin } = item;
          const memoryKey = JSON.stringify([[ref.namespace.ownerId,ref.namespace.scope,ref.namespace.projectId??''],ref.memoryId]);
          const sourceRows = type === 'memory' && item.provenance.sourceAccess === 'available' ?
            receiptSourceRows(db, ref.memoryId, dated && cachedContentLayout(db)?.rawLineage,
              safetyMemo?.evidenceReceipts?.get(memoryKey)?.slice(0,16), safetyMemo?.evidenceMemories?.get(memoryKey))
              .filter(row=>item.provenance.receiptMetadata.some(receipt=>receipt.receiptId===row.id)) : [];
          const date = receiptEventDate(sourceRows);
          const sources = sourceRows.map((row, index) => {
            const { role, excerpt } = validateSourceReceipt(ref.memoryId, row, source =>
              createHash('sha256').update(JSON.stringify(source)).digest('hex'));
            return { index, role, excerpt };
          });
          items.push({ type, ref, ns: input.readSet.findIndex(ns => namespaceKey(ns) === namespaceKey(ref.namespace)), rank: candidate.rank,
            metadata: type === 'memory' ? { state, reviewState: item.reviewState, filing: item.filing,
              kind: item.kind, origin, confidence: item.confidence } : { state, support: item.support, origin,
                ...(origin === 'engine' ? { builtAt: item.builtAt, clusterKey: item.clusterKey, status: item.status } : {}) },
            ...(type === 'card' && origin === 'engine' ? cardPackSources(item) : {}),
            text: type === 'memory' ? item.content : item.title + '\n' + item.body,
            turnIds: citedRawTurns(db, ref.namespace, sourceRows, rawChannel),
            sessionIds: sourceRows.map(row => JSON.stringify(['receipt', namespaceKey(ref.namespace), row.client, row.session_id])),
            date, sources, sourceAccess: type === 'memory' ? item.provenance.sourceAccess : 'unsupported',
            sourcesComplete: type === 'memory' && item.provenance.coverage.status === 'complete',
            fence: bind('snapshot-item', cardLineageItemInside(db,item)),
            dependencyCount: item.support?.currentDependency ? item.support.currentDependency.versions?.length ?? 0 : null });
          if (dated && type === 'memory') dateEntries.push({ item: items.at(-1), rows: sourceRows });
        }
        if (dated && !resolveMemorySourceDates(db, dateEntries, deadlineAt)) { items.length = 0; deadline = true; }
        return { generations, items, unavailable };
      });
      const scope = bind('snapshot-scope', input.readSet);
      const generationsFor = items => prepared.generations.map(value => ({ memory: value.memory,
        ...(items.some(item => item.type === 'card') ? { card: value.card,...(value.lineage?{lineage:value.lineage}:{}) } : {}) }));
      const snapshotValue = items => ({ v: 1, scope, intent: input.intent,
        refs: items.map(({ ref }) => [input.readSet.findIndex(ns => namespaceKey(ns) === namespaceKey(ref.namespace)), ref.type,
          ref.memoryId ?? ref.cardId, ref.revision, ...(ref.type === 'card' ? [ref.bodyRevision] : [])]),
        generations: generationsFor(items), access: access.accessGenerations, fences: items.map(item => item.fence) });
      // Compact keeps v1's 24-ref and size limits. Full refs remain in diagnostics.
      const snapshotFor = items => {
        if (compact && items.length > 24) return null;
        const value = snapshotValue(items);
        return compact &&
          Math.ceil(4 * Buffer.byteLength(JSON.stringify(value)) / 3) + 44 > CONTEXT_LIMITS.snapshotUnits ? null : value;
      };
      const dependencyReserve = items => {
        const declared = items.filter(item => item.dependencyCount !== null);
        if (!declared.length) return {};
        const resolutions = declared.reduce((n, item) => n + item.dependencyCount, 0);
        return { finalDependencyValidationReserve: { records: declared.length,
          resolutions, bindingProbes: 4 * resolutions, manifestRows: 256 * resolutions } };
      };
      const candidateDetails = () => ({ count: candidates.items.length, channels: candidates.channels, coverage: candidates.coverage,
        trace: options.localStatus ? { ...candidates.trace, localEmbedder: sampleLocalStatus(options.localStatus) } : candidates.trace });
      // Sample host status once. Dated trials and final delivery must use the
      // same candidate trace; the v2 sampling point remains after assembly.
      const datedCandidates = input.representation === 'representation-v2-dated' || compact ? candidateDetails() : null;
      // Compact visits each body once in preparation order, so the tail item
      // identifies an accepted trial. Minimal probes use the rejected item.
      const withoutSnapshot = compact ? new WeakSet() : null;
      // Wire-only Card projection retains canonical stored-body fences and bodyRevision.
      const assemble = raw => assembleThreeLayerContext({ prepared: prepared.items, counter: options.counter, policy: input.policy,
        query: input.query, readSet: input.readSet, intent: input.intent, ledgerItem: ledger?.item, documentItem: document?.item,
        budget: input.budget, representation: input.representation, deadlineAt,
        responseBytes: datedCandidates ? ({ meteredBytes, diagnostics, selected }) => {
          const envelope = success({ metered: null, snapshot: null,
            diagnostics: { ...diagnostics, omitted: { ...diagnostics.omitted, unavailable: prepared.unavailable },
              trace: { ...diagnostics.trace, ...dependencyReserve(selected) }, candidates: datedCandidates ?? candidateDetails() } });
          const value = selected.length ? snapshotFor(selected) : null;
          const fits = completeResponseBytes(envelope, meteredBytes, value) <= CONTEXT_LIMITS.responseBytes;
          if (fits || !compact || value === null) return fits;
          if (completeResponseBytes(envelope, meteredBytes, null) > CONTEXT_LIMITS.responseBytes) return false;
          withoutSnapshot.add(selected.at(-1));
          return true;
        } : undefined,
        snapshotOf: items => {
          const value = withoutSnapshot?.has(items.at(-1)) ? null : snapshotFor(items);
          return value === null ? null : encode('snapshot', value, 16384);
        } }, raw);
      let { selected: delivered, validateRaw, ...assembled } = assemble(rawChannel);
      const decorate = () => {
        const diagnostics = assembled.diagnostics;
        diagnostics.omitted.unavailable = prepared.unavailable;
        Object.assign(diagnostics.trace, dependencyReserve(delivered));
        diagnostics.candidates = datedCandidates ?? candidateDetails();
        diagnostics.stops.deadline ||= deadline || performance.now() >= deadlineAt;
      };
      decorate();
      access.check();
      // Counting and authority callbacks have finished. A failed final Raw
      // validation discards the whole Raw projection, including diagnostics.
      if (!validateRaw()) {
        ({ selected: delivered, validateRaw, ...assembled } = assemble({ items: [], coverage: 'partial' }));
        decorate(); access.check();
      }
      assembled.diagnostics.stops.deadline ||= performance.now() >= deadlineAt;
      const deliveredDocument = document && assembled.metered.items.includes(document.item);
      if (deliveredDocument) {
        access.check();
        documentChannel.assertCurrent(document);
      }
      const result = deepFreeze(success(assembled));
      if (bytes(result) > CONTEXT_LIMITS.responseBytes) fail('context_item_too_large');
      // No host callback, count or await follows this authoritative read.
      return read(() => {
        if (searched.sourceState) {
          assertSourcesInside(input, searched.sourceState, 'snapshot_stale');
          const witnessBudget = sourceBudget(Infinity);
          for (const path of searched.sourceState.witnesses) if (delivered.some(item => same(item.ref, path.ref)))
            witnessInside(input, path, 'snapshot_stale', witnessBudget);
        }
        if (deliveredDocument && !documentChannel.visible(document)) fail('snapshot_stale');
        if (ledger && assembled.metered.items.includes(ledger.item) &&
            !same(ledger.fence, canonicalFence(input.readSet, ['memory']))) fail('snapshot_stale');
        if (delivered.length && !same(canonicalFence(input.readSet, [...new Set(delivered.map(item => item.type))]), generationsFor(delivered))) fail('snapshot_stale');
        const safetyMemo=cachedContentLayout(db)?.suppressionRevision&&!options.sources?createContentReadMemo(db):undefined;
        for (const item of delivered) {
          let current;
          try { current = evidence.itemsInside(item.ref.namespace, [item.ref], input.intent, input.readSet,safetyMemo?{safetyMemo,batchRefs:delivered.map(item=>item.ref)}:options.sources?{legacyEvidence:true}:undefined)[0]; }
          catch (error) {
            if (['evidence_unavailable', 'revision_conflict'].includes(error.code)) fail('snapshot_stale');
            throw error;
          }
          if (bind('snapshot-item', cardLineageItemInside(db,current)) !== item.fence) fail('snapshot_stale');
        }
        return result;
      });
    } catch (error) {
      const finalTrace = candidates && error.code === 'index_unavailable' && options.localStatus ? { ...candidates.trace, localEmbedder: sampleLocalStatus(options.localStatus) } : candidates?.trace;
      return failure(error, candidates && error.code === 'index_unavailable' ? { candidates: {
        channels: candidates.channels, coverage: candidates.coverage, trace: finalTrace } } : undefined);
    }
  }
  function fetchCandidateEvidence(original, token, productPayload) {
    try {
      ready();
      const { payload, input } = contextInput('fetchCandidateEvidence', original, supportedTypes, undefined, options.product ? 'context-read-product-v1.1' : undefined), access = authorize('fetchCandidateEvidence', input, options.product ? productPayload ?? payload : payload, token);
      if (memoryOnly) fail('index_unavailable');
      const scope = bind('snapshot-scope', input.readSet);
      let intent = input.intent, refs = input.refs, previous;
      if (input.snapshot !== undefined) {
        previous = decode('snapshot', input.snapshot, 16384, 'invalid_snapshot');
        try {
          ownData(previous, ['v', 'scope', 'intent', 'refs', 'generations', 'access', 'fences']);
          if (previous.v !== 1 || previous.scope !== scope || !['current', 'history'].includes(previous.intent) || !Array.isArray(previous.refs)) fail('invalid_snapshot');
          refs = previous.refs.length === 0 && options.product ? [] : contextRefs(previous.refs.map(value => {
            if (!Array.isArray(value) || value.length !== (value[1] === 'card' ? 5 : 4) || !Number.isInteger(value[0]) || !input.readSet[value[0]]) fail('invalid_snapshot');
            return { namespace: input.readSet[value[0]], type: value[1], [value[1] === 'memory' ? 'memoryId' : 'cardId']: value[2], revision: value[3],
              ...(value[1] === 'card' ? { bodyRevision: value[4] } : {}) };
          }), input.readSet, supportedTypes); intent = previous.intent;
        } catch { fail('invalid_snapshot'); }
      }
      const types = [...new Set(refs.map(ref => ref.type))];
      function fetchInside() {
        const generations = canonicalFence(input.readSet, types);
        if (previous && (!same(previous.generations, generations) || !same(previous.access, access.accessGenerations))) fail('snapshot_stale');
        const safetyMemo=cachedContentLayout(db)?.suppressionRevision&&!options.sources?createContentReadMemo(db):undefined;
        const withholdPrivacy = Boolean(options.product && safetyMemo && !previous && refs.length > 1);
        const items = [], positions = [];
        for (const [index, ref] of refs.entries()) {
          const [item] = evidence.itemsInside(ref.namespace, [ref], intent, input.readSet,
            safetyMemo ? { safetyMemo, batchRefs: refs, visibleReceiptCoverage: options.product,
              withholdPrivacy: withholdPrivacy && input.fences?.[index] == null,
              checkExistingFence: Boolean(previous || input.fences) }
              : options.sources ? { legacyEvidence: true } : undefined);
          if (item === null) continue;
          items.push(item);
          positions.push(index);
        }
        const fenceFor = item => bind('snapshot-item', cardLineageItemInside(db, item));
        const fences = items.map(fenceFor);
        const originalFence = index => {
          const item = safetyMemo?.originalEvidence?.get(items[index]);
          return item && fenceFor(item);
        };
        if (input.fences && positions.some((index, i) => {
          const prefix = input.fences[index];
          return prefix !== null && !fences[i].startsWith(prefix) && !originalFence(i)?.startsWith(prefix);
        })) fail('snapshot_stale');
        if (previous && !same(previous.fences, fences) &&
            (!Array.isArray(previous.fences) || previous.fences.length !== fences.length ||
              fences.some((fence, index) => fence !== previous.fences[index] && originalFence(index) !== previous.fences[index]))) {
          fail('snapshot_stale');
        }
        return { items, generations, fences, positions };
      }
      const prepared = read(fetchInside);
      access.check();
      // Final canonical refetch is synchronous. There is no await or host
      // callback after this point; snapshots bind the exact delivered items.
      return read(() => {
        const current = fetchInside();
        if (!same(current.generations, prepared.generations) || !same(current.fences, prepared.fences) ||
            !same(current.positions, prepared.positions)) fail('snapshot_stale');
        const visible = current.positions.map(index => refs[index]);
        const result = { items: current.items, snapshot: encode('snapshot', { v: 1, scope, intent,
          refs: visible.map(ref => [input.readSet.findIndex(ns => namespaceKey(ns) === namespaceKey(ref.namespace)), ref.type,
            ref.memoryId ?? ref.cardId, ref.revision, ...(ref.type === 'card' ? [ref.bodyRevision] : [])]),
          generations: current.generations, access: access.accessGenerations, fences: current.fences }, 16384) };
        if (bytes(success(result)) > input.responseByteLimit) fail('context_item_too_large');
        return success(result);
      });
    } catch (error) {
      return facadeFailure(error);
    }
  }
  function cardVectors(request) {
    if (!options.embedder) return [];
    for (const entry of indexes.values()) {
      try { const rows = entry.storage.cardVectors(request, options.embedder); if (rows.length) return rows; }
      catch { /* Optional old/missing vectors retain the lexical cluster path. */ }
    }
    return [];
  }
  return { fileIdentity: database?.fileIdentity, productCapabilities: { types: supportedTypes, receiptEventTime: receiptEventTimeEnabled(cachedContentLayout(db)) },
    cardVectors,
    ...(options.product ? { productPort: { db, read, ready, evidence, bind, encode, decode, identity, features: info, canonicalFence } } : {}),
    methods: contentSafetyFacade({ getContextReadCapabilities() {
    return success(structuredClone({ version: CONTEXT_VERSION, methods: [...CONTEXT_METHODS], receiptEventTime: receiptEventTimeEnabled(cachedContentLayout(db)), types: [...supportedTypes], intents: ['current', 'history'],
      channels: { lexical: { enabled: true }, semantic: { configured: Boolean(options.embedder), budgetConfigured: Boolean(dispatch) } },
      ...configuration, limits: { ...CONTEXT_LIMITS, ...(options.sources ? { horizon: 32, sources: SOURCE_LIMITS } : {}) }, maintenance: !readOnly && !memoryOnly,
      assembly: { representation: 'representation-v2-dated', raw: { default: true, configured: Boolean(options.rawSearch) }, representations: [...ASSEMBLY_REPRESENTATIONS], defaults: ASSEMBLY_DEFAULTS, policies: [...ASSEMBLY_POLICIES], defaultPolicy: DEFAULT_ASSEMBLY_POLICY,
        counter: options.counter ? { id: options.counter.id } : null, limits: { ...ASSEMBLY_LIMITS, ...(options.sources ? { candidates: 32, counterCalls: 1634 } : {}) } },
      unsupported: ['role-profiles', ...(!options.sources?.includes('relations-one-hop-v1') ? ['relations'] : []),
        ...(!options.sources?.includes('moc-v1') ? ['moc'] : []), 'partial-semantic-search'] }));
  }, findCandidates, refreshContextIndex, fetchCandidateEvidence, contextRead }, {
      select: (args, method) => {
        assertCompactContextInput(method, args[0], supportedTypes, options.sources);
        return args[0];
      }, check: (scopes,{delivery}) => { ready();
        if (!delivery && scopes.length && cachedContentLayout(db)?.suppressionRevision && hasContentSuppressionRequestInside(db) && !db.isTransaction) {
          contentSuppressionRequestInside(db,scopes,{defer:true}); return;
        }
        if (delivery) assertContentSuppressionRequestInside(db,scopes);
        assertContentScopes(db, scopes);
      },
      requestScope: withContentSuppressionRequest, portGuard: scopes => options.product ? undefined : contentScopeEpochGuard(db,scopes),
      validate(method,_args,_result,scopes) {
        if(readOnly||method!=='refreshContextIndex'||!cachedContentLayout(db)?.suppressionRevision)return;
        // Physical maintenance usage stays internal when a scoped fact exists.
        // Work has completed; its public acknowledgement carries no population.
        const state = scopes.length && cachedContentSuppressionRequestInside(db,scopes[0].ownerId);
        if (state?.facts && scopes.every(ns=>state.owner===ns.ownerId && state.readSet.some(selected=>
          selected.scope===ns.scope && (selected.projectId??'')===(ns.projectId??'')))) {
          if (state.facts.some(f=>scopes.some(ns=>['personal','project'].includes(ns.scope) &&
            f.scope===ns.scope && f.project_id===(ns.projectId??'')))) fail('index_unavailable');
          return;
        }
        read(()=>{for(const ns of scopes)if(['personal','project'].includes(ns.scope)&&db.prepare(`SELECT 1 FROM content_suppressions INDEXED BY content_suppression_target
          WHERE (owner_id,scope,project_id)=(?,?,?) LIMIT 1`).get(ns.ownerId,ns.scope,ns.projectId??''))fail('index_unavailable');});
      }, noOwner: ['getContextReadCapabilities'], failure: facadeFailure }), close() {
    if (closed) return;
    closed = true; for (const controller of controllers) assertContentPort({invoke:()=>controller.abort()});
    defaultRankings.rankings.clear(); defaultRankings.retainedSourceBytes = 0; rankingPartitions = new WeakMap(); for (const entry of indexes.values()) entry.storage.close(); indexes.clear(); if (db?.isOpen) db.close();
  } };
}

function collectLedgerChannel(db, read, port, input, deadlineAt, canonicalFence) {
  const asOf = new Date();
  const window = parseWindow(input.query, asOf);
  let partitions;
  try {
    partitions = assertContentPort({ invoke: () => input.readSet.map(ns =>
      inertContentPortValue(port.list(ledgerNamespace(ns), { to: asOf.toISOString().slice(0, 10) }))) });
  } catch { return null; }
  if (performance.now() >= deadlineAt || !partitions.every(Array.isArray) ||
      !readIntent(input.query, partitions.flat())) return null;
  return read(() => {
    const current = db.prepare('SELECT revision FROM memories WHERE owner_id=? AND scope=? AND project_id=? AND id=?');
    const safetyMemo = createContentReadMemo(db);
    const rows = [];
    for (const [index, partition] of partitions.entries()) {
      const ns = input.readSet[index], checked = new Map();
      for (const row of partition) {
        if (performance.now() >= deadlineAt) return null;
        const key = JSON.stringify([row.memoryId, row.revision]);
        if (!checked.has(key)) {
          const memory = current.get(ns.ownerId, ns.scope, ns.projectId ?? '', row.memoryId);
          const ref = { type: 'memory', namespace: ns, memoryId: row.memoryId, revision: memory?.revision };
          checked.set(key, memory && memory.revision >= row.revision &&
            (memory.revision === row.revision || !contentSuppressionReasonInside(db, ns, {
              kind: 'memory', key: row.memoryId, revision: row.revision,
              version: JSON.stringify(['memory-revision-v1', row.revision]),
            })) && contentReadSafety(db, { namespace: ns, ref, memo: safetyMemo }).allowed);
        }
        if (checked.get(key)) rows.push(row);
      }
    }
    if (!readIntent(input.query, rows)) return null;
    const result = digest(rows, rows, window);
    return result && { item: { channel: 'ledger-v1', ...result }, fence: canonicalFence(input.readSet, ['memory']) };
  });
}

function createDocumentChannel(db, { cardPort, embedder, counter, policy }, read, dispatch, controllers) {
  const roots = createRawSourceRoots(db);
  const call = work => assertContentPort({ invoke: () => inertContentPortValue(work(), 'invalid_input', { rejectProxies: true }) });
  const witness = ({ id, revision, source, sourceMemoryIds, title, body, date, stale }) =>
    JSON.stringify([id, revision, source, sourceMemoryIds, title, body, date, stale]);
  const embeddingKey = embedder && JSON.stringify(metadata(embedder));
  let hasEpisodes = false;
  function visible({ namespace, card }) {
    const { source, sourceMemoryIds, stale } = card;
    if (contentSuppressionReasonInside(db, namespace)) return false;
    try { roots.assertSession(namespace, source.client, source.sessionId, true); }
    catch (error) { if (error.code === 'conversation_deleted') return false; throw error; }
    hasEpisodes ||= Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE name='session_episodes'").get());
    if (hasEpisodes && db.prepare(`SELECT 1 FROM session_episodes
      WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key IN (?,?) AND deleted=1`)
      .get(namespace.ownerId, namespace.scope, namespace.projectId ?? '', source.client,
        ...roots.keys(namespace, source.client, source.sessionId))) return false;
    const row = db.prepare('SELECT deleted FROM memories WHERE owner_id=? AND scope=? AND project_id=? AND id=?');
    return [...sourceMemoryIds, ...(stale?.map(entry => entry.replacement.memoryId) ?? [])].every(id =>
      row.get(namespace.ownerId, namespace.scope, namespace.projectId ?? '', id)?.deleted !== 1);
  }
  function assertCurrent({ namespace, card }) {
    const current = call(() => cardPort.get(namespace, card.id));
    if (!current || witness(current) !== witness(card)) fail('snapshot_stale');
  }
  async function semanticScores(rows, query, access, deadlineAt, queryVector) {
    if (!dispatch) return [];
    const controller = new AbortController();
    controllers.add(controller);
    async function embed(texts, entries) {
      const guard = () => {
        access.check();
        for (const entry of entries) assertCurrent(entry);
        if (entries.length && !read(() => entries.every(visible))) fail('snapshot_stale');
      };
      const vectors = await dispatch(embedder, texts, { signal: controller.signal, deadlineAt, guard,
        budgetClass: entries.length ? 'maintenance' : 'query' });
      if (!Array.isArray(vectors) || vectors.length !== texts.length) fail('provider_error');
      return vectors.map(vector => validateVector(vector, embedder));
    }
    try {
      const missing = rows.filter(({ card }) => card.embedding?.key !== embeddingKey);
      const size = policy.maxBatchDocuments ?? 32;
      for (let index = 0; index < missing.length; index += size) {
        const batch = missing.slice(index, index + size);
        const vectors = await embed(batch.map(({ card }) => Array.from(card.body).slice(0, 2000).join('')), batch);
        for (const [i, entry] of batch.entries()) {
          const { namespace, card } = entry;
          const embedding = { key: embeddingKey, vector: vectors[i] };
          assertCurrent(entry);
          call(() => cardPort.put(namespace, { ...card, embedding }));
          card.embedding = embedding;
        }
      }
      const vector = queryVector ?? (await embed([query], []))[0];
      return rows.map(entry => [cosine(vector, validateVector(entry.card.embedding.vector, embedder)), entry]);
    } finally {
      assertContentPort({ invoke: () => controller.abort() });
      controllers.delete(controller);
    }
  }
  async function collect(input, access, deadlineAt, queryVector) {
    try {
      const rows = input.readSet.flatMap(namespace => call(() => cardPort.list(namespace)).map(card => ({ namespace, card })));
      if (!rows.length || performance.now() >= deadlineAt) return null;
      access.check();
      // The canonical transaction returns only booleans. Embedding vectors
      // belong to the port and stay outside the SQLite read result.
      const allowed = read(() => rows.map(visible));
      const eligible = rows.filter(({ namespace, card }, index) => {
        if (!allowed[index]) call(() => cardPort.hide(namespace, card.id, 'source_unavailable'));
        return allowed[index];
      });
      if (!eligible.length) return null;
      const ranked = embedder ? await semanticScores(eligible, input.query, access, deadlineAt, queryVector) :
        eligible.map(entry => [documentLexicalScore(input.query, entry.card), entry]);
      let score = -Infinity, match;
      const threshold = embedder ? .35 : .6;
      for (const [similarity, entry] of ranked) if (similarity >= threshold && similarity > score) {
        match = entry; score = similarity;
      }
      if (!match || performance.now() >= deadlineAt) return null;
      access.check();
      assertCurrent(match);
      const { namespace, card } = match;
      const count = text => {
        if (performance.now() >= deadlineAt) fail('timeout');
        return countTokens(counter, text, () => access.check());
      };
      const piece = documentPiece(card.body, input.query, input.budget.maxTokens, count);
      if (!piece.body) return null;
      const replacements = new Map((card.stale ?? []).map(({ replacement }) =>
        [replacement.memoryId, replacement]));
      return { ...match, item: { channel: DOCUMENT_CARD_CHANNEL, id: card.id, title: card.title, date: card.date, ...piece,
        source: { namespace, ...card.source }, sourceMemoryIds: card.sourceMemoryIds,
        ...(replacements.size ? { stale: true, replacements: [...replacements.values()],
          precedence: DOCUMENT_CARD_PRECEDENCE } : {}) } };
    } catch (error) {
      if (['scope_changed', 'authority_required', 'store_closed'].includes(error.code)) throw error;
      return null;
    }
  }
  return { collect, visible, assertCurrent };
}
