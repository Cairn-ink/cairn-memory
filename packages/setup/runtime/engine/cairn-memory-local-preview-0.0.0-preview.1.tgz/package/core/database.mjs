import { clearReceiptCoordinatesInside } from './raw-source-roots.mjs';
import './content-write-safety.mjs';
import { inContentSuppressionRequestInside, withoutContentSuppressionReadCacheInside } from './content-suppression-storage.mjs';
import { beginContentWrite, contentWriteOperation } from './content-write-context.mjs';
import { contentSafetyInventory, installContentSafetyInside } from './content-safety-migration.mjs';
import { SAFETY_SCHEMA_VERSIONS, resolveContentLayout, assertContentFeatures } from './content-safety-layout.mjs';
import { attestContentSafety, checkInstalledContentSafety, registerContentReadSnapshot, bindContentSafetyConnection, contentSafetyConnection } from './content-safety-schema.mjs';
import { validateContextProductLayout } from './context-product-schema.mjs';
import { installCardCurrentDependencies, validateCardCurrentDependencies, assertNoCardCurrentDependencies } from './card-current-schema.mjs';
import { installRoleProfiles, validateRoleProfiles, assertNoRoleProfiles } from './role-profile-schema.mjs';
import { installAssets, validateAssets, assertNoAssets } from './asset-schema.mjs';
import { types } from 'node:util';
import { createExclusiveSqliteFile } from './sqlite-journal-probe.mjs';
import { storeFenceOption,pinStoreFile,assertStoreIdentity,noncreatingStoreURI } from './store-fence.mjs';
import { migrateMethodPrerequisites } from './method-package-migration.mjs';
import { randomBytes, randomUUID } from "node:crypto";
import { installRawDeletion, RAW_DELETION_SCHEMA_VERSION } from './raw-deletion-schema.mjs';
import { installRawSources, RAW_SOURCE_SCHEMA_VERSION } from './raw-source-schema.mjs';
import { assertNoLocalAuthority, installLocalAuthority, validateLocalAuthority, validateRawSourcePrerequisites, LOCAL_AUTHORITY_SCHEMA_VERSION } from './local-authority-schema.mjs';
import { lstatSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { existingStoreOption, existingStorePath, validateExistingStore } from './existing-store.mjs';
import { migrateVersion17, CONFIRMATION_SCHEMA_VERSION } from './confirmation-schema.mjs';
import { fail } from "./validation.mjs";
import { installPrivateCards, installCardMemorySources, PRIVATE_CARD_SCHEMA_VERSION } from './private-card-schema.mjs';
import { installPrivateEvidence, PRIVATE_EVIDENCE_SCHEMA_VERSION } from './private-evidence-schema.mjs';
import { installPrivateOrganization, PRIVATE_ORGANIZATION_SCHEMA_VERSION } from './private-organization-schema.mjs';
import { migrateVersion6, installIndexReaders } from "./index-schema.mjs";
import { migrateVersion8 } from './ordered-capture-schema.mjs';
import { migrateVersion9 } from './claim-qualification-schema.mjs';
import { migrateVersion10 } from './qualified-transition-schema.mjs';
import { migrateVersion11 } from './rationale-schema.mjs';
import { migrateVersion12 } from './staged-evidence-schema.mjs';
import { migrateVersion13 } from './classification-journal-schema.mjs';
import { installRawJournal, RAW_SCHEMA_VERSION, installRawCapture, RAW_CAPTURE_SCHEMA_VERSION } from './raw-schema.mjs';
import { installRawLineage, RAW_LINEAGE_SCHEMA_VERSION } from './raw-lineage-schema.mjs';

import { migrateVersion14, migrateVersion15, migrateVersion16 } from './episode-schema.mjs';

export const STORAGE_BUSY_TIMEOUT_MS = 5_000;
export const isStorageBusy = error => error?.code === 'ERR_SQLITE_ERROR' &&
  Number.isInteger(error.errcode) && [5, 6].includes(error.errcode & 0xff);

export const APPLICATION_ID = 0x43414952;
const VERSION = CONFIRMATION_SCHEMA_VERSION;
// Existing layouts accepted without an upgrade by the ordinary opener.
export const READ_SCHEMA_VERSIONS = Object.freeze([VERSION, 20, PRIVATE_CARD_SCHEMA_VERSION,
  PRIVATE_EVIDENCE_SCHEMA_VERSION, PRIVATE_ORGANIZATION_SCHEMA_VERSION, LOCAL_AUTHORITY_SCHEMA_VERSION, 30, 31, 32, 33, ...SAFETY_SCHEMA_VERSIONS]);
// Context reads also validate existing pre-control Raw stores. The retained
// topic reader's narrower supported-version list remains unchanged.
export const CONTEXT_READ_SCHEMA_VERSIONS = Object.freeze([...new Set([...READ_SCHEMA_VERSIONS,
  RAW_SCHEMA_VERSION, RAW_CAPTURE_SCHEMA_VERSION, RAW_LINEAGE_SCHEMA_VERSION, RAW_DELETION_SCHEMA_VERSION, RAW_SOURCE_SCHEMA_VERSION])]);

function createVersion3(db) {
  db.exec(`
    CREATE TABLE memories (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      fingerprint TEXT NOT NULL,
      content TEXT,
      kind TEXT NOT NULL,
      origin TEXT NOT NULL CHECK (origin IN ('explicit','agent-inferred')),
      confidence REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
      revision INTEGER NOT NULL CHECK (revision > 0),
      deleted INTEGER NOT NULL DEFAULT 0 CHECK (deleted IN (0,1)),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      CHECK ((scope = 'personal' AND project_id = '') OR
             (scope = 'project' AND length(project_id) > 0)),
      CHECK ((deleted = 0 AND content IS NOT NULL) OR (deleted = 1 AND content IS NULL))
    ) STRICT;
    CREATE UNIQUE INDEX active_identity ON memories(owner_id, scope, project_id, fingerprint)
      WHERE deleted = 0;
    CREATE INDEX namespace_memories ON memories(
      owner_id, scope, project_id, deleted, updated_at DESC, id);
    CREATE TABLE receipts (
      id TEXT NOT NULL UNIQUE,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      receipt_key TEXT NOT NULL,
      client TEXT NOT NULL,
      session_id TEXT NOT NULL,
      event_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user','assistant')),
      excerpt TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (memory_id, receipt_key)
    ) STRICT;
    CREATE INDEX memory_receipts ON receipts(memory_id, created_at, id);
    CREATE TABLE suppressed (
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL,
      project_id TEXT NOT NULL,
      fingerprint TEXT NOT NULL,
      PRIMARY KEY (owner_id, scope, project_id, fingerprint)
    ) STRICT;
    CREATE TABLE namespace_epochs (
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      epoch INTEGER NOT NULL CHECK (epoch >= 1),
      PRIMARY KEY (owner_id, scope, project_id)
    ) STRICT;
    CREATE TABLE store_metadata (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      store_id TEXT NOT NULL UNIQUE,
      cursor_secret TEXT NOT NULL
    ) STRICT;
  `);
  db.prepare(`INSERT INTO store_metadata(singleton, store_id, cursor_secret)
    VALUES (1, ?, ?)`).run(randomUUID(), randomBytes(32).toString("hex"));
}

function migrateVersion1(db) {
  db.exec(`
    ALTER TABLE receipts RENAME TO receipts_v1;
    CREATE TABLE receipts (
      id TEXT NOT NULL UNIQUE,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      receipt_key TEXT NOT NULL,
      client TEXT NOT NULL,
      session_id TEXT NOT NULL,
      event_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user','assistant')),
      excerpt TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (memory_id, receipt_key)
    ) STRICT;
  `);
  const insert = db.prepare(`INSERT INTO receipts
    (id, memory_id, receipt_key, client, session_id, event_id, role, excerpt, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  for (const receipt of db.prepare("SELECT * FROM receipts_v1").all()) {
    insert.run(randomUUID(), receipt.memory_id, receipt.receipt_key, receipt.client,
      receipt.session_id, receipt.event_id, receipt.role, receipt.excerpt, receipt.created_at);
  }
  db.exec(`
    DROP TABLE receipts_v1;
    DROP INDEX namespace_memories;
    CREATE INDEX namespace_memories ON memories(
      owner_id, scope, project_id, deleted, updated_at DESC, id);
    CREATE INDEX memory_receipts ON receipts(memory_id, created_at, id);
    CREATE TABLE namespace_epochs (
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      epoch INTEGER NOT NULL CHECK (epoch >= 1),
      PRIMARY KEY (owner_id, scope, project_id)
    ) STRICT;
    INSERT INTO namespace_epochs(owner_id, scope, project_id, epoch)
      SELECT DISTINCT owner_id, scope, project_id, 1 FROM memories;
    CREATE TABLE store_metadata (
      singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
      store_id TEXT NOT NULL UNIQUE,
      cursor_secret TEXT NOT NULL
    ) STRICT;
  `);
  db.prepare(`INSERT INTO store_metadata(singleton, store_id, cursor_secret)
    VALUES (1, ?, ?)`).run(randomUUID(), randomBytes(32).toString("hex"));
}

function migrateVersion3(db) {
  db.exec(`
    ALTER TABLE memories ADD COLUMN filing_status TEXT NOT NULL DEFAULT 'unfiled'
      CHECK (filing_status IN ('filed','unfiled'));
    CREATE TABLE mocs (
      id TEXT PRIMARY KEY,
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      level INTEGER NOT NULL CHECK (level IN (1,2)),
      title TEXT NOT NULL,
      canonical_title TEXT NOT NULL,
      revision INTEGER NOT NULL CHECK (revision > 0),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      CHECK ((scope = 'personal' AND project_id = '') OR
             (scope = 'project' AND length(project_id) > 0))
    ) STRICT;
    CREATE UNIQUE INDEX namespace_moc_titles ON mocs(
      owner_id, scope, project_id, level, canonical_title);
    CREATE INDEX namespace_mocs ON mocs(
      owner_id, scope, project_id, level, canonical_title, id);
    CREATE TABLE moc_title_sources (
      moc_id TEXT NOT NULL REFERENCES mocs(id) ON DELETE CASCADE,
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      memory_revision INTEGER NOT NULL CHECK (memory_revision > 0),
      PRIMARY KEY (moc_id, memory_id)
    ) STRICT;
    CREATE INDEX memory_title_sources ON moc_title_sources(memory_id, moc_id);
    CREATE TABLE moc_memory_refs (
      moc_id TEXT NOT NULL REFERENCES mocs(id) ON DELETE CASCADE,
      moc_revision INTEGER NOT NULL CHECK (moc_revision > 0),
      memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      memory_revision INTEGER NOT NULL CHECK (memory_revision > 0),
      PRIMARY KEY (moc_id, memory_id)
    ) STRICT;
    CREATE INDEX memory_moc_refs ON moc_memory_refs(memory_id, moc_id);
    CREATE TABLE moc_edges (
      parent_id TEXT NOT NULL REFERENCES mocs(id) ON DELETE CASCADE,
      parent_revision INTEGER NOT NULL CHECK (parent_revision > 0),
      child_id TEXT NOT NULL REFERENCES mocs(id) ON DELETE CASCADE,
      child_revision INTEGER NOT NULL CHECK (child_revision > 0),
      PRIMARY KEY (parent_id, child_id),
      CHECK (parent_id != child_id)
    ) STRICT;
    CREATE INDEX child_moc_edges ON moc_edges(child_id, parent_id);
  `);
}

function migrateVersion4(db) {
  db.exec(`
    CREATE TABLE admission_claims (
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      client TEXT NOT NULL,
      event_id TEXT NOT NULL,
      payload_digest TEXT NOT NULL CHECK (
        length(payload_digest) = 64 AND payload_digest NOT GLOB '*[^0-9a-f]*'),
      state TEXT NOT NULL CHECK (state IN ('pending','completed')),
      token TEXT,
      lease_expires_at INTEGER,
      memory_ids TEXT,
      suppressed_count INTEGER,
      PRIMARY KEY (owner_id, scope, project_id, client, event_id),
      CHECK ((scope = 'personal' AND project_id = '') OR
             (scope = 'project' AND length(project_id) > 0)),
      CHECK ((state = 'pending' AND token IS NOT NULL AND lease_expires_at IS NOT NULL
        AND memory_ids IS NULL AND suppressed_count IS NULL) OR
        (state = 'completed' AND token IS NULL AND lease_expires_at IS NULL
        -- Five opaque IDs of up to 200 characters, doubled by JSON escaping,
        -- plus quotes, commas and brackets (including IDs preserved by migration).
        AND memory_ids IS NOT NULL AND length(memory_ids) <= 2016
        AND suppressed_count IS NOT NULL AND suppressed_count BETWEEN 0 AND 5))
    ) STRICT;
  `);
}

function migrateVersion5(db) {
  db.exec(`
    CREATE TABLE memory_conflicts (
      left_memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      left_revision INTEGER NOT NULL CHECK (left_revision > 0),
      right_memory_id TEXT NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
      right_revision INTEGER NOT NULL CHECK (right_revision > 0),
      relation TEXT NOT NULL CHECK (relation = 'contradicts'),
      source TEXT NOT NULL CHECK (source IN ('explicit-hint','inferred-hint')),
      PRIMARY KEY (left_memory_id, left_revision, right_memory_id, right_revision, relation, source),
      CHECK (left_memory_id < right_memory_id)
    ) STRICT;
    CREATE INDEX right_memory_conflicts ON memory_conflicts(right_memory_id);
  `);
}

function migrateVersion7(db) {
  db.exec(`ALTER TABLE memories ADD COLUMN currentness TEXT NOT NULL DEFAULT 'current'
    CHECK (currentness IN ('current','historical'));
    CREATE TABLE memory_supersessions (
      owner_id TEXT NOT NULL,
      scope TEXT NOT NULL CHECK (scope IN ('personal','project')),
      project_id TEXT NOT NULL,
      previous_memory_id TEXT PRIMARY KEY REFERENCES memories(id),
      previous_revision INTEGER NOT NULL CHECK (previous_revision > 0),
      replacement_memory_id TEXT NOT NULL REFERENCES memories(id),
      replacement_revision INTEGER NOT NULL CHECK (replacement_revision > 0),
      -- Four opaque 200-unit IDs, including worst-case JSON escaping/delimiters.
      receipt_ids TEXT NOT NULL CHECK (length(receipt_ids) <= 1613),
      CHECK (previous_memory_id != replacement_memory_id),
      CHECK ((scope = 'personal' AND project_id = '') OR
             (scope = 'project' AND length(project_id) > 0))
    ) STRICT;
    CREATE INDEX replacement_supersessions ON memory_supersessions(replacement_memory_id);`);
  installIndexReaders(db, true);
}

// A read callback is internal, synchronous work on this connection only: no
// await, host callbacks, nested transactions, transaction control or live cursors.
// Return fully materialized arrays/records, never opaque containers or handles.
const activeReads = new WeakSet(), discardedConnections = new WeakSet();
export const isConnectionDiscarded = db => discardedConnections.has(db);
function materializedRead(value, seen = new Set()) {
  if (typeof value === 'function') fail('storage_error');
  if (!value || typeof value !== 'object') return;
  if (types.isPromise(value)) fail('storage_error');
  const prototype = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && prototype !== null && prototype !== Object.prototype) fail('storage_error');
  for (let prototype = value; prototype; prototype = Object.getPrototypeOf(prototype)) {
    for (const key of ['next', 'then']) {
      const descriptor = Object.getOwnPropertyDescriptor(prototype, key);
      if (descriptor && (!Object.hasOwn(descriptor, 'value') || typeof descriptor.value === 'function')) fail('storage_error');
    }
  }
  if (seen.has(value)) return;
  seen.add(value);
  const descriptors = Object.getOwnPropertyDescriptors(value);
  for (const key of Reflect.ownKeys(descriptors)) {
    const descriptor = descriptors[key];
    if (!Object.hasOwn(descriptor, 'value')) fail('storage_error');
    materializedRead(descriptor.value, seen);
  }
}
// Only the work phase uses this adapter. Transaction ownership remains keyed on
// db; safety/suppression resolve the adapter to that same native connection.
function checkedReadConnection(db, check) {
  if (!check) return db;
  const wrap = target => { const proxy = new Proxy(target, { get(object, key) {
    if (key === Symbol.iterator) return () => proxy;
    const value = Reflect.get(object, key, object);
    if (typeof value !== 'function') return value;
    return (...args) => {
      if (key !== 'return' && key !== Symbol.dispose && key !== 'close') check();
      const result = Reflect.apply(value, object, args);
      return key === 'prepare' || key === 'iterate' ? wrap(result) : result === object ? proxy : result;
    };
  } }); return proxy; };
  return bindContentSafetyConnection(wrap(db), db);
}
export function readTransaction(db, work, acquisition) {
  if (discardedConnections.has(db) || !db.isOpen) fail('store_closed');
  if (activeReads.has(db) || db.isTransaction || typeof work !== 'function' ||
      types.isAsyncFunction(work) || types.isGeneratorFunction(work)) fail('storage_error');
  activeReads.add(db);
  let saved, began = false, attempted = false, value, error, failed = false, cleanupError, cleanupFailed = false, unsafeResult = false;
  try {
    // Optional opening budget; connection identity and cleanup stay unchanged.
    acquisition?.checkAdmission?.();
    const queryOnly = db.prepare('PRAGMA query_only');
    acquisition?.checkAdmission?.();
    saved = queryOnly.get().query_only;
    acquisition?.checkAdmission?.();
    db.exec('PRAGMA query_only=ON');
    acquisition?.checkAdmission?.();
    attempted = true;
    db.exec('BEGIN');
    began = true;
    // Private synchronous acquisition hook, before suppression/safety reads.
    // Internal callers may acquire SHARED here without host callbacks.
    acquisition?.readReady?.();
    value = inContentSuppressionRequestInside(checkedReadConnection(db, acquisition?.checkAdmission), work);
    try { materializedRead(value); } catch (failure) { unsafeResult = true; throw failure; }
    if (!db.isTransaction) fail('storage_error');
    acquisition?.checkAdmission?.();
    db.exec('COMMIT');
    began = false;
  } catch (failure) {
    error = failure; failed = true;
    // Also covers a BEGIN that took effect before an instrumentation failure.
    began ||= attempted && db.isTransaction;
  } finally {
    if (began && db.isTransaction) {
      clearReceiptCoordinatesInside(contentSafetyConnection(db));
      try { db.exec('ROLLBACK'); } catch (failure) { cleanupError = failure; cleanupFailed = true; }
    }
    if (saved !== undefined) {
      try {
        const restore = () => db.exec('PRAGMA query_only=' + (saved ? 'ON' : 'OFF'));
        if (acquisition?.cleanup) acquisition.cleanup(restore); else restore();
      }
      catch (failure) { if (!cleanupFailed) cleanupError = failure; cleanupFailed = true; }
    }
    if (cleanupFailed || unsafeResult) {
      discardedConnections.add(db);
      try { db.close(); } catch { /* Poisoned even if native close fails. */ }
    }
    activeReads.delete(db);
  }
  if (cleanupFailed) throw cleanupError;
  if (failed) throw error;
  return value;
}
registerContentReadSnapshot((db,work)=>readTransaction(db,()=>{checkInstalledContentSafety(db);return work();}));

// Reviewed read-only mode: keep transaction fences and statement counts, acquiring
// SHARED on the first SELECT. Writers must retain BEGIN IMMEDIATE.
export function transaction(db, work, check, { deferred = false, beforeCommit } = {}) {
  if (activeReads.has(db) || discardedConnections.has(db)) fail('storage_error');
  check?.();
  const execute = () => {
    db.exec(deferred ? "BEGIN" : "BEGIN IMMEDIATE");
    let contentWrite;
    try {
      const result = inContentSuppressionRequestInside(db, () => {
        checkInstalledContentSafety(db);
        contentWrite = beginContentWrite(db);
        return work();
      });
      contentWrite?.validate(result);
      contentWrite?.close();
      contentWrite = null;
      beforeCommit?.();
      check?.();
      db.exec("COMMIT");
      return result;
    } catch (error) {
      clearReceiptCoordinatesInside(contentSafetyConnection(db));
      if(db.isTransaction)db.exec("ROLLBACK");
      if (error?.code === 'ERR_SQLITE_ERROR' && error.message === 'card_dependency_limit_reached') {
        fail('dependency_limit_reached');
      }
      throw error;
    } finally { contentWrite?.close(); }
  };
  return contentWriteOperation(db) ? withoutContentSuppressionReadCacheInside(db, execute) : execute();
}

// Presence is significant: explicit undefined and accessors are invalid.
export function busyTimeoutOption(input) {
  if (!input || typeof input !== 'object') return undefined;
  const descriptor = Object.getOwnPropertyDescriptor(input, 'busyTimeoutMs');
  if (!descriptor) {
    if ('busyTimeoutMs' in input) fail('invalid_input');
    return undefined;
  }
  // Retained openers may accept Proxies. Only the supplied opt-in requires
  // an own data property that can be attested without a Proxy.
  if (types.isProxy(input)) fail('invalid_input');
  if (!Object.hasOwn(descriptor, 'value') || !Number.isInteger(descriptor.value) ||
      descriptor.value < 0 || descriptor.value > STORAGE_BUSY_TIMEOUT_MS) fail('invalid_input');
  return descriptor.value;
}

/** contentSafety:'s2h-v1' creates only a new file, at its base's safety cell.
 * Default creation and all existing-store maintenance paths stay unchanged. */
export function openDatabase(path, options = {}) {
  const busyTimeoutMs = busyTimeoutOption(options);
  const timeout = Math.min(STORAGE_BUSY_TIMEOUT_MS, busyTimeoutMs ?? STORAGE_BUSY_TIMEOUT_MS);
  let { privateCards = false, rawConversations = false, rawCapture = false, rawLineage = false, rawDeletion = false, rawSources = false, localControls = false, methodPackages = false, assets = false, roleProfiles = false, currentDependencies = false, existingStore, storeFence, contentSafety } = options;
  if ([rawConversations, rawCapture, rawLineage, rawDeletion, rawSources, localControls].some(value => typeof value !== 'boolean')) fail('invalid_input');
  rawDeletion ||= rawSources || localControls;
  rawLineage ||= rawDeletion;
  rawCapture ||= rawLineage;
  rawConversations ||= rawCapture;
  if (contentSafety !== undefined) {
    if (contentSafety !== 's2h-v1') fail('invalid_input');
    if (existingStore !== undefined || storeFence !== undefined || path === ':memory:' ||
        !currentDependencies && (rawConversations || methodPackages || assets || roleProfiles)) fail('unsupported_database');
  }
  if (storeFence !== undefined && existingStore !== undefined) fail('invalid_input');
  const fence = storeFence === undefined ? undefined : storeFenceOption(storeFence);
  if (existingStore !== undefined) {
    const option = existingStoreOption(existingStore), location = existingStorePath(path);
    const db = new DatabaseSync(location.uri, { timeout });
    try {
      location.check();
      db.exec('PRAGMA foreign_keys = ON; PRAGMA trusted_schema = OFF;');
      validateExistingStore(db, option);
      const layout = resolveContentLayout(db.prepare('PRAGMA user_version').get().user_version);
      assertContentFeatures(layout, { privateCards, rawConversations, rawCapture, rawLineage, rawDeletion, rawSources, localControls, methodPackages, assets, roleProfiles, currentDependencies });
      if ((assets || roleProfiles || currentDependencies) && layout.base < 31) fail('unsupported_database');
      if ((roleProfiles || currentDependencies) && layout.base < 32) fail('unsupported_database');
      if (methodPackages && layout.base < 30) fail('unsupported_database');
      if (currentDependencies && layout.base !== 33) fail('unsupported_database');
      location.check();
      return db;
    } catch (error) {
      try { db.close(); } catch { /* Preserve the construction failure. */ }
      throw error;
    }
  }
  if (typeof path !== "string" || !path.trim() || path.includes("\0")) fail("invalid_path");
  let pin;
  if (fence) {
    pin = pinStoreFile(path, fence);
  } else if (path !== ":memory:") {
    path = resolve(path);
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 });
    try {
      // Existing files need no fd. A missing file is exclusively created in a
      // child so even a concurrent Worker opening the new inode is lock-safe.
      lstatSync(path);
      if (contentSafety !== undefined) fail('unsupported_database');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      try { createExclusiveSqliteFile(path); }
      catch (creation) { if (creation.code !== 'EEXIST') throw creation; if (contentSafety !== undefined) fail('unsupported_database'); }
    }
    const stat = lstatSync(path);
    if (!stat.isFile() || (process.platform !== "win32" && (stat.mode & 0o077))) {
      fail("unsafe_database_file");
    }
  }
  let db;
  try {
    // URI mode=rw is mandatory for fences: no mkdir or creation fallback.
    db = new DatabaseSync(fence ? noncreatingStoreURI(path) : path, { timeout });
    db.exec("PRAGMA foreign_keys = ON; PRAGMA trusted_schema = OFF;");
    const needsWriter = Symbol('open needs writer');
    try {
      transaction(db, () => {
        if (fence) {
          pin.check();
          assertStoreIdentity(db, fence);
        }
        if (contentSafety !== undefined && (db.prepare('PRAGMA application_id').get().application_id !== 0 ||
            db.prepare('PRAGMA user_version').get().user_version !== 0 ||
            db.prepare('SELECT count(*) n FROM sqlite_schema').get().n !== 0)) fail('unsupported_database');
        const layout = attestContentSafety(db);
        // Only suppression-revision layouts have a read-only ordinary open.
        // Older layouts retain the IMMEDIATE body below, after rolling back
        // this snapshot; all checks must run again under the writer lock.
        if (!layout.suppressionRevision) throw needsWriter;
        if (db.prepare('PRAGMA application_id').get().application_id !== APPLICATION_ID) fail('unsupported_database');
        assertContentFeatures(layout, { privateCards, rawConversations, rawCapture, rawLineage, rawDeletion, rawSources, localControls, methodPackages, assets, roleProfiles, currentDependencies });
        validateContextProductLayout(db, layout);
      }, undefined, { deferred: true });
      return db;
    } catch (error) {
      if (error !== needsWriter) throw error;
    }
    transaction(db, () => {
      if (fence) {
        // Before initialize() and all migration/schema or application writes.
        pin.check();
        assertStoreIdentity(db, fence);
      }
      if (contentSafety !== undefined && (db.prepare('PRAGMA application_id').get().application_id !== 0 ||
          db.prepare('PRAGMA user_version').get().user_version !== 0 ||
          db.prepare('SELECT count(*) n FROM sqlite_schema').get().n !== 0)) fail('unsupported_database');
      const layout = attestContentSafety(db);
      if (layout.suppressionRevision) {
        if (db.prepare('PRAGMA application_id').get().application_id !== APPLICATION_ID) fail('unsupported_database');
        assertContentFeatures(layout, { privateCards, rawConversations, rawCapture, rawLineage, rawDeletion, rawSources, localControls, methodPackages, assets, roleProfiles, currentDependencies });
        validateContextProductLayout(db, layout);
        return;
      }
      function initialize() {
      const appId = db.prepare("PRAGMA application_id").get().application_id;
      const version = db.prepare("PRAGMA user_version").get().user_version;
      if ((methodPackages || assets || roleProfiles || currentDependencies) && !(appId === 0 && version === 0 && db.prepare('SELECT count(*) AS n FROM sqlite_master').get().n === 0) &&
          !(appId === APPLICATION_ID && [18,20,21,22,23,24,25,26,27,28,29,30,31,32,33].includes(version))) fail('unsupported_database');
      if (version < 33) assertNoCardCurrentDependencies(db);
      if (version < 32) assertNoRoleProfiles(db);
      if (version < 31) assertNoAssets(db);
      if (appId === APPLICATION_ID && [30,31,32,33].includes(version)) {
        validateExistingStore(db, { storeId: db.prepare('SELECT store_id FROM store_metadata WHERE singleton=1').get()?.store_id });
        return;
      }
      if (appId === APPLICATION_ID && [RAW_SCHEMA_VERSION, RAW_CAPTURE_SCHEMA_VERSION, RAW_LINEAGE_SCHEMA_VERSION, RAW_DELETION_SCHEMA_VERSION, RAW_SOURCE_SCHEMA_VERSION, LOCAL_AUTHORITY_SCHEMA_VERSION].includes(version)) {
        if (version < LOCAL_AUTHORITY_SCHEMA_VERSION) assertNoLocalAuthority(db);
        for (const name of ['raw_conversations','raw_messages','raw_parts','raw_events','raw_owner_usage','raw_capture_controls',
          'private_cards','card_notes','card_applicability_reviews','evidence_mappings']) {
          if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name)) fail('unsupported_database');
        }
        if (version >= RAW_CAPTURE_SCHEMA_VERSION) {
          for (const name of ['raw_capture_events', 'raw_session_fences']) {
            if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name)) fail('unsupported_database');
          }
        } else if (rawCapture) {
          installRawCapture(db);
          db.exec(`PRAGMA user_version = ${RAW_CAPTURE_SCHEMA_VERSION};`);
        }
        if (version >= RAW_LINEAGE_SCHEMA_VERSION) {
          for (const name of ['raw_source_maps','raw_receipt_lineage','raw_receipt_origins','raw_exclusion_clocks','raw_source_exclusions']) {
            if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name)) fail('unsupported_database');
          }
        } else if (rawLineage) {
          installRawLineage(db);
          db.exec(`PRAGMA user_version = ${RAW_LINEAGE_SCHEMA_VERSION};`);
        }
        if (version >= RAW_DELETION_SCHEMA_VERSION) {
          for (const name of ['raw_deletion_actions','raw_job_sources','raw_closed_jobs','raw_deletion_effects']) {
            if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?").get(name)) fail('unsupported_database');
          }
        } else if (rawDeletion) {
          installRawDeletion(db);
          db.exec(`PRAGMA user_version = ${RAW_DELETION_SCHEMA_VERSION};`);
        }
        if (version >= RAW_SOURCE_SCHEMA_VERSION) {
          validateRawSourcePrerequisites(db);
        } else if (rawSources || localControls) {
          installRawSources(db);
          db.exec(`PRAGMA user_version = ${RAW_SOURCE_SCHEMA_VERSION};`);
        }
        if (version === LOCAL_AUTHORITY_SCHEMA_VERSION) validateLocalAuthority(db);
        else if (localControls) {
          installLocalAuthority(db);
          db.exec(`PRAGMA user_version = ${LOCAL_AUTHORITY_SCHEMA_VERSION};`);
        }
        return;
      }
      function upgrade() {
      if (appId === APPLICATION_ID && version === PRIVATE_ORGANIZATION_SCHEMA_VERSION) return;
      if (appId === APPLICATION_ID && version === PRIVATE_EVIDENCE_SCHEMA_VERSION) {
        if (privateCards || rawConversations) {
          installPrivateOrganization(db);
          db.exec(`PRAGMA user_version = ${PRIVATE_ORGANIZATION_SCHEMA_VERSION};`);
        }
        return;
      }
      if (appId === APPLICATION_ID && version === PRIVATE_CARD_SCHEMA_VERSION) {
        if (privateCards || rawConversations) {
          installPrivateEvidence(db);
          installPrivateOrganization(db);
          db.exec(`PRAGMA user_version = ${PRIVATE_ORGANIZATION_SCHEMA_VERSION};`);
        }
        return;
      }
      if (appId === APPLICATION_ID && version === 20) {
        if (privateCards || rawConversations) {
          installCardMemorySources(db);
          installPrivateEvidence(db);
          installPrivateOrganization(db);
          db.exec(`PRAGMA user_version = ${PRIVATE_ORGANIZATION_SCHEMA_VERSION};`);
        }
        return;
      }
      if (appId === APPLICATION_ID && version === VERSION) {
        if (privateCards || rawConversations) {
          installPrivateCards(db);
          installCardMemorySources(db);
          installPrivateEvidence(db);
          installPrivateOrganization(db);
          db.exec(`PRAGMA user_version = ${PRIVATE_ORGANIZATION_SCHEMA_VERSION};`);
        }
        return;
      }
      function upgradeCommittedSchema() {
        if (appId === APPLICATION_ID && version === 14) return;
        if (appId === APPLICATION_ID && version === 13) {
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 12) {
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 11) {
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 10) {
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 9) {
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 8) {
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 7) {
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 6) {
          migrateVersion6(db);
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 1) {
          migrateVersion1(db);
          migrateVersion3(db);
          migrateVersion4(db);
          migrateVersion5(db);
          migrateVersion6(db);
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 3) {
          migrateVersion3(db);
          migrateVersion4(db);
          migrateVersion5(db);
          migrateVersion6(db);
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 4) {
          migrateVersion4(db);
          migrateVersion5(db);
          migrateVersion6(db);
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        if (appId === APPLICATION_ID && version === 5) {
          migrateVersion5(db);
          migrateVersion6(db);
          migrateVersion7(db);
          migrateVersion8(db);
          migrateVersion9(db);
          migrateVersion10(db);
          migrateVersion11(db);
          migrateVersion12(db);
          migrateVersion13(db);
          return;
        }
        const tables = db.prepare("SELECT count(*) AS n FROM sqlite_master").get().n;
        if (appId !== 0 || version !== 0 || tables !== 0) fail("unsupported_database");
        createVersion3(db);
        migrateVersion3(db);
        migrateVersion4(db);
        migrateVersion5(db);
        migrateVersion6(db);
        migrateVersion7(db);
        migrateVersion8(db);
        migrateVersion9(db);
        migrateVersion10(db);
        migrateVersion11(db);
        migrateVersion12(db);
        migrateVersion13(db);
      }
      if (!(appId === APPLICATION_ID && version === 17)) {
        if (!(appId === APPLICATION_ID && version === 16)) {
          if (!(appId === APPLICATION_ID && version === 15)) {
            upgradeCommittedSchema();
            migrateVersion14(db);
          }
          migrateVersion15(db);
        }
        migrateVersion16(db);
      }
      migrateVersion17(db);
      db.exec(`PRAGMA application_id = ${APPLICATION_ID}; PRAGMA user_version = ${VERSION};`);
      if (privateCards || rawConversations) {
        installPrivateCards(db);
        installCardMemorySources(db);
        installPrivateEvidence(db);
        installPrivateOrganization(db);
        db.exec(`PRAGMA user_version = ${PRIVATE_ORGANIZATION_SCHEMA_VERSION};`);
      }
      }
      upgrade();
      if (rawConversations) {
        installRawJournal(db);
        db.exec(`PRAGMA user_version = ${RAW_SCHEMA_VERSION};`);
        if (rawCapture) {
          installRawCapture(db);
          db.exec(`PRAGMA user_version = ${RAW_CAPTURE_SCHEMA_VERSION};`);
          if (rawLineage) {
            installRawLineage(db);
            db.exec(`PRAGMA user_version = ${RAW_LINEAGE_SCHEMA_VERSION};`);
            if (rawDeletion) {
              installRawDeletion(db);
              db.exec(`PRAGMA user_version = ${RAW_DELETION_SCHEMA_VERSION};`);
              if (rawSources || localControls) {
                installRawSources(db);
                db.exec(`PRAGMA user_version = ${RAW_SOURCE_SCHEMA_VERSION};`);
                if (localControls) {
                  installLocalAuthority(db);
                  db.exec(`PRAGMA user_version = ${LOCAL_AUTHORITY_SCHEMA_VERSION};`);
                }
              }
            }
          }
        }
      }
      }
      initialize();
      if (methodPackages || assets || roleProfiles || currentDependencies) migrateMethodPrerequisites(db);
      if ((assets || roleProfiles || currentDependencies) && db.prepare('PRAGMA user_version').get().user_version < 31) {
        installAssets(db);
        db.exec('PRAGMA user_version=31');
        validateAssets(db);
      }
      if ((roleProfiles || currentDependencies) && db.prepare('PRAGMA user_version').get().user_version < 32) {
        installRoleProfiles(db);
        db.exec('PRAGMA user_version=32');
        validateRoleProfiles(db);
      }
      if (currentDependencies && db.prepare('PRAGMA user_version').get().user_version < 33) {
        installCardCurrentDependencies(db);
        db.exec('PRAGMA user_version=33');
        validateCardCurrentDependencies(db);
      }
      if (contentSafety !== undefined) {
        const base = db.prepare('PRAGMA user_version').get().user_version;
        installContentSafetyInside(db, base, contentSafetyInventory(db));
      }
    });
    return db;
  } catch (error) {
    db?.close();
    throw error;
  } finally { pin?.close(); }
}
