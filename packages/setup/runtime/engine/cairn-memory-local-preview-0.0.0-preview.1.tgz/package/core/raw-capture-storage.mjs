import { cachedContentLayout } from './content-safety-schema.mjs';
import { contentReadSafety } from './content-safety.mjs';
import { createHash } from 'node:crypto';
import { transaction, isStorageBusy } from './database.mjs';
import { createRawJournal, isRawEpochConflict } from './raw-journal.mjs';
import { rawBoundary, rawRegistration, rawNamespace } from './raw-input.mjs';
import { captureSnapshot } from './capture-input.mjs';
import { dispatchCommit, hasCommitDispatcher } from './commit-dispatch.mjs';
import { episodeSnapshot } from './episode-input.mjs';
import { episodeText } from './episode-storage.mjs';
import { rawSourceMap } from './raw-source-map.mjs';
import { createRawLineageStorage } from './raw-lineage-storage.mjs';
import { boundedText, fail, identifier, object, revision } from './validation.mjs';
import { managedRequest } from './local-authority-input.mjs';
import { createLocalAuthorityStorage, createLocalRawPrivacyStorage } from './local-authority-storage.mjs';
import { localAuthorityGuard } from './local-authority-guard.mjs';

const where = 'owner_id=? AND scope=? AND project_id=? AND client=? AND event_id=?';
const key = input => [...rawBoundary(input.namespace), input.client, input.eventId];
const freeze = value => {
  if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
};
const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');

/** Internal only: joins the real admission/episode transaction, never interprets. */
export function createRawCaptureStorage({ db, profile, ...options }) {
  const hostInterpretation = options.interpretation === 'host';
  const privacy = options.localRawPrivacy ? createLocalRawPrivacyStorage(db) : null;
  const arrivalInputs = new WeakMap();
  const journal = createRawJournal({ db, ...options });
  const lineage = createRawLineageStorage(db);
  const authority = db.prepare("SELECT 1 FROM sqlite_master WHERE name='local_capture_controls'").get() ? createLocalAuthorityStorage(db) : null;
  const binding = input => db.prepare(`SELECT * FROM raw_capture_events WHERE ${where}`).get(...key(input));
  const rawEvent = input => db.prepare(`SELECT result FROM raw_events WHERE ${where}`).get(...key(input));

  async function prepare(request, ordinary = false, ordinaryOrder, unknownMessageIds = [], arrivalToken = {}, deadline) {
    const managed = options.localAuthority;
    if (managed) {
      request = managedRequest(request, Boolean(profile.sessionEpisodes));
      authority.check(managed, request.namespace, request.client);
    }
    object(request, ['namespace','client','sessionId','eventId','messages',
      ...(profile.sessionEpisodes ? ['episodeContext'] : ['causal'])]);
    const { causal, episodeContext, ...source } = request;
    const input = freeze(rawRegistration(source));
    const rangeMessages = input.messages.map(message => unknownMessageIds.includes(message.id) ? { id:message.id, occurredAt: null } : { id:message.id, occurredAt: message.occurredAt });
    if (privacy) arrivalInputs.set(arrivalToken, { ...input, messages: rangeMessages });
    // Copy the complete context/profile and projection before the first await.
    let context = {};
    if (profile.sessionEpisodes) {
      object(episodeContext, ['clientLabel','generation','origin']);
      if (!['ordinary','precompact'].includes(episodeContext.origin)) fail('invalid_input');
      context = { episodeContext: { clientLabel: episodeText(episodeContext.clientLabel, 80),
        generation: identifier(episodeContext.generation), origin: episodeContext.origin } };
    } else if (causal !== undefined) {
      if (profile.captureEvidence || profile.captureSourcePolicy === 'indexed-evidence-v1') fail('invalid_input');
      object(causal, ['streamId','sequence']);
      context = { causal: { streamId: identifier(causal.streamId), sequence: revision(causal.sequence) } };
    }
    const sessionKey = journal.sessionKey(input.namespace, input.client, input.sessionId);
    privacy?.assertModeInside(input.namespace, input.client, sessionKey, hostInterpretation ? 'host' : 'engine');
    try {
      const fence = () => privacy?.fenceArrival(input.namespace, input.client, sessionKey, rangeMessages);
      if (privacy && hasCommitDispatcher(db)) await dispatchCommit(db, fence, deadline); else fence();
    }
    catch (error) {
      if (privacy && !isStorageBusy(error) && ['storage_busy','conversation_deleted'].includes(error.code)) arrivalInputs.get(arrivalToken).decided = true;
      throw error;
    }
    const previous = binding(input);
    if (previous) { const denied = localAuthorityGuard(db,previous); if (denied) fail(denied); }
    let bindingDigest = managed ? hash(['raw-capture-managed-v1',profile,context,managed.targetId,managed.storeId,
      rawBoundary(managed.namespace),managed.client,managed.expectedConsentGeneration]) : hash(['raw-capture-v1', profile, context]);
    if (hostInterpretation) bindingDigest = hash(['raw-capture-host-v1', bindingDigest]);
    if (previous && previous.binding_digest !== bindingDigest) fail('event_payload_conflict');
    const row = db.prepare(`SELECT id FROM raw_conversations WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key=?`)
      .get(...rawBoundary(input.namespace), input.client, sessionKey);
    const firstIds = ordinary ? input.messages.map(message => message.id) : previous ? JSON.parse(previous.first_message_ids) : input.messages.filter(message =>
      message.part.index === 0 && !(row && db.prepare('SELECT 1 FROM raw_parts WHERE conversation_id=? AND message_id=? AND part_index=0')
        .get(row.id, message.id))).map(message => message.id);
    const messages = hostInterpretation ? [] : input.messages.filter(message => firstIds.includes(message.id)).flatMap(message => {
      let content;
      try { content = boundedText(message.content, 4000, true); }
      catch (error) { if (error.code === 'invalid_text') return []; throw error; }
      return [{ id: message.id, role: message.role, content,
        ...((profile.sessionEpisodes || ordinary) ? { occurredAt: message.occurredAt } : {}) }];
    });
    if (ordinaryOrder) messages.sort((a,b) => ordinaryOrder.indexOf(a.id) - ordinaryOrder.indexOf(b.id));
    const projection = freeze({ namespace: { ...input.namespace, projectId: input.namespace.projectId || null },
      client: input.client, eventId: input.eventId,
      sessionId: profile.sessionEpisodes || ordinary ? input.sessionId : sessionKey, messages, ...context });
    const snapshot = messages.length ? profile.sessionEpisodes ? episodeSnapshot(projection)
      : captureSnapshot(projection, profile.captureQualification, profile.captureSourcePolicy) : null;
    const projectionDigest = snapshot?.payloadDigest ?? hash([hostInterpretation ? 'raw-capture-host-empty-v1' : 'raw-capture-empty-v1',
      sessionKey, input.eventId, firstIds, bindingDigest]);
    const maps = lineage.enabled() ? input.messages.filter(message => messages.some(value => value.id === message.id)).map(rawSourceMap) : [];
    if (previous && previous.projection_digest !== projectionDigest) fail('event_payload_conflict');
    const generation = db.prepare('SELECT generation FROM episode_controls WHERE owner_id=? AND scope=? AND project_id=?')
      .get(...rawBoundary(input.namespace))?.generation ?? 'initial';
    if (profile.sessionEpisodes && context.episodeContext.generation !== generation) fail('generation_conflict');
    deadline?.check();
    const token = await journal.prepareRegistration(input);
    // On expiry, establish this registration's own refusal before the retry
    // boundary checks the budget. A prior attempt supplies no provenance.
    let epochConflict;
    const checkFailureDeadline = () => {
      if (!arrivalInputs.get(arrivalToken)?.decided) deadline?.check();
    };
    const checkDeadline = () => {
      if (arrivalInputs.get(arrivalToken)?.decided) return;
      if (deadline?.expired()) {
        try { journal.assertRegistrationCurrent(token); }
        catch (error) {
          if (isRawEpochConflict(error)) { epochConflict = error; throw error; }
          // Mixed conflicts cannot prove an epoch-only failure. Keep expiry.
        }
      }
      deadline?.check();
    };
    checkDeadline();
    if (managed) authority.check(managed,input.namespace,input.client);
    // A same-event winner may have committed while sealing awaited. Select
    // observation before any model preflight; commit still checks atomically.
    const replay = Boolean(previous || binding(input));

    function admissionState(eventId) {
      const admission = db.prepare(`SELECT * FROM admission_claims WHERE ${where}`)
        .get(...rawBoundary(input.namespace), input.client, eventId);
      if (admission?.state === 'completed') return { admission, state: 'completed' };
      const evidence = db.prepare(`SELECT state,expires_at FROM staged_capture_evidence WHERE ${where}`)
        .get(...rawBoundary(input.namespace), input.client, eventId);
      const watermark = evidence && db.prepare('SELECT watermark FROM staged_capture_clocks WHERE owner_id=? AND scope=? AND project_id=?')
        .get(...rawBoundary(input.namespace))?.watermark;
      if (evidence && (evidence.state !== 'pending' || evidence.expires_at <= Math.max(Date.now(), watermark ?? 0))) {
        return { admission, state: 'incomplete' };
      }
      const writer = admission?.state === 'reserved' && db.prepare(`SELECT writer_expires_at FROM session_episodes
        WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key=?`)
        .get(...rawBoundary(input.namespace), input.client, sessionKey);
      return { admission, state: admission?.lease_expires_at > Date.now() || writer?.writer_expires_at > Date.now()
        ? 'processing' : 'incomplete' };
    }

    function emptyOutcome() {
      const overlap = input.messages.filter(message => message.part.index === 0 && !firstIds.includes(message.id));
      if (hostInterpretation || !overlap.length) return { status: 'not-run', reason: firstIds.length ? 'no-eligible-first-part' : 'continuation' };
      let processing = false, incomplete = false, interpreted = false;
      for (const message of overlap) {
        const owner = db.prepare('SELECT first_event_id FROM raw_messages WHERE conversation_id=? AND message_id=?').get(row?.id, message.id);
        const origin = owner && binding({ ...input, eventId: owner.first_event_id });
        if (!origin || !JSON.parse(origin.eligible_message_ids).includes(message.id)) continue;
        interpreted = true;
        const { state } = admissionState(owner.first_event_id);
        if (state === 'processing') processing = true;
        else if (state !== 'completed') incomplete = true;
      }
      return processing ? { processing: true, admission: { status: 'processing' } }
        : incomplete ? { status: 'incomplete', reason: 'interpretation-incomplete' }
          : interpreted ? { duplicate: true, overlap: true, admission: { status: 'covered' } }
            : { status: 'not-run', reason: 'no-eligible-first-part' };
    }

    function assertEpochCurrent() { if (epochConflict) throw epochConflict; }
    function commit() {
      if (!db.isTransaction) fail('raw_transaction_required');
      // First decision under the writer lock: a refused batch writes neither
      // mode/range nor admission/Raw/payload rows. Callers commit this sentinel
      // before surfacing the refusal, so no rollback-to-fence crash gap exists.
      const closed = privacy?.fenceArrivalInside(input.namespace, input.client, sessionKey, rangeMessages);
      if (closed) { arrivalInputs.get(arrivalToken).decided = true; return { closed }; }
      checkDeadline();
      if (managed) authority.check(managed,input.namespace,input.client);
      privacy?.assertModeInside(input.namespace, input.client, sessionKey, hostInterpretation ? 'host' : 'engine', true);
      privacy?.recordRangeInside(input.namespace, input.client, sessionKey, rangeMessages);
      let result;
      checkDeadline();
      try { result = journal.commitRegistration(token); }
      catch (error) { if (isRawEpochConflict(error)) epochConflict = error; throw error; }
      checkDeadline();
      const existing = binding(input);
      if (existing) {
        if (existing.binding_digest !== bindingDigest || existing.projection_digest !== projectionDigest) fail('event_payload_conflict');
      } else {
        lineage.register(result.conversationId, maps);
        db.prepare(`INSERT INTO raw_capture_events(owner_id,scope,project_id,client,event_id,conversation_id,
          session_key,first_message_ids,eligible_message_ids,projection_digest,binding_digest,capture_generation)
          VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).run(...key(input), result.conversationId, sessionKey,
          JSON.stringify(firstIds), JSON.stringify(messages.map(message => message.id)), projectionDigest, bindingDigest, generation);
        if (managed) db.prepare(`UPDATE raw_capture_events SET local_target_id=?,local_store_id=?,local_consent_generation=? WHERE ${where}`)
          .run(managed.targetId,managed.storeId,managed.expectedConsentGeneration,...key(input));
      }
      return { raw: result, ...(existing && snapshot && !ordinary ? { observation: replayInside(existing) } : {}) };
    }
    let accepted = false;

    // Called only under the same transaction that revalidates/commits Raw.
    // It observes shared admission state without acquiring interpretation work.
    function replayInside(recorded) {
      const denied = localAuthorityGuard(db,recorded); if (denied) fail(denied);
      const currentGeneration = db.prepare('SELECT generation FROM episode_controls WHERE owner_id=? AND scope=? AND project_id=?')
        .get(...rawBoundary(input.namespace))?.generation ?? 'initial';
      if (recorded.capture_generation !== currentGeneration) fail('capture_evidence_closed');
      const { admission, state } = admissionState(input.eventId);
      if (admission && admission.payload_digest !== projectionDigest) fail('event_payload_conflict');
      if (state === 'processing') return { processing: true, admission: { status: 'processing' } };
      if (state !== 'completed') return { status: 'incomplete', reason: 'interpretation-incomplete' };
      let reconciliation;
      if (projection.causal) {
        const ordered = db.prepare(`SELECT stream_id,sequence,reconciliation FROM capture_events WHERE ${where}`).get(...key(input));
        if (!ordered || ordered.stream_id !== projection.causal.streamId || ordered.sequence !== projection.causal.sequence ||
            !ordered.reconciliation) fail('capture_order_conflict');
        reconciliation = JSON.parse(ordered.reconciliation);
      }
      const memoryIds = JSON.parse(admission.memory_ids), suppressedCount = admission.suppressed_count;
      if(cachedContentLayout(db)?.suppressionRevision)for(const memoryId of memoryIds){
        const row=db.prepare('SELECT revision FROM memories WHERE id=?').get(memoryId);
        if(!row||!contentReadSafety(db,{namespace:input.namespace,ref:{type:'memory',namespace:input.namespace,memoryId,revision:row.revision},intent:'history'}).allowed)fail('memory_suppressed');
      }
      const episode = profile.sessionEpisodes && db.prepare(`SELECT episode_id FROM episode_events WHERE ${where}`).get(...key(input));
      return { duplicate: true, memoryIds, suppressedCount,
        ...(reconciliation ? { reconciliation } : {}),
        ...(profile.captureRationale ? { rationale: { status: 'not-run',reason: 'duplicate',previousOutcome: 'unavailable' } } : {}),
        ...(episode ? { episode: { id: episode.episode_id, status: 'not-run', reason: 'replay' },
          admission: { status: 'completed', memoryIds, suppressedCount } } : {}) };
    }

    function observeReplay(onlyRecorded = false) {
      if (!snapshot) fail('invalid_input');
      // An already failed interpretation cannot acquire new retry provenance.
      const result = transaction(db, () => {
        if (onlyRecorded) {
          if (!binding(input)) return null;
          // Observation must never repair an orphan binding by registering new
          // source. The existing receipt makes journal commit a guarded replay.
          if (!rawEvent(input)) fail('event_payload_conflict');
        }
        // Exact source identity and current namespace/session authority still
        // pass through the journal. Staging is never a Raw read permission.
        const committed = commit();
        if (committed.closed) return committed;
        if (!committed.observation) fail('invalid_input');
        return committed.observation;
      }, onlyRecorded ? checkFailureDeadline : checkDeadline);
      if (result?.closed) fail(result.closed);
      if (result) accepted = true;
      return result;
    }
    const commitOnly = () => { const result = transaction(db, commit, checkDeadline); if (result.closed) fail(result.closed); accepted = true; return result; };
    return Object.freeze({ localPrivacy: Boolean(privacy), input: projection, hasProjection: Boolean(snapshot), replay,
      emptyOutcome, commit, observeReplay, assertEpochCurrent, checkDeadline, checkFailureDeadline,
      // A winner can commit even during a failing model preflight. Only an
      // unaccepted attempt may observe that winner; it never acquires work.
      observeFailedInterpretation: () => !accepted && snapshot ? observeReplay(true) : null,
      accept: () => { accepted = true; },
      commitOnly,
      ...(hasCommitDispatcher(db) ? {
        commitOnlyAsync: () => dispatchCommit(db, commitOnly, deadline),
        observeReplayAsync: onlyRecorded => dispatchCommit(db, () => observeReplay(onlyRecorded), deadline),
        observeFailedInterpretationAsync: () => !accepted && snapshot
          ? dispatchCommit(db, () => observeReplay(true), deadline) : null,
      } : {}),
      result: () => { const row = accepted && rawEvent(input); return row ? JSON.parse(row.result) : null; },
      setStaging: staging => db.prepare(`UPDATE raw_capture_events SET staging=? WHERE ${where}`).run(staging, ...key(input)),
    });
  }

  function fenceSession(input) {
    object(input, ['namespace','client','sessionId']);
    const { client, sessionId } = input, namespace = rawNamespace(input.namespace);
    // Reuse the journal's strict namespace/client/session identity validation.
    const session = journal.sessionKey(namespace, client, sessionId);
    return transaction(db, () => {
      if (privacy) privacy.fenceInside(namespace,client,session);
      else db.prepare('INSERT OR IGNORE INTO raw_session_fences VALUES(?,?,?,?,?)')
        .run(...rawBoundary(namespace), client, session);
      return journal.closePending({ ownerId: namespace.ownerId, namespace, client, sessionKey: session, reason: 'capture_barrier' });
    });
  }
  function fenceArrival(arrivalToken) {
    if (!privacy) return;
    const input = arrivalInputs.get(arrivalToken);
    if (input && !input.decided) privacy.fenceArrival(input.namespace, input.client,
      journal.sessionKey(input.namespace, input.client, input.sessionId), input.messages);
  }
  async function prepareCapture(request, arrivalToken = {}, deadline) {
    // Validate and detach before any asynchronous sealing or model work.
    object(request, ['namespace','client','sessionId','eventId','messages',
      ...(profile.sessionEpisodes ? ['episodeContext'] : ['causal'])]);
    rawNamespace(request.namespace);
    const receivedAt = new Date().toISOString();
    const snapshot = captureSnapshot(request, profile.captureQualification, profile.captureSourcePolicy, true, receivedAt);
    // The inherited Raw layout supports two clients; other captures stay Memory-only.
    if (!['claude-code', 'codex'].includes(snapshot.client)) return null;
    const namespace = rawNamespace(snapshot.namespace);
    const session = journal.sessionKey(namespace, snapshot.client, snapshot.sessionId);
    const conversation = db.prepare(`SELECT id FROM raw_conversations WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key=?`)
      .get(...rawBoundary(namespace), snapshot.client, session);
    let ordinal = conversation ? db.prepare('SELECT coalesce(max(ordinal),0) n FROM raw_messages WHERE conversation_id=?').get(conversation.id).n : 0;
    const messages = snapshot.messages.map((message, index) => {
      const previous = conversation && db.prepare('SELECT ordinal,occurred_at FROM raw_messages WHERE conversation_id=? AND message_id=?').get(conversation.id, message.id);
      const content = request.messages[index].content;
      return { id: message.id, role: message.role, content,
        occurredAt: message.occurredAt ?? previous?.occurred_at ?? receivedAt,
        messageOrdinal: previous?.ordinal ?? ++ordinal,
        part: { index: 0, start: 0, totalUnits: content.length, totalBytes: Buffer.byteLength(content) } };
    });
    const rawRequest = { namespace: snapshot.namespace, client: snapshot.client, sessionId: snapshot.sessionId,
      eventId: snapshot.eventId, messages: messages.sort((a,b) => a.messageOrdinal - b.messageOrdinal), ...(snapshot.causal ? { causal: snapshot.causal } : {}),
      ...(profile.sessionEpisodes ? { episodeContext: structuredClone(request.episodeContext) } : {}) };
    const unknown = snapshot.messages.filter((message, index) => request.messages[index].occurredAt == null).map(message => message.id);
    return prepare(rawRequest, true, snapshot.messages.map(message => message.id), unknown, arrivalToken, deadline);
  }
  return Object.freeze({ ...journal, prepare, prepareCapture, fenceSession, fenceArrival,
    ...(authority ? { getLocalCaptureControl: authority.get, setLocalCaptureControl: authority.set } : {}) });
}
