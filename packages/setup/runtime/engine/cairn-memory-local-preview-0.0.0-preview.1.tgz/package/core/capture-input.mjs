import { createHash } from 'node:crypto';
import { boundedText, denseArray, fail, identifier, object, receiptEventTime, revision } from './validation.mjs';

const kinds = ['fact', 'preference', 'decision', 'instruction', 'context'];

/** Copy trusted identity and normalize every message before claiming or calling a model. */
export function captureSnapshot(input, captureQualification, captureSourcePolicy, retainTimes = true, now) {
  try {
    const namespace = { ownerId: input.namespace.ownerId, scope: input.namespace.scope,
      projectId: input.namespace.projectId };
    const client = identifier(input.client);
    const eventId = identifier(input.eventId);
    const sessionId = identifier(input.sessionId);
    let causal;
    if (input.causal !== undefined) {
      object(input.causal, ['streamId', 'sequence']);
      causal = { streamId: identifier(input.causal.streamId), sequence: revision(input.causal.sequence) };
    }
    const messages = denseArray(input.messages, 1, 24).map((message) => {
      object(message, ['id', 'role', 'content', 'occurredAt']);
      const id = identifier(message.id);
      const role = message.role;
      if (!['user', 'assistant'].includes(role)) fail('invalid_input');
      if ((captureQualification || captureSourcePolicy === 'indexed-evidence-v1') &&
          (typeof message.content !== 'string' || !message.content.isWellFormed())) {
        fail('invalid_input');
      }
      // Absence is optional; an explicitly supplied non-instant (including null) is invalid.
      if (Object.hasOwn(message, 'occurredAt') && message.occurredAt == null) fail('invalid_input');
      const occurredAt = receiptEventTime(message.occurredAt, now);
      return { id, role, content: boundedText(message.content, 4000),
        ...(retainTimes && occurredAt !== null ? { occurredAt } : {}) };
    });
    if (new Set(messages.map((message) => message.id)).size !== messages.length ||
        messages.reduce((sum, message) => sum + message.content.length, 0) > 20000) {
      fail('invalid_input');
    }
    const timed = messages.some(message => message.occurredAt !== undefined);
    const payloadDigest = createHash('sha256').update(JSON.stringify([
      captureSourcePolicy === 'indexed-evidence-v1' ? 'cairn.capture.indexed-evidence.v1' :
        captureSourcePolicy ? 'cairn.capture.indexed-windows.v1' :
        captureQualification ? 'cairn.capture.v3' : causal ? 'cairn.capture.v2' : 'cairn.capture.v1',
      [namespace.ownerId, namespace.scope, namespace.projectId],
      client, eventId, sessionId, messages.map(({ id, role, content, occurredAt }) =>
        [id, role, content, ...(timed ? [occurredAt ?? null] : [])]),
      ...(causal ? [[causal.streamId, causal.sequence]] : []),
      ...(captureQualification ? [captureQualification] : []),
      ...(captureSourcePolicy ? [captureSourcePolicy, 'nonoverlap-800-v1'] : []),
    ]), 'utf8').digest('hex');
    return { namespace, client, eventId, sessionId, messages, payloadDigest, ...(causal ? { causal } : {}),
      ...(captureQualification ? { captureQualification } : {}),
      ...(captureSourcePolicy ? { captureSourcePolicy } : {}) };
  } catch { fail('invalid_input'); }
}

/** Detached v2 evidence window. The complete snapshot and replay digest stay unchanged. */
export function retainedSourceView(snapshot) {
  try {
    const truncatedMessageIndices = [];
    const messages = snapshot.messages.map((message, index) => {
      const content = boundedText(boundedText(message.content, 800, true), 800, true);
      if (content !== message.content) truncatedMessageIndices.push(index);
      const { occurredAt, ...source } = message;
      return Object.freeze({ ...source, content });
    });
    return Object.freeze({ messages: Object.freeze(messages),
      retainedSourceWindow: Object.freeze({ maxUnitsPerMessage: 800,
        truncatedMessageIndices: Object.freeze(truncatedMessageIndices) }) });
  } catch { fail('invalid_input'); }
}

/** The extractor chooses indices; all receipt identity and text comes from the trusted source view. */
export function extractedItems(output, snapshot, retainedMessages, onInvalid = () => {}, sourceReceipts) {
  let reason = 'invalid_extraction_output_shape';
  try {
    const sourceMessages = retainedMessages ?? snapshot.messages;
    object(output, ['items']);
    return denseArray(output.items, 0, 5).map((item) => {
      reason = 'invalid_extraction_item_shape';
      object(item, ['content', 'kind', 'confidence', 'sourceIndices', ...(snapshot.sessionEpisodes ? ['procedural'] : [])]);
      if (Object.hasOwn(item, 'procedural') && (item.procedural !== true || !['preference','instruction'].includes(item.kind))) fail('invalid_model_output');
      reason = 'invalid_extraction_text';
      if ((snapshot.captureQualification || snapshot.captureSourcePolicy === 'indexed-evidence-v1') &&
          (typeof item.content !== 'string' || !item.content.isWellFormed())) {
        fail('invalid_model_output');
      }
      const content = boundedText(item.content, 600);
      reason = 'invalid_extraction_value';
      if (!kinds.includes(item.kind) || typeof item.confidence !== 'number' ||
          !Number.isFinite(item.confidence) || item.confidence < 0 || item.confidence > 1) {
        fail('invalid_model_output');
      }
      reason = 'invalid_extraction_source_shape';
      const indices = denseArray(item.sourceIndices, 1, 4);
      reason = 'invalid_extraction_source_duplicate';
      if (new Set(indices).size !== indices.length) fail('invalid_model_output');
      reason = 'invalid_extraction_source_range';
      if (indices.some((index) => !Number.isInteger(index) || index < 0 || index >= sourceMessages.length)) {
        fail('invalid_model_output');
      }
      const receipts = indices.map((index) => {
        const message = sourceMessages[index];
        return { client: sourceReceipts?.[index]?.client ?? snapshot.client,
          sessionId: sourceReceipts?.[index]?.sessionId ?? snapshot.sessionId,
          eventId: message.id, role: message.role,
          excerpt: retainedMessages === undefined ? boundedText(message.content, 800, true) : message.content };
      });
      return { content, kind: item.kind, confidence: item.confidence, receipts,
        ...(snapshot.sessionEpisodes && item.procedural === true ? { proceduralProposal: true } : {}),
        ...(snapshot.causal ? { sourceIndices: [...indices] } : {}) };
    });
  } catch {
    try { onInvalid(reason); } catch { /* Diagnostics never change validation. */ }
    fail('invalid_model_output');
  }
}
