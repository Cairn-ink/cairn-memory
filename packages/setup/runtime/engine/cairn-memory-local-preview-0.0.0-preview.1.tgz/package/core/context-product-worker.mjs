import { AsyncLocalStorage } from 'node:async_hooks';
import { types } from 'node:util';
import { maintenanceErrorName, maintenanceFailureCode, maintenanceIndexFailure } from './context-product-attribution.mjs';
import { createMaintenanceAttribution } from './context-product-attribution.mjs';
import { performance } from 'node:perf_hooks';
import { parentPort, workerData } from 'node:worker_threads';
import { serviceIssuance } from './context-product-service.mjs';
import { requestAuthority } from './context-product-authority.mjs';
import { nativeObserver, sealNative } from './context-product-telemetry.mjs';
import { PRODUCT_PROFILE, verifyRecords, boundedData, mono, issuance, deadline, operationRecord } from './context-product-control.mjs';
import { productFailure } from './context-product-reader.mjs';
import { createProductSqlitePolicy } from './context-product-sqlite.mjs';
import { fail } from './validation.mjs';
import { openDiagnosticClock, validOpenDiagnosticBuffer } from './context-product-open-diagnostic.mjs';

const workerFirst = validOpenDiagnosticBuffer(workerData.openPhases) ? process.hrtime.bigint() : undefined;
const phase = openDiagnosticClock(workerData.openPhases);
phase?.mark('workerFirst', workerFirst);
const { request, operation: opening, binding } = workerData;
let sidecarHandles;
let facade, index, host, active = false, disposing, currentControl = request;
let semanticTurn;
let semantic,semanticOutstanding,currentOperation=opening,booting=true,closing=false,rejectPermission,exiting;
const owned = [], resources = new Int32Array(workerData.resources);
const resourceOwner = Object.freeze({
  register(kind, close) {
    const at = kind === 'lease' ? 0 : kind === 'provider' ? 2 : -1;
    if (at < 0 || typeof close !== 'function' || owned.length >= 64) fail('invalid_input');
    Atomics.add(resources, at, 1); owned.push({ at, close });
  },
});
const attribution=workerData.maintenance ? createMaintenanceAttribution({buffer:workerData.maintenanceMarker}) : undefined;
const observer = nativeObserver(workerData.frame);
observer.journalRemainingMs = () => Number(mono(currentOperation.operationCutoffMonoNs) - process.hrtime.bigint()) / 1e6;
if (phase) observer.openDiagnostic = phase;
const sqlite = workerData.wal ? createProductSqlitePolicy({ observer }) : null;
const startSqlite = op => sqlite?.start(Number(mono(op.operationCutoffMonoNs)) / 1e6);

// Match the legacy native mapping without linking SQLite into bootstrap.
// Keep the initiating call and the first disposal failure independent.
let failureDetail,secondaryFailureDetail,disposalFailureDetail;
const noteFailure=(kind,engineCode,error,disposal=false,secondary=false,step=attribution?.stepKind??0)=>{if(!workerData.maintenance)return;const detail={kind,...(kind==='engine'||kind==='unmapped'?{engineCode:maintenanceFailureCode(engineCode)}:{}),
  ...(kind==='engine'&&engineCode==='index_unavailable'?maintenanceIndexFailure(error)??{reason:'other'}:{}),
  ...(kind==='protocol'?{protocolKind:'frame_conflict'}:{}),...(kind==='exception'?{errorName:maintenanceErrorName(error),step}:{})};if(secondary)secondaryFailureDetail??=detail;else if(disposal)disposalFailureDetail??=detail;else failureDetail??=detail;};
const nativeFailure = (error, disposal = false, secondary = false, step) => {
  const code=error?.code === 'ERR_SQLITE_ERROR'
    ? Number.isInteger(error.errcode) && [5,6].includes(error.errcode&255) ? 'storage_busy':'storage_error' : error?.code;
  const response=productFailure(code);
  if(!(closing&&code==='store_closed'))noteFailure(code===undefined?'exception':code===response.error.code?'engine':'unmapped',code,error,disposal,secondary,step);
  return response;
};
const within = op => { if (closing) fail('store_closed'); if (process.hrtime.bigint() >= mono(op.operationCutoffMonoNs)) fail('read_timeout'); };
function result(operation, result, extra = {}) {
  const secondary=!result.ok&&attribution?.takeSecondaryFailure();
  if(secondary)try{nativeFailure(secondary.error,false,true,secondary.step);}catch{noteFailure('exception',undefined,secondary.error,false,true,secondary.step);}
  const failure=workerData.maintenance&&!result.ok&&!(closing&&result.error?.code==='store_closed')?(attribution?.failure()??failureDetail):undefined;
  parentPort.postMessage({ operation, result, ...extra,...(failure?{maintenanceFailure:failure}:{}),...(!result.ok&&secondaryFailureDetail?{maintenanceSecondaryFailure:secondaryFailureDetail}:{}) });
}
function dispose() {
  return disposing ??= (async () => {
    let failed = false;
    const failedDisposal=error=>{if(workerData.maintenance&&!failed)nativeFailure(error,true);failed=true;};
    try { semantic?.close(); index?.close(); facade?.close(); } catch(error) {failedDisposal(error);}
    for (const resource of owned.reverse()) {
      try { await resource.close(); Atomics.add(resources, resource.at + 1, 1); } catch(error) {failedDisposal(error);}
    }
    if (failed){if(workerData.maintenance)secondaryFailureDetail={kind:'cleanup'};fail('reader_failed');}
  })();
}
// Close never races bootstrap acquisition or an outstanding asynchronous call.
function exitWhenIdle() {
  return exiting ??= (async () => {
    // A cached disposal promise owns its already-captured failure metadata.
    if(workerData.maintenance&&!disposing){attribution?.resetFailure();failureDetail=undefined;secondaryFailureDetail=undefined;}
    observer.select(workerData.frame);
    try { await dispose(); sealNative(workerData.frame); phase?.mark('disposed'); }
    catch { if(workerData.maintenance)try{parentPort.postMessage({kind:'maintenance-close-failure',maintenanceFailure:disposalFailureDetail,...(secondaryFailureDetail?{maintenanceSecondaryFailure:secondaryFailureDetail}:{})});}catch{}process.exitCode = 1; }
    parentPort.close();
  })();
}
parentPort.on('message', message => {
  if (message?.method !== 'close') return;
  closing = true; phase?.mark('closeReceived');
  rejectPermission?.(Object.assign(Error('store_closed'), { code: 'store_closed' }));
  if (!booting && !active) void exitWhenIdle();
});
function capabilities() {
  return { ok: true, value: { version: 'context-read-v1', profile: PRODUCT_PROFILE,
    methods: workerData.maintenance ? ['refreshContextIndex','getContextIndexStatus'] : ['findCandidates','contextRead','fetchCandidateEvidence','getContextIndexStatus'], types: facade.capabilities.types, intents: ['current', 'history'],
    receiptEventTime: facade.capabilities.receiptEventTime === true, execution: 'worker', hardResponseCutoff: true, cancellation: true, readSetMaximum: 32,
    namespaceSelection: 'recent-projects-v1', readyOnly: true, maintenance: Boolean(workerData.maintenance), assembly: index.assembly,
    channels: { lexical: { enabled: true }, semantic: { configured: false, enabled: false } },
    schemas: { memory: [18, ...Array.from({ length: 14 }, (_, i) => i + 20)], card: Array.from({ length: 11 }, (_, i) => i + 23) },
    ...(workerData.wal ? { journals: ['DELETE','WAL'], sidecarJournals: ['DELETE','WAL'], wal: {available:true} } : { journals: ['DELETE'], sidecarJournals: ['DELETE'], wal: {available:false,reason:'deferred_to_p2d'} }), unsupported: ['semantic', 'relations', 'moc', 'raw-search'] } };
}
try {
  startSqlite(opening);
  verifyRecords(request, opening, request, operationRecord(request, mono(request.admittedMonoNs), workerData.deadlineMs, 1, opening.operationId)); within(opening);
  if (workerData.maintenance) serviceIssuance(binding,workerData.readSet,workerData.ownerCoverage);
  else issuance(binding, request, workerData.readSet, workerData.ownerCoverage);
  phase?.mark('verified');
  const { contextProductFileIdentity } = await import('./read-database.mjs'); within(opening);
  phase?.mark('databaseImported');
  const fileIdentity = contextProductFileIdentity(workerData.path);
  phase?.mark('fileIdentified');
  const permission = new Promise((resolve, reject) => { rejectPermission = reject; parentPort.once('message', message => {
    try {
      if (message.kind !== 'identity-ack'){if(!closing)noteFailure('protocol');fail('reader_failed');}
      verifyRecords(request, message.operation, request, opening); sidecarHandles=message.sidecarHandles; resolve();
    } catch (error) { reject(error); }
  }); });
  phase?.mark('identitySent');
  parentPort.postMessage({ kind: 'identity', operation: opening, fileIdentity });
  await permission; rejectPermission = undefined; within(opening);
  phase?.mark('identityAcked');
  observer.identity = actual => { if (actual !== fileIdentity) fail('unsafe_database_file'); };
  const module = await import(workerData.host.moduleUrl); within(opening);
  phase?.mark('hostImported');
  host = await module.createContextReadHost(Object.freeze({ ...workerData.host.configuration, resourceOwner }));
  if (typeof host?.close === 'function') resourceOwner.register('lease', () => host.close());
  const authorize = (method,payload,credential) => requestAuthority(host,binding,currentControl)(method,payload,credential);
  if(workerData.semanticConfig) {
    const {semanticClient}=await import('./context-semantic-client.mjs'); within(opening);
    semantic=semanticClient(workerData.semanticPort,workerData.semanticConfig,()=>currentOperation,{semanticOutstanding:()=>semanticTurn?.getStore()?.semanticOutstanding});
  }
  within(opening);
  phase?.mark('hostCreated');
  const { openContextProductFacade } = await import('./context-read-facade.mjs'); within(opening);
  phase?.mark('facadeImported');
  phase?.mark('facadeOpening');
  facade = openContextProductFacade(workerData.path, { observer, authorize, sqlite });
  phase?.mark('facadeOpened');
  const { openProductIndex } = await import('./context-product-index.mjs'); within(opening);
  phase?.mark('indexImported');
  let comparison=null;
  if(workerData.memoryComparison===true){comparison=await import('./context-product-comparison.mjs');within(opening);}
  index = openProductIndex({path:workerData.path,facade,authorize,ownerCoverage:workerData.ownerCoverage,observer,sqlite,sidecarJournalMode:workerData.sidecarJournalMode,maintenance:workerData.maintenance,counter:host.counter,semantic,operation:()=>currentOperation,attribution,
    storageOptions:{sidecarHandles,memoryComparison:comparison,verificationBatching:workerData.verificationBatching===true,verificationBatchState:workerData.verificationBatchState}});
  phase?.mark('indexOpened');
  within(opening);
  // The opening telemetry remains unsealed until connection disposal.
  phase?.mark('openSent');
  result(opening, { ok: true, value: null }, { fileIdentity: facade.fileIdentity });
} catch (error) {attribution?.captureFailure(error);attribution?.selectFailure(error);
  const response=workerData.maintenance?nativeFailure(error):undefined;
  try { await dispose(); sealNative(workerData.frame); } catch { /* No seal: diagnostic coverage is incomplete. */ }
  result(opening, response??nativeFailure(error));
} finally {
  booting = false;
  if (closing) await exitWhenIdle();
}
parentPort.on('message', async message => {
  if (closing || message?.method === 'close') return;
  if (active || !facade) {failureDetail=undefined;secondaryFailureDetail=undefined;noteFailure('worker_state');result(message.operation, productFailure('reader_failed')); return;}
  active = true;failureDetail=undefined;secondaryFailureDetail=undefined;
  attribution?.reset(message.maintenanceOrdinal);
  const receivedAt=Number(process.hrtime.bigint())/1e6;
  if (message.method === 'fetchCandidateEvidence') phase?.mark('readReceived');
  const { operation, frame } = message;
  observer.select(frame);
  try {
    const callRequest = workerData.maintenance ? message.request : request;
    if (workerData.maintenance && (callRequest.clockDomainId !== request.clockDomainId || callRequest.credentialBindingId !== binding.credentialBindingId || callRequest.credentialExpiresUtcMs !== binding.credentialExpiresUtcMs)) fail('authority_required');
    verifyRecords(message.request, operation, callRequest, operationRecord(callRequest, mono(operation.enteredMonoNs),
      deadline(['refreshContextIndex','refreshMaintenance','admitMaintenance'].includes(message.method) ? message.input?.budget?.maxMs : message.input?.deadlineMs), opening.workerEpoch, operation.operationId));
    if (operation.workerEpoch !== opening.workerEpoch) fail('authority_required');
    if(Object.hasOwn(message,'semanticOutstanding')){
      if(!workerData.maintenance||!semantic||!types.isSharedArrayBuffer(message.semanticOutstanding)||message.semanticOutstanding.byteLength!==8)fail('authority_required');
      semanticTurn??=new AsyncLocalStorage();semanticOutstanding=message.semanticOutstanding;
    }else semanticOutstanding=undefined;
    currentControl = callRequest;
    currentOperation=operation;
    startSqlite(operation);
    within(operation);
    if (frame && (frame.operationId !== operation.operationId || frame.workerEpoch !== operation.workerEpoch)){noteFailure('protocol');fail('reader_failed');}
    let response;
    const observation = {};
    if (message.method === 'getContextReadCapabilities') {
      response = capabilities();
      if(semantic) {
        const access=requestAuthority(host,binding,currentControl)(message.method,message.input,message.credential),snapshot=await semantic.snapshot();
        const value=response.value;
        value.channels.semantic={configured:snapshot.identity!==null,enabled:snapshot.policy?.semantic??null};
        value.unsupported=value.unsupported.filter(x=>x!=='semantic');
        value.semanticExtension={version:'context-read-product-p2e-v1',ownerVectorPurge:true,queryEmbeddingMaximum:1,completeCoverageRequired:true,durableOwnerLedger:true,refreshBudgetDimensions:['maxItems','maxMs','maxUsd']};
        response=access.envelope(()=>response);
      }
    }
    else if (message.method === 'fetchCandidateEvidence') {
      if (workerData.maintenance) fail('authority_required');
      const payload = boundedData(message.input), { deadlineMs, ...fetchInput } = payload;
      deadline(deadlineMs);
      response = facade.fetchCandidateEvidence(fetchInput, message.credential, payload);
      phase?.mark('readFinished');
    } else {
      if(['admitMaintenance','refreshMaintenance'].includes(message.method)&&!workerData.maintenance)fail('authority_required');
      if (workerData.maintenance && !['getContextIndexStatus','refreshContextIndex','admitMaintenance','refreshMaintenance'].includes(message.method)) fail('authority_required');
      const run=()=>index.run(message.method, boundedData(message.input), message.credential,
        performance.now() + Number(mono(operation.operationCutoffMonoNs)-process.hrtime.bigint())/1e6, observation);
      response = await (semanticOutstanding===undefined?run():semanticTurn.run({semanticOutstanding},run));
    }
    if(!response.ok)try{index?.discard();}catch(error){nativeFailure(error,false,true);}
    if(attribution) {
      const preparationStarted=Number(process.hrtime.bigint())/1e6;
      within(operation);sealNative(frame);
      const {at,comparison,admission,...detail}=observation,metrics=attribution.snapshot();
      attribution.serialize(()=>result(operation,response,{...(admission?{maintenanceAdmission:admission}:{}),...(at===undefined?{}:{observedAtMonoMs:at}),
        ...(comparison?{comparison:response.ok?comparison:{status:'incomplete',cause:'operation_failed',rows:comparison.rows,bytes:comparison.bytes}}:{}),
        maintenancePhases:{...detail,...metrics,...(message.maintenanceOrdinal===null?{}:{ordinal:message.maintenanceOrdinal}),
          dispatchMs:receivedAt-Number(mono(operation.enteredMonoNs))/1e6,
          resultPreparationMs:metrics.resultPreparationMs+Number(process.hrtime.bigint())/1e6-preparationStarted,finishedAtMonoMs:Number(process.hrtime.bigint())/1e6}}));
    } else {
      within(operation);sealNative(frame);
      if (message.method === 'fetchCandidateEvidence') phase?.mark('readResultSent');
      result(operation,response,observation.at===undefined?{}:{observedAtMonoMs:observation.at,
        maintenancePhases:{...observation,at:undefined,dispatchMs:receivedAt-Number(mono(operation.enteredMonoNs))/1e6,finishedAtMonoMs:Number(process.hrtime.bigint())/1e6}});
    }
  } catch (error) {attribution?.captureFailure(error);attribution?.selectFailure(error);
    try{index?.discard();}catch(cleanupError){nativeFailure(cleanupError,false,true);}
    sealNative(frame); result(operation, nativeFailure(error)); }
  finally { semanticOutstanding=undefined; active = false; if (closing) await exitWhenIdle(); }
});
