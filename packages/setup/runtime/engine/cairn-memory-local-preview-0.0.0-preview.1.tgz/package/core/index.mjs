import { createMemoryRuntime } from "./runtime.mjs";
import {
  fail, identifier, limit, memoryInput, namespace, object, revision,
} from "./validation.mjs";

export { MemoryStoreError } from "./validation.mjs";
export { openMemoryCore } from "./contract.mjs";
export { openMemoryReader } from './memory-reader.mjs';
export { openContextReader } from './context-reader.mjs';
export { openContextProductReader, openContextIndexMaintainer } from './context-product-reader.mjs';
export { createContextReadSupervisor } from './context-read-supervisor.mjs';
export { renewContextMaintenancePump } from './context-product-pump.mjs';
// U5c-2 public configuration constants; storage readers remain internal.
export { CONTEXT_SOURCES, SOURCE_LIMITS } from './context-read-input.mjs';

/** Embedded storage only. The caller, not this library, authenticates owners. */
export function openMemoryStore(input) {
  object(input, ["path", "sessionEpisodes"]);
  const runtime = createMemoryRuntime(input);

  function bindScope(input) {
    runtime.ready();
    const ns = namespace(input);

    return Object.freeze({
      remember(input) {
        runtime.ready();
        const tagged = input !== null && typeof input === 'object' && Object.hasOwn(input, 'procedural');
        const { procedural, ...memory } = tagged ? input : {};
        const value = memoryInput(tagged ? memory : input);
        return runtime.admit(ns, { ...value, receipts: [value.receipt],
          ...(tagged ? { procedural } : {}) },
          { legacy: true }).legacyMemory;
      },

      get(id) {
        runtime.ready();
        return runtime.legacyGet(ns, identifier(id));
      },

      list(options = {}) {
        runtime.ready();
        object(options, ["limit"]);
        return runtime.legacyList(ns, limit(options.limit));
      },

      search(query, options = {}) {
        runtime.ready();
        object(options, ["limit"]);
        const count = limit(options.limit);
        if (typeof query !== "string" || query.length > 4_000) fail("invalid_query");
        const terms = [...new Set(query.normalize("NFKC").toLowerCase()
          .match(/[\p{L}\p{N}]+/gu) ?? [])];
        if (terms.length === 0) return [];
        return runtime.legacySearch(ns, terms, count);
      },

      correct(id, input, expectedRevision) {
        runtime.ready();
        identifier(id);
        revision(expectedRevision);
        const value = memoryInput(input);
        if (value.origin !== "explicit") fail("correction_must_be_explicit");
        return runtime.correct(ns, id,
          { ...value, receipts: [value.receipt] }, expectedRevision, { legacy: true }).legacyMemory;
      },

      forget(id, expectedRevision) {
        runtime.ready();
        identifier(id);
        revision(expectedRevision);
        return runtime.forget(ns, id, expectedRevision).forgotten;
      },
    });
  }

  return Object.freeze({ scope: bindScope, close: runtime.close });
}

export { profileRef as roleProfileRef, releaseRef as roleProfileReleaseRef } from './role-profile-input.mjs';
export { roleTaskMeteredText, roleTaskToolResponse } from './role-context-wire.mjs';

// U5c-3: dependency authoring remains under explicit Card confirmation authority.
export { CARD_CURRENT_VERSION, CARD_CURRENT_METHODS } from './card-current-input.mjs';

export { selectContextProductNamespaces } from './context-product-selection.mjs';
