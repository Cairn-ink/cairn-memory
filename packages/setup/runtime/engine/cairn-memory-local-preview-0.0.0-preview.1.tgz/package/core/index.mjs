import { withContentSuppressionRequest } from './content-suppression-storage.mjs';
import { contentSafetyFacade } from './content-safety-boundary.mjs';
import { createMemoryRuntime } from "./runtime.mjs";
// This entry already loads the SQLite engine. Register the optional Raw
// implementation in its installed module closure; evaluation opens no files.
// The separately imported Raw factory keeps its selection-gated dependencies.
import './raw-search-authority.mjs';
import './raw-search-storage.mjs';
import './raw-search-maintenance.mjs';
import './raw-search-retrieval.mjs';
import {
  fail, identifier, limit, memoryInput, namespace, object, revision,
  normalizeBoundedText as normalizeBoundedTextWithGuard,
} from "./validation.mjs";

export { MemoryStoreError, normalizedTextLength } from "./validation.mjs";
/** Public one-argument form: callers cannot change the raw-length guard. */
export function normalizeBoundedText(value) {
  return normalizeBoundedTextWithGuard(value);
}
export { openMemoryCore } from "./contract.mjs";
export { openMemoryReader } from './memory-reader.mjs';
export { openContextReader } from './context-reader.mjs';
export { openRawSearch } from './raw-search-index.mjs';
export { openContentSuppressionReader } from './content-suppression-reader.mjs';
export { openContextProductReader, openContextIndexMaintainer } from './context-product-reader.mjs';
export { createContextReadSupervisor, createContextReaderPool } from './context-read-supervisor.mjs';
export { renewContextMaintenancePump } from './context-product-pump.mjs';
export { openContextSemanticCoordinator } from './context-semantic-coordinator.mjs';
// U5c-2 public configuration constants; storage readers remain internal.
export { CONTEXT_SOURCES, SOURCE_LIMITS } from './context-read-input.mjs';

/** Embedded storage only. The caller, not this library, authenticates owners. */
export function openMemoryStore(input) {
  object(input, ["path", "sessionEpisodes", "contentSafety", "busyTimeoutMs"]);
  const runtime = createMemoryRuntime(input);

  function bindScope(input) {
    runtime.ready();
    const ns = namespace(input);

    return contentSafetyFacade({
      remember(input) {
        runtime.ready();
        const tagged = input !== null && typeof input === 'object' && Object.hasOwn(input, 'procedural');
        const { procedural, ...memory } = tagged ? input : {};
        const value = memoryInput(tagged ? memory : input);
        return runtime.admit(ns, { ...value, receipts: [value.receipt],
          ...(tagged ? { procedural } : {}) },
          { legacy: true }).legacyMemory;
      },

      get(id) {
        runtime.ready();
        return runtime.legacyGet(ns, identifier(id));
      },

      list(options = {}) {
        runtime.ready();
        object(options, ["limit"]);
        return runtime.legacyList(ns, limit(options.limit));
      },

      search(query, options = {}) {
        runtime.ready();
        object(options, ["limit"]);
        const count = limit(options.limit);
        if (typeof query !== "string" || query.length > 4_000) fail("invalid_query");
        const terms = [...new Set(query.normalize("NFKC").toLowerCase()
          .match(/[\p{L}\p{N}]+/gu) ?? [])];
        if (terms.length === 0) return [];
        return runtime.legacySearch(ns, terms, count);
      },

      correct(id, input, expectedRevision) {
        runtime.ready();
        identifier(id);
        revision(expectedRevision);
        const value = memoryInput(input);
        if (value.origin !== "explicit") fail("correction_must_be_explicit");
        return runtime.correct(ns, id,
          { ...value, receipts: [value.receipt] }, expectedRevision, { legacy: true }).legacyMemory;
      },

      forget(id, expectedRevision) {
        runtime.ready();
        identifier(id);
        revision(expectedRevision);
        return runtime.forget(ns, id, expectedRevision).forgotten;
      },
    }, { check: runtime.assertContentScope, select: () => ns,
      requestScope: (work, method) => ['get','list','search'].includes(method) ? withContentSuppressionRequest(work) : work(),
      failure(error, method) { if (error.code !== 'memory_not_found') throw error;
        if (method === 'get') return null; if (['list','search'].includes(method)) return []; throw error; } });
  }

  return Object.freeze({ scope: bindScope, close: runtime.close });
}

export { profileRef as roleProfileRef, releaseRef as roleProfileReleaseRef } from './role-profile-input.mjs';
export { roleTaskMeteredText, roleTaskToolResponse } from './role-context-wire.mjs';

// U5c-3: dependency authoring remains under explicit Card confirmation authority.
export { CARD_CURRENT_VERSION, CARD_CURRENT_METHODS } from './card-current-input.mjs';

export { selectContextProductNamespaces } from './context-product-selection.mjs';
