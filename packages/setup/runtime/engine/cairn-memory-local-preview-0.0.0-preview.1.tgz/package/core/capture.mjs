import { readFileSync } from 'node:fs';
import { isStorageBusy } from './database.mjs';
import { releaseStagedCaptureClaim } from './commit-dispatch.mjs';
import { withContentSuppressionRequest } from './content-suppression-storage.mjs';
import { isCaptureSourceBusy, isPreDispatchToken } from './capture-source-safety.mjs';
import { routeDocumentCards } from './document-card.mjs';
import { captureSnapshot, extractedItems, retainedSourceView, extractionLimit, quantityInstructions } from './capture-input.mjs';
import { callModel } from './model-call.mjs';
import { fittingCap, prefixUnits, requestFits } from './model-packing.mjs';
import { boundedText, fail, MemoryStoreError } from './validation.mjs';
import { emitDiagnostic } from './model-diagnostics.mjs';
import { reconcileCapture } from './ordered-capture.mjs';
import { qualifyExtractedItems } from './automatic-qualification.mjs';
import { qualifyCandidateItems } from './qualification-candidates.mjs';
import { reviewCapturedRationale } from './automatic-rationale.mjs';
import { extractedWindowItems, sourceWindowCatalog } from './source-windows.mjs';

const system = readFileSync(new URL('./prompts/extract-memories.md', import.meta.url), 'utf8');
const retainedSystem = readFileSync(new URL('./prompts/extract-retained-sources.md', import.meta.url), 'utf8');
const episodeSystem = readFileSync(new URL('./prompts/extract-episode-sources.md', import.meta.url), 'utf8');
const windowSystem = readFileSync(new URL('./prompts/extract-source-windows.md', import.meta.url), 'utf8');
const unwrap = (result) => { if (!result.ok) fail(result.error.code); return result.value; };

async function classifyAdmission(model, namespace, admission, operations, key, deadline, keep = false) {
  if (!admission.memories.length) return { status: 'skipped', reason: 'empty' };
  let attemptToken;
  try {
    deadline?.check();
    const guards = [];
    for (const admitted of admission.memories) {
      const inspected = operations.get({ namespace, memoryId: admitted.id });
      if (!inspected.ok && inspected.error.code === 'memory_not_found' && operations.isAwaiting?.(admitted.id)) continue;
      const { memory } = unwrap(inspected);
      if (memory.revision !== admitted.revision) fail('revision_conflict');
      if (memory.filing.status === 'unfiled') guards.push({ memoryId: admitted.id, revision: admitted.revision });
    }
    // Keep has its own durable admission identity; placement uses the same revision guards.
    const start = () => operations.beginInitialClassification({ ...key,
      admitted: admission.memories.map(({ id, revision }) => ({ memoryId: id, revision })),
      selected: guards });
    const started = keep ? { skipped: !guards.length } : unwrap(operations.commit ? await operations.commit(start) : start());
    if (started.skipped) return { status: 'skipped', reason: 'already_filed' };
    attemptToken = started.token;
    deadline?.check();
    if (typeof model?.classify !== 'function') {
      emitDiagnostic(model, 'classify', 'core_call', 'model_not_configured');
      fail('model_not_configured');
    }
    const readMap = () => operations.map({ namespace, purpose: 'classification' });
    const mapped = unwrap(operations.commit ? await operations.commit(readMap) : readMap());
    deadline?.check();
    // Placement requests retain their five-memory schema and output budget.
    const classified = { proposal: { items: [] }, basedOn: { memoryRevisions: [], indexRevision: mapped.indexRevision } };
    for (let start = 0; start < guards.length; start += 5) {
      const group = guards.slice(start, start + 5);
      const part = unwrap(await operations.classifyPlacement({ namespace,
        memoryIds: group.map(guard => guard.memoryId), expectedMemoryRevisions: group,
        mapRevision: mapped.indexRevision }));
      classified.proposal.items.push(...part.proposal.items);
      classified.basedOn.memoryRevisions.push(...part.basedOn.memoryRevisions);
      if (part.classificationTruncated) {
        classified.classificationTruncated ??= { memoriesShortened: 0, catalogItemsOmitted: 0 };
        classified.classificationTruncated.memoriesShortened += part.classificationTruncated.memoriesShortened;
        classified.classificationTruncated.catalogItemsOmitted = Math.max(
          classified.classificationTruncated.catalogItemsOmitted, part.classificationTruncated.catalogItemsOmitted);
      }
    }
    deadline?.check();
    const apply = keep ? operations.applyPlacement : operations.applyInitialPlacement;
    const place = () => apply({ ...(keep ? { namespace } : { ...key, token: attemptToken }),
      proposal: classified.proposal,
      expectedMemoryRevisions: classified.basedOn.memoryRevisions,
      expectedIndexRevision: classified.basedOn.indexRevision });
    const placed = unwrap(operations.commit ? await operations.commit(place) : place());
    return { status: 'applied', memoryRevisions: placed.memories.map((memory) =>
      ({ memoryId: memory.id, revision: memory.revision })), indexRevision: placed.indexRevision,
    ...(classified.classificationTruncated ? { classificationTruncated: classified.classificationTruncated } : {}) };
  } catch (error) {
    if (attemptToken) {
      try { const failAttempt = () => operations.failInitialClassification({ ...key, token: attemptToken });
        unwrap(operations.commit ? await operations.commit(failAttempt, { compensating: true }) : failAttempt()); }
      catch { /* A failed receipt write cannot replace the original failure. */ }
    }
    const code = error instanceof MemoryStoreError ? error.code : 'classification_failed';
    return { status: 'failed', error: { code, retryable: code === 'storage_busy' } };
  }
}

/** The exact extraction request for a snapshot under one capture configuration. */
export function extractionRequest(snapshot, { captureQualification, captureSourcePolicy, episode = false }) {
  const catalog = captureSourcePolicy ? sourceWindowCatalog(snapshot) : null;
  const retained = !catalog && captureQualification === 'source-bound-v2' ? retainedSourceView(snapshot) : null;
  const sourceMessages = retained?.messages ?? snapshot.messages;
  const instructions = episode ? episodeSystem : catalog ? windowSystem : retained ? retainedSystem : system;
  return { catalog, retained, sourceMessages,
    system: snapshot.ledger ? instructions + '\n' + quantityInstructions : instructions,
    input: catalog?.input ?? { messages: sourceMessages.map(({ role, content }, index) => ({ index, role, content })) } };
}

/**
 * Whether an extraction request fits, counted exactly as the guarded call
 * counts it; null when the port is missing or misconfigured, which the
 * guarded call reports itself.
 */
export function extractionFits(model, request) {
  if (typeof model?.extract !== 'function' || !Number.isSafeInteger(model.contextWindow) ||
      model.contextWindow < 8192) return null;
  return requestFits(model, 'extract')(request.system, request.input);
}

// A submitted batch whose extraction request cannot fit is an input error,
// refused before any claim, staging, write or provider call. Hosts split
// batches with core.planCaptureBatches, which uses this same measurement.
export function checkExtractionFits(model, request) {
  if (extractionFits(model, request) !== false) return;
  emitDiagnostic(model, 'extract', 'core_call', 'context_budget_exceeded');
  fail('context_budget_exceeded');
}

// Keep extracts from an existing episode's staged sources, which the host did
// not size. When they cannot fit, every source stays in the request with its
// text cut to a common prefix of at least 120 units, and the result says so.
function keepRequest(model, request, deadline) {
  if (extractionFits(model, request) !== false) return { request, shortened: 0 };
  const fits = requestFits(model, 'extract', deadline);
  const messages = request.input.messages;
  const view = (cap) => ({ ...request.input, messages: messages.map((message) =>
    ({ ...message, content: prefixUnits(message.content, cap) })) });
  const cap = fittingCap(Math.max(...messages.map((message) => message.content.length)),
    (units) => fits(request.system, view(units)));
  if (cap === null) return { request, shortened: 0 };
  return { request: { ...request, input: view(cap) },
    shortened: messages.filter((message) => message.content.length > cap).length };
}

/** Public-envelope operations own all transactions; no model work runs inside them. */
export async function captureMessages({ model, input, operations, captureQualification,
  captureSourcePolicy, captureRationale, captureEvidence, deadline, episodeRun, rawRegistration, runtime, ns, ledger, documentMessages, documentSessionId }) {
  deadline?.check();
  // The default Raw capture registration already supplies each message's
  // explicit or receive time; captureRaw and Raw-free captures keep their input.
  let snapshot = episodeRun?.snapshot ?? captureSnapshot(input, captureQualification, captureSourcePolicy);
  if (!episodeRun && snapshot.messages.some(message => message.occurredAt !== undefined)) {
    snapshot = runtime.captureSnapshot(ns, snapshot, captureQualification, captureSourcePolicy);
  }
  deadline?.check();
  if (ledger) snapshot = { ...snapshot, ledger: true };
  let request = extractionRequest(snapshot, { captureQualification, captureSourcePolicy, episode: Boolean(episodeRun) });
  let { catalog, retained, sourceMessages } = request;
  sourceMessages = catalog?.messages ?? sourceMessages;
  deadline?.check();
  if (!episodeRun) checkExtractionFits(model, request);
  let extractionTruncated;
  if (episodeRun?.keep) {
    const kept = keepRequest(model, request, deadline);
    request = kept.request;
    if (kept.shortened) extractionTruncated = { messagesShortened: kept.shortened };
  }
  // Retention coverage of this submitted snapshot, not an attestation of which
  // extraction policy executed an earlier duplicate batch.
  const coverage = { ...(catalog?.coverage ?? (retained ? { retainedSourceWindow: retained.retainedSourceWindow } : {})),
    ...(captureSourcePolicy === 'indexed-evidence-v1' ? { qualificationStatus: 'not-requested' } : {}) };
  const key = { namespace: snapshot.namespace, client: snapshot.client,
    eventId: snapshot.eventId, payloadDigest: snapshot.payloadDigest };
  const identities = sourceMessages.map((message, index) => ({
    client: snapshot.sourceReceipts?.[index]?.client ?? snapshot.client,
    sessionId: snapshot.sourceReceipts?.[index]?.sessionId ?? snapshot.sessionId,
    eventId: message.id, role: message.role, excerpt: message.content,
  }));
  const claimWork = () => snapshot.causal ? operations.ordered.claim(snapshot, identities)
    : captureEvidence ? operations.claimCaptureEvidence({ ...key, view: retained }, identities)
      : operations.claimAdmission({ ...key, leaseMs: 125000 }, identities);
  const claim = episodeRun ? episodeRun.claim : unwrap(operations.commit ? await operations.commit(claimWork) : claimWork());
  if (claim.rawReplay) return claim.rawReplay;
  if (claim.processing || claim.duplicate) return { ...claim, ...coverage,
    ...(captureRationale ? { rationale: { status: 'not-run', reason: claim.processing ? 'processing' : 'duplicate',
      previousOutcome: 'unavailable' } } : {}) };
  const owned = { ...key, token: claim.token };
  const qualificationReport = {};
  let finished, stagedDispatched = false;
  try {
    const allowed = operations.filterCaptureSources?.(identities) ?? identities.map((_, index) => index);
    if (!allowed.length && !episodeRun?.skip) fail('source_excluded');
    const selected = allowed.map(index => identities[index]);
    const assertSources = () => operations.assertCaptureSources?.(selected);
    const documentCards = documentMessages && { sources: selected,
      ...routeDocumentCards(snapshot.namespace, snapshot.client, documentSessionId ?? snapshot.sessionId,
        documentMessages.filter(message => selected.some(source => source.eventId === message.id && source.role === message.role))) };
    const sourceView = allowed.length === identities.length ? undefined : allowed.map(index => ({
      index: catalog ? catalog.entries[index].messageIndex : index,
      role: sourceMessages[index].role, content: sourceMessages[index].content,
    }));
    sourceMessages = allowed.map(index => sourceMessages[index]);
    if (catalog) {
      catalog = { ...catalog, entries: allowed.map((index, position) => ({ ...catalog.entries[index], index: position })),
        messages: sourceMessages };
      request = { ...request, input: { ...request.input,
        messages: allowed.map((index, position) => ({ ...request.input.messages[index], index: position })) } };
    } else request = { ...request, input: { ...request.input,
      messages: allowed.map((index, position) => ({ ...request.input.messages[index], index: position })) } };
    deadline?.check();
    const output = episodeRun?.skip ? { items: [] } : await callModel(model, 'extract', request.system, request.input,
      { failureCode: 'extraction_failed', deadline, validateFresh: assertSources,
        beforeDispatch: () => {
          if (isPreDispatchToken(owned.token)) {
            owned.token = operations.beginCaptureDispatch(owned).token;
            stagedDispatched = true;
            deadline?.check();
          }
        } });
    let items = catalog ? extractedWindowItems(output, snapshot, catalog,
      reason => emitDiagnostic(model, 'extract', 'core_validation', reason), extractionLimit(request.input.messages)) : extractedItems(output, snapshot,
      retained ? sourceMessages : sourceMessages.map(message => ({ ...message, content: boundedText(message.content, 800, true) })),
      reason => emitDiagnostic(model, 'extract', 'core_validation', reason), selected);
    if (!catalog && snapshot.causal) for (const item of items) item.sourceIndices = item.sourceIndices.map(index => allowed[index]);
    deadline?.check();
    // Do not start another interpretation stage after explicit discard/forget.
    // A provider request already in flight cannot be recalled by local deletion.
    if (captureEvidence) unwrap(operations.assertCaptureEvidence(owned));
    if (captureQualification && items.length) items = captureQualification === 'source-bound-v2'
      ? await qualifyCandidateItems(model, items, deadline,
        () => { assertSources(); if (captureEvidence) unwrap(operations.assertCaptureEvidence(owned)); }, Boolean(episodeRun),
        qualificationReport)
      : await qualifyExtractedItems(model, items, deadline, qualificationReport, assertSources);
    // Join only each receipt's own trusted message; session clocks and Raw never enter here.
    for (const item of items) {
      const times = item.receipts.map(receipt =>
        snapshot.messages.find(message => message.id === receipt.eventId)?.occurredAt ?? null);
      if (times.some(time => time !== null)) item.receiptTimes = times;
    }
    deadline?.check();
    if (snapshot.causal) {
      const prepared = unwrap(operations.ordered.prepare(snapshot, claim.order, items));
      deadline?.check();
      const judged = captureQualification
        ? { decisions: [], reason: items.length ? 'qualification_requires_identity' : null }
        : await reconcileCapture({ model, snapshot, items, discovery: prepared.discovery, deadline, validateFresh: () => { assertSources(); unwrap(operations.ordered.assertPrepared(snapshot, claim.order, prepared)); }, sourceView });
      deadline?.check();
      const finish = () => operations.ordered.finish(documentCards ? { ...snapshot, documentCards } : snapshot, claim.token, claim.order, prepared, judged);
      finished = unwrap(operations.commit ? await operations.commit(finish) : finish());
    } else {
      const finish = () => operations.finishAdmission({ ...owned, items: items.map(({ receiptTimes, ...item }) =>
      receiptTimes ? { ...item, receipts: item.receipts.map((receipt, index) =>
        ({ ...receipt, occurredAt: receiptTimes[index] })) } : item) }, documentCards);
      finished = unwrap(operations.commit ? await operations.commit(finish) : finish());
    }
  } catch (error) {
    // A failed or stale cleanup cannot replace the original error or release a successor's claim.
    try { if (operations.commit && captureEvidence === 'staged-v1' && !episodeRun &&
        error instanceof MemoryStoreError && error.code === 'evidence_unavailable') {
      await releaseStagedCaptureClaim(runtime, owned);
    } else { const abandon = () => operations.abandonAdmission(owned, (isCaptureSourceBusy(error) && !stagedDispatched) || Boolean(episodeRun &&
      (isStorageBusy(error) || (error instanceof MemoryStoreError && error.code === 'storage_busy'))));
      if (operations.commit) await operations.commit(abandon, { compensating: true }); else abandon();
    }
    } catch { /* Pre-dispatch staged tokens remain reclaimable without cleanup. */ }
    if (error instanceof MemoryStoreError) throw error;
    if (episodeRun && isStorageBusy(error)) fail('storage_busy');
    fail(episodeRun?.keep ? 'storage_error' : 'extraction_failed');
  }
  const admission = { ...(episodeRun ? { status: 'completed' } : {}),
    memories: finished.memories, suppressedCount: finished.suppressedCount, indexRevision: finished.indexRevision };
  const classification = operations.commit
    ? await withContentSuppressionRequest(() => classifyAdmission(model, snapshot.namespace, admission, operations, key, deadline, episodeRun?.keep))
    : await classifyAdmission(model, snapshot.namespace, admission, operations, key, deadline, episodeRun?.keep);
  const rationale = captureRationale ? await reviewCapturedRationale({ snapshot, admission,
    classification, sourceMessages, operations, deadline }) : undefined;
  const { itemsShortened, itemsUnqualified } = qualificationReport;
  return { duplicate: false, admission, classification,
    ...(captureRationale ? { rationale } : {}),
    ...coverage,
    ...(finished.documentCards ? { documentCards: finished.documentCards } : {}),
    ...(finished.reconciliation ? { reconciliation: finished.reconciliation } : {}),
    ...(itemsShortened || itemsUnqualified
      ? { qualificationTruncated: { itemsShortened, itemsUnqualified, reason: 'context_budget' } } : {}),
    ...(extractionTruncated ? { extractionTruncated } : {}) };
}
