import { createHmac } from 'node:crypto';
import { fail } from './validation.mjs';
import { cachedContentLayout } from './content-safety-schema.mjs';
import { purgeUnreadableMemoryRelationsInside as purgeUnreadableMemoryRelations } from './content-safety-schema.mjs';

const where = 'owner_id=? AND scope=? AND project_id=?';
const boundary = ns => [ns.ownerId, ns.scope, ns.projectId || ''];
const receiptValue = row => ({ client: row.client, sessionId: row.session_id,
  eventId: row.event_id, role: row.role, excerpt: row.excerpt });

// One exact/hashed alias rule for both SQL readers and projected Episode proof.
export function rawSessionKeys(ns, client, value, secret) {
  return [value, 's1:' + createHmac('sha256', Buffer.from(secret, 'hex'))
    .update(JSON.stringify(['episode-v1', ...boundary(ns), client, value])).digest('hex')];
}

/** Source-session authority shared by deletion, admission and option-off writers. */
export function createRawSourceRoots(db, { readMemo } = {}) {
  let available;
  let episodeMutation, fences, jobs;
  const hasFences = () => fences === true || (fences = Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE name='raw_session_fences'").get()));
  const hasJobs = () => jobs === true || (jobs = Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE name='raw_job_sources'").get()));
  const enabled = () => available === true || (available = Boolean(db.prepare(
    "SELECT 1 FROM sqlite_master WHERE name='raw_deletion_actions'").get()));
  const hashSession = (ns, client, value) => rawSessionKeys(ns, client, value,
    db.prepare('SELECT secret FROM episode_identity WHERE singleton=1').get().secret)[1];
  const keys = (ns, client, value) => [value, hashSession(ns, client, value)];
  function assertSession(ns, client, value, readExisting = false) {
    if (readExisting ? !hasFences() : !enabled()) return;
    const key = JSON.stringify(['session-fence', ...boundary(ns), client, value]);
    if (readExisting && readMemo?.has(key)) return;
    for (const session of keys(ns, client, value)) if (db.prepare(
      `SELECT 1 FROM raw_session_fences WHERE ${where} AND client=? AND session_key=?`)
      .get(...boundary(ns), client, session)) fail('conversation_deleted');
    if (readExisting) readMemo?.set(key, true);
  }
  function emptySession(ns, row) {
    if (!readMemo) return false;
    const key = JSON.stringify(['empty-session', ...boundary(ns), row.client, row.session_id]);
    if (readMemo.has(key)) return readMemo.get(key);
    const args = [...boundary(ns), row.client, ...keys(ns, row.client, row.session_id)];
    const jobs = hasJobs();
    const found = db.prepare(`SELECT 1 FROM raw_conversations WHERE ${where} AND client=? AND session_key IN (?,?)
      UNION ALL SELECT 1 FROM session_episodes WHERE ${where} AND client=? AND session_key IN (?,?)
      ${jobs ? `UNION ALL SELECT 1 FROM raw_job_sources WHERE ${where} AND source_client=? AND session_key IN (?,?)` : ''} LIMIT 1`)
      .get(...args, ...args, ...(jobs ? args : []));
    readMemo.set(key, !found); return !found;
  }
  function resolve(ns, value, readExisting = false) {
    if (!readExisting && !enabled()) return [];
    const sessions = keys(ns, value.client, value.sessionId), found = new Map();
    const add = row => {
      const root = found.get(row.session_key) ?? { client: value.client, sessionKey: row.session_key };
      if (row.conversation_id) root.conversationId = row.conversation_id;
      if (row.episode_id) root.episodeId = row.episode_id;
      found.set(row.session_key, root);
    };
    for (const session of sessions) {
      const raw = db.prepare(`SELECT c.id AS conversation_id,c.session_key FROM raw_conversations c
        JOIN raw_messages m ON m.conversation_id=c.id WHERE c.owner_id=? AND c.scope=? AND c.project_id=?
        AND c.client=? AND c.session_key=? AND m.message_id=?`).get(...boundary(ns), value.client, session, value.eventId);
      if (raw) add(raw);
      const episode = db.prepare(`SELECT e.id AS episode_id,e.session_key FROM session_episodes e
        WHERE e.owner_id=? AND e.scope=? AND e.project_id=? AND e.client=? AND e.session_key=? AND e.deleted=0
        AND (EXISTS(SELECT 1 FROM episode_messages m WHERE m.episode_id=e.id AND m.message_id=?)
          OR EXISTS(SELECT 1 FROM episode_sources s WHERE s.origin_episode_id=e.id AND s.message_id=?))`)
        .get(...boundary(ns), value.client, session, value.eventId, value.eventId);
      if (episode) add(episode);
      if ((!readExisting || hasJobs()) && db.prepare(`SELECT 1 FROM raw_job_sources WHERE ${where} AND source_client=? AND session_key=? AND message_id=?`)
        .get(...boundary(ns), value.client, session, value.eventId)) add({ session_key: session });
    }
    if (found.size > 1) fail('raw_lineage_unavailable');
    return [...found.values()];
  }
  function receipt(ns, row, readExisting = false) {
    const stored = db.prepare(`SELECT DISTINCT c.id AS conversationId,c.client,c.session_key AS sessionKey
      FROM raw_receipt_lineage l JOIN raw_conversations c ON c.id=l.conversation_id
      WHERE l.receipt_id=? AND c.owner_id=? AND c.scope=? AND c.project_id=?`).all(row.id, ...boundary(ns));
    if (!stored.length) {
      const kept = keepReceipt(ns, row);
      if (kept) return kept;
    }
    const values = stored.length ? stored : resolve(ns, receiptValue(row), readExisting);
    // Existing real receipt IDs can prove older batch-based episode receipts.
    if (!values.length) {
      const linked = db.prepare(`SELECT DISTINCT e.id AS episode_id,e.client,e.session_key FROM episode_memory_links l
        JOIN session_episodes e ON e.id=l.episode_id JOIN json_each(l.receipt_ids) r
        WHERE e.owner_id=? AND e.scope=? AND e.project_id=? AND e.deleted=0 AND r.value=?
          AND e.client=? AND e.session_key IN (?,?)`).all(...boundary(ns), row.id, row.client,
        ...keys(ns, row.client, row.session_id).slice(0,2));
      for (const item of linked) values.push({ client: item.client, sessionKey: item.session_key, episodeId: item.episode_id });
      if (new Set(values.map(item => item.sessionKey)).size > 1) fail('raw_lineage_unavailable');
    }
    const independent = !values.length && db.prepare('SELECT kind FROM raw_receipt_origins WHERE receipt_id=?')
      .get(row.id)?.kind === 'independent';
    return { roots: values, independent, unknown: !values.length && !independent };
  }
  function keepReceipt(ns, row) {
    const actions = db.prepare(`SELECT DISTINCT a.keep_source_ids FROM episode_memory_links l
      JOIN json_each(l.receipt_ids) r JOIN episode_keep_actions a ON a.episode_id=l.episode_id AND a.event_id=l.event_id
      JOIN session_episodes e ON e.id=l.episode_id WHERE r.value=? AND l.memory_id=?
      AND e.owner_id=? AND e.scope=? AND e.project_id=? AND a.owner_id=? AND a.scope=? AND a.project_id=?`)
      .all(row.id, row.memory_id, ...boundary(ns), ...boundary(ns));
    if (!actions.length) return null;
    const found = new Map(); let missing = false;
    for (const action of actions) {
      let ids;
      try { ids = JSON.parse(action.keep_source_ids); } catch { missing = true; continue; }
      if (!Array.isArray(ids) || !ids.length || ids.length > 16 || new Set(ids).size !== ids.length ||
          ids.some(id => typeof id !== 'string')) { missing = true; continue; }
      const sources = db.prepare(`SELECT s.message_id,s.role,e.id AS episodeId,e.client,e.session_key AS sessionKey
        FROM json_each(?) j JOIN episode_sources s ON s.id=j.value JOIN session_episodes e ON e.id=s.origin_episode_id
        WHERE e.owner_id=? AND e.scope=? AND e.project_id=?`).all(action.keep_source_ids, ...boundary(ns));
      if (sources.length !== ids.length) missing = true;
      const selected = sources.filter(source => source.message_id === row.event_id && source.role === row.role);
      if (!selected.length) missing = true;
      for (const { message_id, role, ...root } of selected) found.set(root.client + ':' + root.sessionKey, root);
    }
    // P2 stamped the consumer identity, but kept exact source IDs. These IDs
    // prove only a unique original root; never infer it from excerpt text or
    // substitute a later passage after the recorded IDs have disappeared.
    const values = [...found.values()], proven = !missing && values.length === 1;
    return { roots: proven ? values : [], independent: false, unknown: !proven,
      legacyKeep: true, possibleRoots: missing ? null : values };
  }
  function memoryRoots(ns, id) {
    const roots = new Map();
    for (const row of db.prepare('SELECT * FROM receipts WHERE memory_id=?').all(id)) {
      for (const root of receipt(ns, row).roots) roots.set(root.client + ':' + root.sessionKey, root);
    }
    return [...roots.values()];
  }
  function touchMemory(ns, id, incoming) {
    if (!enabled()) return;
    const roots = memoryRoots(ns, id);
    if (incoming) roots.push(...resolve(ns, incoming));
    touchRoots(ns, roots);
  }
  function touchRoots(ns, roots, changedEpisodes = new Set()) {
    for (const root of new Map(roots.map(root => [root.client + ':' + root.sessionKey, root])).values()) {
      db.prepare(`UPDATE raw_conversations SET revision=revision+1 WHERE ${where} AND client=? AND session_key=?`)
        .run(...boundary(ns), root.client, root.sessionKey);
      for (const row of db.prepare(`SELECT id FROM session_episodes WHERE ${where} AND client=? AND session_key=? AND deleted=0`)
        .all(...boundary(ns), root.client, root.sessionKey)) if (!changedEpisodes.has(row.id)) {
        db.prepare('UPDATE session_episodes SET revision=revision+1 WHERE id=?').run(row.id);
      }
    }
  }
  function mutateSources(ns, sources, work) {
    if (!enabled()) return work();
    if (!db.isTransaction) fail('raw_transaction_required');
    const affected = new Map();
    for (const source of sources) {
      const sessions = keys(ns, source.client, source.sessionId);
      // Raw/episode registration and trusted jobs can all resolve an old receipt
      // without adding one. Compare authority across the actual SQL mutation,
      // before any new message ledger/map can obscure the transition.
      const receipts = db.prepare(`SELECT r.* FROM receipts r JOIN memories m ON m.id=r.memory_id
        WHERE m.owner_id=? AND m.scope=? AND m.project_id=? AND m.deleted=0 AND r.client=? AND r.event_id=?`)
        .all(...boundary(ns), source.client, source.eventId);
      for (const row of receipts) if (keys(ns, row.client, row.session_id).some(key => sessions.includes(key)) && !affected.has(row.id)) {
        affected.set(row.id, { row, before: JSON.stringify(receipt(ns, row)) });
      }
    }
    const result = work();
    const changed = new Set();
    for (const { row, before } of affected.values()) if (JSON.stringify(receipt(ns, row)) !== before) changed.add(row.memory_id);
    for (const id of changed) touchMemory(ns, id);
    return result;
  }
  function bindJob(ns, input, sources) {
    if (!enabled() || !sources) return;
    return mutateSources(ns, sources, () => {
      const insert = db.prepare('INSERT OR IGNORE INTO raw_job_sources VALUES(?,?,?,?,?,?,?,?)');
      for (const source of sources) {
        assertSession(ns, source.client, source.sessionId);
        const values = resolve(ns, source);
        const session = values[0]?.sessionKey ?? hashSession(ns, source.client, source.sessionId);
        insert.run(...boundary(ns), input.client, input.eventId, source.client, session, source.eventId);
      }
    });
  }
  function mutateEpisodeSources(ns, episodeId, work) {
    const trackRoots = enabled(), layout = cachedContentLayout(db);
    // Relations can already depend on exact keep proof on a lineage-only
    // store. Its cleanup must not enable deletion's root/CAS bookkeeping.
    if (!trackRoots && !(layout?.relationsRevision && layout.rawLineage)) return work();
    if (!db.isTransaction) fail('raw_transaction_required');
    const owner = !episodeMutation;
    if (owner) episodeMutation = { namespace: JSON.stringify(boundary(ns)), before: new Map(), receipts: new Map() };
    const context = episodeMutation;
    try {
      if (context.namespace !== JSON.stringify(boundary(ns))) fail('raw_transaction_required');
      const read = id => db.prepare(`SELECT id,origin_episode_id,event_id,message_id,digest,role,truncated,ordinal
        FROM episode_sources WHERE episode_id=? ORDER BY id`).all(id);
      if (episodeId && !context.before.has(episodeId)) {
        context.before.set(episodeId, read(episodeId));
        // Retain authority before exact keep source IDs disappear. Losing that
        // proof can change deletion support for another root on the same Memory,
        // even though no receipt was inserted or removed in this transaction.
        const receipts = db.prepare(`SELECT DISTINCT r.* FROM episode_keep_actions a JOIN json_each(a.keep_source_ids) j
          JOIN episode_sources s ON j.value=s.id JOIN episode_memory_links l ON l.episode_id=a.episode_id AND l.event_id=a.event_id
          JOIN json_each(l.receipt_ids) ids JOIN receipts r ON r.id=ids.value AND r.memory_id=l.memory_id
          JOIN memories m ON m.id=r.memory_id WHERE s.episode_id=? AND m.owner_id=? AND m.scope=? AND m.project_id=? AND m.deleted=0`)
          .all(episodeId, ...boundary(ns));
        for (const row of receipts) if (!context.receipts.has(row.id)) context.receipts.set(row.id,
          { row, before: JSON.stringify(receipt(ns, row)), roots: memoryRoots(ns, row.memory_id) });
      }
      const result = work();
      if (owner) {
        const changed = new Set(), origins = new Set();
        for (const [id, before] of context.before) {
          const after = read(id);
          if (JSON.stringify(before) === JSON.stringify(after)) continue;
          changed.add(id);
          for (const source of [...before, ...after]) origins.add(source.origin_episode_id);
        }
        // Defer origin CAS touches until the enclosing source mutation finishes.
        // In particular, invalidating a draft's consumers must not self-trigger
        // its genuine pre-publication stale_episode guard.
        const reached = [];
        for (const id of origins) {
          const row = db.prepare(`SELECT client,session_key FROM session_episodes WHERE ${where} AND id=?`).get(...boundary(ns), id);
          if (!row) fail('raw_lineage_unavailable');
          reached.push({ client: row.client, sessionKey: row.session_key });
        }
        let changedAuthority = false;
        for (const { row, before, roots } of context.receipts.values()) {
          const current = db.prepare('SELECT * FROM receipts WHERE id=?').get(row.id);
          if (before !== JSON.stringify(current ? receipt(ns, current) : null)) {
            changedAuthority = true;
            reached.push(...roots, ...memoryRoots(ns, row.memory_id));
          }
        }
        // Changed consumers already receive their ordinary save/invalidate
        // revision. Preserve the caller's one-step episode revision result.
        if (trackRoots) touchRoots(ns, reached, changed);
        // Exact keep proof can disappear without revising the Memory or its
        // receipts. Erase derived rows only after the outer source mutation
        // settles, in its existing transaction, without installing a layout.
        if (changedAuthority && cachedContentLayout(db)?.relationsRevision) purgeUnreadableMemoryRelations(db, ns);
      }
      return result;
    } finally { if (owner) episodeMutation = undefined; }
  }
  function jobGuard(ns, input) {
    if (!enabled()) return null;
    if (db.prepare(`SELECT 1 FROM raw_closed_jobs WHERE ${where} AND client=? AND event_id=?`)
      .get(...boundary(ns), input.client, input.eventId)) return 'conversation_deleted';
    const rows = db.prepare(`SELECT source_client,session_key FROM raw_job_sources WHERE ${where} AND client=? AND event_id=?`)
      .all(...boundary(ns), input.client, input.eventId);
    for (const row of rows) {
      try { assertSession(ns, row.source_client, row.session_key); }
      catch (error) { if (error.code === 'conversation_deleted') return error.code; throw error; }
    }
    return null;
  }
  return { enabled, hashSession, keys, resolve, receipt, memoryRoots, touchMemory, mutateSources,
    mutateEpisodeSources, bindJob, jobGuard, assertSession, emptySession };
}
