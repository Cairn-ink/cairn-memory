import { rawSearchRequestState, withRawSearchRequestScope } from './raw-search-request-scope.mjs';
import { withContentSuppressionRequest } from './content-suppression-storage.mjs';
import { rawSearchOptions,searchInput,immutable,same,RAW_SEARCH_VERSION,RAW_SEARCH_LIMITS } from './raw-search-input.mjs';
import { fail } from './validation.mjs';
import { performance } from 'node:perf_hooks';
import { contextBudget } from './context-read-budget.mjs';
import { randomUUID } from 'node:crypto';
import { dirname } from 'node:path';
import { types } from 'node:util';
import { createRawSearchCache } from './raw-search-cache.mjs';
import { rawSearchSqlite, rawSearchDeadline } from './raw-search-sqlite.mjs';

const publicCodes = new Set(['invalid_input','invalid_query','invalid_read_set','authority_required','scope_changed',
  'stale_publication','store_closed','read_in_progress','maintenance_authority_required','raw_search_backend_unavailable']);
const pageAllowanceMs=100;
const expired = at => {if(performance.now()>=at)rawSearchDeadline();};
// Status and purge have no caller clock: cap contention at the normal Raw
// operation window, with the same fail-fast 25 ms storage backoff.
const administrativeWaitMs=1000;
// Opaque handles may cross readers only within the exact same host authority,
// physical canonical file, owner and read set. Tickets remain reader-local.
const preparedByAuthority = new WeakMap();
const emptyPartial = () => immutable({version:RAW_SEARCH_VERSION,publication:null,candidates:[],
  coverage:{status:'partial',scanned:null,expanded:null,causes:['deadline']},semantic:{state:'unknown',reason:null}});
const safeFailure = error => { fail(publicCodes.has(error?.code) ? error.code : 'raw_search_unavailable'); };

function plainCandidateData(candidate) {
  const pending = [candidate], seen = new WeakSet();
  while (pending.length) {
    const value = pending.pop();
    // Detect even revoked proxies before doing any reflection on the value.
    if (types.isProxy(value)) return false;
    if (value === null || value === undefined) continue;
    const kind = typeof value;
    if (kind === 'string' || kind === 'boolean' || kind === 'number') continue;
    if (kind !== 'object') return false;
    if (seen.has(value)) continue;
    seen.add(value);
    const array = Array.isArray(value), prototype = Object.getPrototypeOf(value);
    if (array ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null) return false;
    if (types.isModuleNamespaceObject(value) || types.isArgumentsObject(value) ||
        types.isTypedArray(value) || types.isBoxedPrimitive(value) || types.isExternal(value)) return false;
    const descriptors = Object.getOwnPropertyDescriptors(value), keys = Reflect.ownKeys(descriptors);
    const length = array ? descriptors.length.value : 0;
    // An absent index can read from the prototype. Require dense arrays.
    if (array && keys.length !== length + 1) return false;
    for (const key of keys) {
      if (array && key === 'length') continue;
      const descriptor = descriptors[key];
      if (typeof key !== 'string' || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) return false;
      if (array) {
        const index = Number(key);
        if (!Number.isInteger(index) || index < 0 || index >= length || String(index) !== key) return false;
      }
      pending.push(descriptor.value);
    }
  }
  return true;
}

/** Open the configured Raw store; enabled:false explicitly disables search. */
export async function openRawSearch(value, { signal } = {}) {
  if (value === undefined || value === false || value?.enabled === false) return null;
  const options=rawSearchOptions(value);
  let openingDeadlineAt=performance.now()+1000;
  let opening=true;
  const openingCheck=()=>{if(opening&&signal?.aborted)fail('raw_upkeep_cancelled');expired(openingDeadlineAt);};
  const [{openReadDatabase},{createRawSearchAuthority},{openRawSearchStorage},{createRawSearchMaintenance},retrieval,embedding,{sqliteFileStat},{isStorageBusy}]=await Promise.all([
    import('./read-database.mjs'),import('./raw-search-authority.mjs'),import('./raw-search-storage.mjs'),
    import('./raw-search-maintenance.mjs'),import('./raw-search-retrieval.mjs'),import('./context-read-embedder.mjs'),import('./sqlite-journal-probe.mjs'),import('./database.mjs')]);
  const interrupted = error => isStorageBusy(error)||['source_busy','search_deadline'].includes(error?.code);
  let database,storage,authority;
  try {
    const canonicalFile=()=>{
      if(sqliteFileStat(options.path).nlink!==1n)fail('unsafe_database_file');
      for(let path=options.path;;path=dirname(path)){
        if(sqliteFileStat(path).isSymbolicLink())fail('unsafe_database_file');
        if(dirname(path)===path)break;
      }
    };
    while(true) {
      let openingNative;
      try {
        openingCheck();canonicalFile();
        database=openReadDatabase(options.path,{contextRead:true,busyTimeoutMs:0,preflight:openingCheck,
          nativeObserver:{invoke(_kind,_label,work){openingCheck();return work();},database:native=>rawSearchSqlite(openingNative=native,openingCheck)}});
        const assertFile=database.assertFile;
        database.assertFile=()=>{assertFile();canonicalFile();};
        authority=createRawSearchAuthority(database,options);
        storage=await openRawSearchStorage({directory:options.directory,identity:authority.identity,bind:authority.bind,quotaBytes:options.quotaBytes,deadlineAt:openingDeadlineAt});
        openingCheck();break;
      }catch(error){
        // Dispose both handles before yielding. Every new attempt revalidates
        // canonical identity and the sidecar schema/header/physical seal.
        try {
          // Preflight can throw before openReadDatabase returns its wrapper.
          // Dispose it synchronously before yielding to sidecar disposal.
          if(openingNative?.isOpen)openingNative.close();
          if(openingNative?.isOpen)throw new Error('Open canonical Raw search connection');
          await storage?.close();
        }
        catch(cleanup){throw new Error('Raw search opening disposal failed',{cause:cleanup});}
        storage=undefined;database=undefined;
        if(!isStorageBusy(error)&&error.code!=='source_busy')throw error;
        const wait=Math.max(25,(authority?.resume()??0)-performance.now());
        if(performance.now()+wait>=openingDeadlineAt)rawSearchDeadline();
        await new Promise(resolve=>setTimeout(resolve,wait));
      }
    }
    openingCheck();opening=false;openingDeadlineAt=Infinity;
    const metadata=options.embedder&&{id:options.embedder.id,revision:options.embedder.revision,
      dimensions:options.embedder.dimensions,normalization:options.embedder.normalization};
    const cacheEnabled=options.policy?.family==='local'&&!!metadata;
    const cache=createRawSearchCache({enabled:cacheEnabled,checkKey:()=>{
      return withContentSuppressionRequest(()=>{database.assertFile();return authority.cacheKey(storage.publication({shape:false}),metadata);},{fresh:true});
    }});
    const maintenance=createRawSearchMaintenance(storage,authority,options),prepared=new Map(),searches=new Map();
    const dispatch=options.embedder&&contextBudget({budgetConfigured:true,policy:options.policy,embedder:options.embedder});
    const releaseResidency=embedding.selectRawVectorResidency();
    const instance=randomUUID();
    let sharedPrepared=preparedByAuthority.get(options.authority);
    if(!sharedPrepared)preparedByAuthority.set(options.authority,sharedPrepared=new WeakMap());
    let closed=false,serial=0;
    const operations=new Set();
    const ready=()=>{if(closed)fail('store_closed');database.assertFile();};
    const tracked=work=>(...args)=>{
      const operation=withContentSuppressionRequest(async()=>{try{ready();return await work(...args);}catch(error){safeFailure(error);}},{fresh:true});
      operations.add(operation);operation.then(()=>operations.delete(operation),()=>operations.delete(operation));return operation;
    };
    const requestOwner = {};
    function requestState() {
      return rawSearchRequestState(requestOwner, () => {
        const state = { prepared: new Map(), searches: new Map(), routes: new Set(), close() {
          for (const handle of state.routes) sharedPrepared.delete(handle);
          state.routes.clear(); state.prepared.clear(); state.searches.clear();
        } };
        return state;
      }) ?? { prepared, searches };
    }
    function retain(map,key,entry,limit,drop=id=>map.delete(id)) {
      for(const [id,value] of map)if(value.expires<performance.now())drop(id);
      while(map.size>=limit)drop(map.keys().next().value);
      map.set(key,{...entry,expires:performance.now()+5000});
    }
    const checkSources=(sources,intent,at=Infinity)=>{for(const source of sources)authority.check(source,intent,at);};
    // Scoped routing is metadata-only: the module-level authority WeakMap
    // must not become a second strong owner of invocation text or handles.
    function scopedPreparedRoute(stateRef, ticket, handleRef) {
      return { identity: authority.identity, resolve(at) {
        ready();
        const live = stateRef.deref()?.prepared.get(ticket), handle = handleRef.deref();
        if (!live || !handle || live.handle !== handle || live.expires < performance.now()) fail('source_unavailable');
        return { ...live, access() { live.access(() => {
          ready(); expired(at); checkSources(live.sources, live.intent, at);
        }); } };
      } };
    }
    function retainPrepared(ticket,entry) {
      const state = requestState(), { prepared } = state;
      retain(prepared,ticket,entry,RAW_SEARCH_LIMITS.preparations, id => {
        const handle = prepared.get(id)?.handle;
        if (state.routes) { sharedPrepared.delete(handle); state.routes.delete(handle); }
        prepared.delete(id);
      });
      if (state.routes) {
        state.routes.add(entry.handle);
        sharedPrepared.set(entry.handle, scopedPreparedRoute(new WeakRef(state), ticket, new WeakRef(entry.handle)));
        return;
      }
      sharedPrepared.set(entry.handle,{identity:authority.identity,resolve(at){
        ready();
        const live=prepared.get(ticket);
        if(!live||live.handle!==entry.handle||live.expires<performance.now())fail('source_unavailable');
        // Each issuing reader runs its own access callbacks and live guards
        // before the validating reader's final whole-set canonical snapshot.
        return {...live,access(){live.access(()=>{
          ready();expired(at);checkSources(live.sources,live.intent,at);
        });}};
      }});
    }
    function dropPrepared(ticket) {
      const state = requestState(), handle = state.prepared.get(ticket)?.handle;
      if (state.routes) { sharedPrepared.delete(handle); state.routes.delete(handle); }
      state.prepared.delete(ticket);
    }
    async function retry(work,at,onExhausted) {
      while(true)try{expired(at);return await work(at);}catch(error){
        if(!interrupted(error))throw error;
        cache.drop();authority.reset();
        if(error.code==='search_deadline')return onExhausted();
        const wait=isStorageBusy(error)?25:error.code==='source_busy'?Math.max(0,authority.resume()-performance.now()):0;
        if(at-performance.now()<wait+pageAllowanceMs)return onExhausted();
        if(wait)await new Promise(resolve=>setTimeout(resolve,wait));
        try{authority.refresh(at);}catch(next){if(!interrupted(next))throw next;}
      }
    }
    async function search(value,token) {
      const at=performance.now()+1000;
      return retry(deadlineAt=>searchAttempt(value,token,deadlineAt),at,emptyPartial);
    }
    async function searchAttempt(value,token,deadlineAt) {
      const input=searchInput(value),access=authority.authorize('rawSearch',input,token);access();
      expired(deadlineAt);
      let cacheProof,borrowed,residency,vectors=null;
      try {
        let state=null;
        if(cacheEnabled)try{
          const publication=storage.publication({shape:false,deadlineAt});
          cacheProof={publication,metadata,key:authority.cacheKey(publication,metadata,deadlineAt)};
          borrowed=cache.acquire(cacheProof.key);
          if(borrowed){
            state=storage.publication({deadlineAt});
            if(state.sequence!==publication.sequence||state.revision!==publication.revision){
              borrowed.release();borrowed=null;cache.drop();cacheProof=undefined;
            }
          }
        }catch(error){borrowed?.release();borrowed=null;cache.drop();cacheProof=undefined;if(interrupted(error))throw error;}
        const snapshot=borrowed?{...state,rows:borrowed.rows}:await storage.search({deadlineAt});expired(deadlineAt);access();
        // A concurrent publication between the optional header read and the
        // payload snapshot only defers caching. It adds no new search error.
        if(cacheProof&&snapshot.sequence!==cacheProof.publication.sequence){cache.drop();cacheProof=undefined;}
        // Scope before scoring: no foreign owner or namespace enters a corpus.
        const scopeKeys=new Set(options.readSet.map(ns=>JSON.stringify(ns)));
        const scopedRows=snapshot.rows.filter(row=>{expired(deadlineAt);return scopeKeys.has(JSON.stringify(row.source.ref.namespace));});
        const guard=()=>{ready();expired(deadlineAt);access();};
        let semantic={state:'bm25-only',reason:options.embedder?'partial_coverage':'disabled'},queryVector=null;
        const port=options.embedder;let query=input.queryVector;
        let queryAllowed=!port||authority.queryAllowed(deadlineAt);
        const queryGuard=()=>{
          guard();
          if(!authority.queryAllowed(deadlineAt)){queryAllowed=false;fail('namespace_paused');}
        };
        if(!queryAllowed)semantic={state:'bm25-only',reason:'namespace_paused'};
        const chunks=scopedRows.reduce((n,row)=>{expired(deadlineAt);return n+row.chunks.length;},0);
        const complete=!snapshot.partial&&scopedRows.every(row=>same(row.embedder,metadata)&&row.chunks.every(c=>c.vector));
        if(port&&queryAllowed&&!query&&complete&&scopedRows.length&&embedding.semanticCapacity(chunks,port).eligible){
          try{
            if(Buffer.byteLength(input.query)+64>8192)fail('provider_error');
            const result=await dispatch(port,[input.query],{budgetClass:'query',signal:new AbortController().signal,deadlineAt,guard:queryGuard});
            if(!Array.isArray(result)||result.length!==1)fail('invalid_vector');
            query={input:input.query,embedder:metadata,vector:result[0]};
          }catch(error){guard();if(interrupted(error))throw error;
            semantic={state:'bm25-only',reason:!queryAllowed?'namespace_paused':['budget_denied','timeout','rate_limited'].includes(error.code)?error.code:'provider_error'};}
        }
        if(port&&queryAllowed&&query&&query.input===input.query&&same(query.embedder,metadata)&&embedding.semanticCapacity(chunks,port).eligible&&complete){
          try {
            // Another search may have populated the same reader while this
            // operation awaited its query provider. Reuse that reservation.
            if(!borrowed&&cacheProof)borrowed=cache.acquire(cacheProof.key);
            if(!borrowed){residency=embedding.reserveSharedVectors(chunks,port);if(!residency)fail('partial_coverage');}
            queryVector=embedding.validateVector(query.vector,port);
            vectors=borrowed?borrowed.vectors:retrieval.loadRawVectorBlocks(scopedRows,port,()=>expired(deadlineAt));
            if(!vectors)fail('partial_coverage');
            semantic={state:'ready',reason:null};
          }catch(error){if(interrupted(error))throw error;vectors=null;queryVector=null;semantic={state:'bm25-only',reason:error.code==='partial_coverage'?'partial_coverage':'invalid_vector'};}
        }
        expired(deadlineAt);
        const checked=new Map(),verifiedTurns=new Map(),candidateSources=new Map();
        const allows=source=>{
          const key=JSON.stringify(source.ref);
          if(!checked.has(key))try{authority.check(source,input.intent,deadlineAt);checked.set(key,true);}
          catch(error){if(!['source_unavailable','source_excluded','raw_crypto_unavailable','source_budget_exceeded'].includes(error.code))throw error;checked.set(key,false);}
          return checked.get(key);
        };
        const verifyTurn=turn=>{
          if(!verifiedTurns.has(turn.id)){
            const segments=turn.segments.filter(segment=>allows(segment.source));
            const spans=segments.map(s=>s.source.ref.span).sort((a,b)=>a.start-b.start);let through=0;
            for(const span of spans){if(span.start!==through)break;through=span.end;}
            const total=segments[0]?.source.totalUnits??segments[0]?.source.manifest?.message.total_units;
            verifiedTurns.set(turn.id,{...turn,segments,complete:segments.length>0&&(total===undefined||through===total)});
          }
          return verifiedTurns.get(turn.id);
        };
        const result=retrieval.retrieveRaw(scopedRows,input.query,{vectors,queryVector,check:()=>expired(deadlineAt),
          accept(row,center){
            const turn=verifyTurn(row.turn),verifiedCenter=verifyTurn(center);
            if(!turn.segments.length||!verifiedCenter.segments.length)return false;
            const sources=[...new Map([...turn.segments,...verifiedCenter.segments].map(s=>[JSON.stringify(s.source.ref),s.source])).values()];
            candidateSources.set(row.id,sources);return {...row,turn};
          }});
        expired(deadlineAt);
        const publication=authority.bind('raw-search-publication-v1',[authority.identity,snapshot.sequence]);
        const proof=authority.bind('raw-search-proof-v1',[instance,publication,++serial]);
        let candidates=result.rows.map(row=>{expired(deadlineAt);
          const sources=row.turn.segments.map(s=>{expired(deadlineAt);return s.source;}),source=sources[0],ref=source.ref;
          const historical=sources.some(s=>s.classification.kind==='history-only');
          const bare=sources.some(s=>s.classification.kind==='current-eligible-bare');
          const classification=historical?{kind:'history-only',reason:'history-contributor'}:bare?
            {kind:'current-eligible-bare',reason:'complete-privacy-no-memory-link'}:{kind:'current-eligible-linked',reason:'current-memory-links'};
          if(classification.kind==='current-eligible-bare'&&sources.some(s=>s.classification.reason==='host-session-ancestry'))classification.reason='host-session-ancestry';
          return {id:row.id,namespace:ref.namespace,conversationId:ref.conversationId,messageId:ref.messageId,
            ordinal:source.ordinal,role:source.role,occurredAt:source.occurredAt,ranges:sources.map(s=>s.ref),score:row.score,
            centerId:row.centerId,neighbor:row.neighbor,currentness:historical?source.currentness:bare?'unknown':'current',
            classification,
            rangeClassifications:sources.map(s=>s.classification),publication,proof};
        });
        const coverage=result.coverage;
        if(snapshot.partial){coverage.status='partial';coverage.causes.push(snapshot.partialReason);}
        // Work/population counters can describe denied/stale rows. Public coverage
        // reports limits and availability only; operational counts stay internal.
        coverage.scanned=null;coverage.expanded=null;
        // Final predicates share one canonical snapshot. A newly denied hit is
        // dropped without refusing the allowed remainder of the page.
        const validated=authority.validate(candidates.map(candidate=>({sources:candidateSources.get(candidate.id),
          intent:input.intent,access,value:candidate})),deadlineAt,{dropDenied:true,inventoryCheckpoint:snapshot.checkpoint});
        candidates=validated.values;
        if(!validated.coverageComplete){coverage.status='partial';coverage.causes.push('index_incomplete');}
        const output=immutable({version:RAW_SEARCH_VERSION,publication,candidates,coverage,semantic},()=>expired(deadlineAt));
        if(cacheProof&&!borrowed&&(vectors||snapshot.partial)){
          residency?.release();residency=null;
          borrowed=cache.install(cacheProof.key,scopedRows,vectors,metadata,snapshot.hintBytes,()=>expired(deadlineAt));
        }
        expired(deadlineAt);
        retain(requestState().searches,proof,{candidateSources,intent:input.intent,access,candidates},4);
        return output;
      }finally{vectors=null;borrowed?.release();residency?.release();}
    }
    const refused=()=>fail('source_unavailable');
    const classify=(candidate,settings,token)=>retry(at=>classifyAttempt(candidate,settings,token,at),performance.now()+1000,
      ()=>immutable({kind:'denied',reason:'source-or-authority-unavailable'}));
    const prepare=(candidate,settings,token)=>retry(at=>prepareAttempt(candidate,settings,token,at),performance.now()+1000,refused);
    const preparedOutput=(source,classification,ranges,check)=>immutable({namespace:source.ref.namespace,
      conversationId:source.ref.conversationId,messageId:source.ref.messageId,ordinal:source.ordinal,
      role:source.role,occurredAt:source.occurredAt,classification,ranges},check);
    function candidateEntry(candidate,intent) {
      const entry=requestState().searches.get(candidate?.proof);
      if(!entry||entry.expires<performance.now()||entry.intent!==intent||!entry.candidates.some(row=>same(row,candidate)))fail('stale_publication');
      return {...entry,sources:entry.candidateSources.get(candidate.id)};
    }
    async function classifyAttempt(candidate,{intent='current'}={},token,at) {
      if(!['current','history'].includes(intent))fail('invalid_input');
      try {
        const entry=candidateEntry(candidate,intent);
        const canonical=()=>checkSources(entry.sources,intent,at);
        canonical();
        const access=authority.authorize('rawSearchSource',{publication:candidate.publication,intent},token,
          canonical);
        access();
        return authority.validate([{sources:entry.sources,intent,access,value:candidate.classification}],at)[0];
      }catch(error){if(interrupted(error))throw error;return immutable({kind:'denied',reason:'source-or-authority-unavailable'});}
    }
    async function prepareAttempt(candidate,{intent='current'}={},token,at) {
      if(!['current','history'].includes(intent))fail('invalid_input');
      const entry=candidateEntry(candidate,intent);
      const canonical=()=>checkSources(entry.sources,intent,at);
      canonical();
      const access=authority.authorize('rawSearchSource',{candidate,intent},token,canonical);
      const guard=()=>{canonical();access(canonical);};guard();
      const snapshot=storage.publication({shape:false,deadlineAt:at});guard();
      if(candidate.publication!==authority.bind('raw-search-publication-v1',[authority.identity,snapshot.sequence]))fail('stale_publication');
      // The private proof retains authenticated refs; text is opened canonically.
      // Preparing a page must not decode the entire ranking index per hit.
      const rows=entry.sources.map(source=>({source})).filter(row=>candidate.ranges.some(ref=>same(ref,row.source.ref)))
        .sort((a,b)=>a.source.ref.span.start-b.source.ref.span.start);
      if(!rows.length||rows.length!==candidate.ranges.length||rows.length>1024)fail('source_unavailable');
      const bytes=rows.reduce((n,row)=>n+row.source.bytes,0);
      if(bytes>256*1024)fail('source_budget_exceeded');
      const ranges=[];
      for(const row of rows){
        guard();const text=await authority.open(row.source,intent,guard);ready();guard();
        ranges.push({source:row.source.ref,text,classification:row.source.classification});
      }
      const source=rows[0].source;
      const output=preparedOutput(source,candidate.classification,ranges);
      const ticket=authority.bind('raw-search-prepared-v1',[candidate.proof,++serial]);
      const handle=Object.freeze({value:output,ticket,validate(){return revalidate([handle])[0];}});
      retainPrepared(ticket,{sources:entry.sources,intent,access,value:output,handle});
      try{revalidate([ticket]);}catch(error){dropPrepared(ticket);throw error;}return handle;
    }
    async function prepareMany(candidates,{intent='current',deadlineAt=performance.now()+1000,onPrepared=()=>{}}={},token) {
      if(!Array.isArray(candidates)||candidates.length>24||!['current','history'].includes(intent)||
          typeof deadlineAt!=='number'||Number.isNaN(deadlineAt)||typeof onPrepared!=='function')fail('invalid_input');
      const at=Math.min(deadlineAt,performance.now()+1000),handles=[];
      if(!candidates.length)return {handles,complete:true};
      // Successful entries live for one prepareMany invocation, never across calls.
      const successfulEntries=[];
      const check=()=>{expired(at);if(closed)fail('store_closed');};
      return retry(async()=>{
        check();
        // Authenticate each issuing proof independently. Known unpreparable
        // ranges must not spend the shared snapshot's opening budget.
        const entries=candidates.map((candidate,index)=>{
          try {
            check();
            if(index<handles.length)return null;
            const memo=successfulEntries[index];
            successfulEntries[index]=undefined;
            // Record the shape before proof lookup can read caller properties.
            const plainData=plainCandidateData(candidate);
            const entry=candidateEntry(candidate,intent);
            // Capture the full authorization payload and the fields read directly
            // for proof lookup, range selection, publication and handle output.
            const candidateBinding=plainData?JSON.stringify([candidate.proof,candidate.id,candidate.ranges,
              candidate.publication,candidate.classification,candidate]):undefined;
            if(plainData&&memo?.candidate===candidate&&memo.candidateBinding===candidateBinding){
              successfulEntries[index]=memo;
              return memo.entry;
            }
            const rows=entry.sources.filter(source=>candidate.ranges.some(ref=>same(ref,source.ref)))
              .sort((a,b)=>a.ref.span.start-b.ref.span.start);
            if(!rows.length||rows.length!==candidate.ranges.length||rows.length>1024)fail('source_unavailable');
            if(rows.reduce((bytes,source)=>bytes+source.bytes,0)>256*1024)fail('source_budget_exceeded');
            // Preserve the existing host authorization protocol. Authorization
            // is metadata-only; the shared canonical snapshot follows it.
            const access=authority.authorize('rawSearchSource',{candidate,intent},token,check);access();check();
            const preparedEntry={...entry,rows,access};
            if(plainData)successfulEntries[index]={candidate,candidateBinding,entry:preparedEntry};
            return preparedEntry;
          }catch(error){if(interrupted(error))throw error;return null;}
        });
        const publication=storage.publication({shape:false,deadlineAt:at});
        const binding=authority.bind('raw-search-publication-v1',[authority.identity,publication.sequence]);
        for(let i=0;i<entries.length;i++)if(candidates[i]?.publication!==binding)entries[i]=null;
        const batch=authority.prepareBatch(entries,intent,at);
        for(let index=handles.length;index<candidates.length;index++){
          check();let handle=null;
          try {
            const candidate=candidates[index],entry=entries[index];
            if(!batch.allowed[index])fail('source_unavailable');
            const {rows,access}=entry;
            const ranges=[];
            for(const source of rows){
              // The captured bytes outlive the snapshot. Recheck live source
              // predicates after host callbacks and around every part opener.
              const guard=()=>{check();access();authority.check(source,intent,at);check();};
              const text=await batch.open(source,guard);check();
              ranges.push({source:source.ref,text,classification:source.classification});
            }
            const output=preparedOutput(rows[0],candidate.classification,ranges,check);
            check();
            const ticket=authority.bind('raw-search-prepared-v1',[candidate.proof,++serial]);
            handle=Object.freeze({value:output,ticket,validate(){return revalidate([handle])[0];}});
            retainPrepared(ticket,{sources:entry.sources,intent,access,value:output,handle});
            try{revalidate([ticket]);}catch(error){dropPrepared(ticket);handle=null;throw error;}
          }catch(error){if(interrupted(error))throw error;}
          check();handles.push(handle);onPrepared(handle,index);
        }
        return {handles,complete:true};
      },at,()=>({handles:handles.slice(),complete:false}));
    }
    async function prepareSource(ref,{intent='current'}={},token) {
      if(!['current','history'].includes(intent))fail('invalid_input');
      const source=authority.inspect(ref,intent),canonical=()=>authority.check(source,intent);
      const access=authority.authorize('rawSearchSource',{source:source.ref,intent},token,canonical);
      const guard=()=>{canonical();access(canonical);};
      const text=await authority.open(source,intent,guard);guard();
      const output=immutable({namespace:source.ref.namespace,conversationId:source.ref.conversationId,messageId:source.ref.messageId,
        ordinal:source.ordinal,role:source.role,occurredAt:source.occurredAt,classification:source.classification,
        ranges:[{source:source.ref,text,classification:source.classification}]});
      const ticket=authority.bind('raw-search-source-prepared-v1',[instance,++serial,source.ref]);
      const handle=Object.freeze({value:output,ticket,validate(){return revalidate([handle])[0];}});
      retainPrepared(ticket,{sources:[source],intent,access,value:output,handle});
      revalidate([ticket]);return handle;
    }
    function revalidate(handles) {
      return withContentSuppressionRequest(()=>revalidateInside(handles),{fresh:true});
    }
    function revalidateInside(handles) {
      const at=performance.now()+1000;let busy=0;
      try {
        ready();if(!Array.isArray(handles)||handles.length>RAW_SEARCH_LIMITS.preparations)fail('invalid_input');
        const entries=handles.map(handle=>{
          const own=requestState().prepared.get(typeof handle==='string'?handle:handle?.ticket);
          if(own&&(typeof handle==='string'||own.handle===handle)){
            if(own.expires<performance.now())fail('source_unavailable');return own;
          }
          if(typeof handle!=='string'){
            const reader=sharedPrepared.get(handle);
            if(!reader||!same(reader.identity,authority.identity))fail('source_unavailable');
            return reader.resolve(at);
          }
          fail('source_unavailable');
        });
        while(true)try{return authority.validate(entries,at);}catch(error){
          if(!interrupted(error))throw error;
          cache.drop();authority.reset();
          if(error.code==='search_deadline'||error.code==='source_busy'&&busy++>=1)throw error;
          const wait=error.code==='source_busy'?Math.max(0,authority.resume()-performance.now()):0;
          if(at-performance.now()<wait+pageAllowanceMs)throw error;
          // This API is synchronous. The bounded backoff owns no read snapshot.
          if(wait)Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,wait);
          authority.refresh(at);
        }
      }catch{fail('raw_search_unavailable');}
    }
    async function administrativeRetry(work) {
      const at=performance.now()+administrativeWaitMs;
      let last;
      for(let attempt=0;attempt<40;attempt++){
        if(performance.now()>=at)throw last;
        try{return await work();}catch(error){
          if(!isStorageBusy(error)||performance.now()+25>=at)throw error;
          last=error;await new Promise(resolve=>setTimeout(resolve,25));
        }
      }
      throw last;
    }
    const status=()=>{
      const progress=maintenance.status();
      return {state:progress.phase==='failed'?'unavailable':'unknown',eligible:null,indexed:null,embedded:null,
        coverage:'unknown',error:progress.error?['quota_exhausted','no_progress','maintenance_release_failed'].includes(progress.error)?progress.error:'raw_search_unavailable':null,
        maintenance:{phase:progress.phase,quantum:progress.quantum,noProgress:progress.noProgress,pending:progress.pending,
          checkpoint:authority.bind('raw-search-progress-v1',progress.checkpointAdvances),lastActualWork:progress.lastActualWork}};
    };
    return Object.freeze({search:tracked(search),prepare:tracked(prepare),prepareMany:tracked(prepareMany),prepareSource:tracked(prepareSource),classify:tracked(classify),validate:revalidate,revalidate,
      maintain:tracked((input,token)=>withRawSearchRequestScope(async()=>{const access=authority.authorize('rawSearchMaintenance',{},token);
        const cacheError=cache.maintain();
        await maintenance.maintain(input,access,
          cacheError&&(isStorageBusy(cacheError)||cacheError.code==='source_busy')?cacheError:undefined);return status();})),
      status:()=>withContentSuppressionRequest(async()=>{try{ready();await administrativeRetry(()=>storage.status());return status();}catch{return {state:'unavailable',eligible:null,indexed:null,embedded:null,coverage:'unknown',error:'raw_search_unavailable'};}},{fresh:true}),
      purge:tracked(async()=>{cache.close();await maintenance.close();await administrativeRetry(()=>storage.dropOwner());prepared.clear();searches.clear();}),
      close:()=>withContentSuppressionRequest(async()=>{if(closed)return;closed=true;
        try{cache.close();await maintenance.close();await Promise.allSettled([...operations]);prepared.clear();searches.clear();}
        finally{try{await storage.close();}finally{try{database.db.close();}finally{releaseResidency();}}}},{fresh:true})});
  }catch(error){await storage?.close();database?.db.close();safeFailure(error);}
}
