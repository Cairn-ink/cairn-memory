import { captureDispatch, captureSourceBusy } from './capture-source-safety.mjs';
import { contentWriteMethodClass } from './content-write-context.mjs';
import { withContentSuppressionRequest } from './content-suppression-storage.mjs';
import { contentSafetyFacade } from './content-safety-boundary.mjs';
import { roleProfileOptions } from './role-profile-input.mjs';
import { createRoleProfileFacade } from './role-profile-facade.mjs';
import { assetOptions } from './asset-input.mjs';
import { createAssetFacade } from './asset-facade.mjs';
import { methodPackageOptions } from './method-package-input.mjs';
import { createMethodPackageFacade } from './method-package-facade.mjs';
import { openContextCore } from './context-read-facade.mjs';
import { decisionReviewOption } from './confirmation-storage.mjs';
import { createLocalRawSearch, localRawSearchManager } from './local-raw-search.mjs';
import { isRawCapabilityRefusal } from './content-safety-layout.mjs';
import { defaultRawOptions } from './local-defaults.mjs';
import { rawOptions } from './raw-options.mjs';
import { storeFenceOption } from './store-fence.mjs';
import { existingStoreOption } from './existing-store.mjs';
import { ownData } from './local-authority-input.mjs';
import { types } from 'node:util';
import { composeRawCore } from './raw-composition.mjs';
import { privateCardOptions, cardNamespace, ENGINE_CARD_LIMITS } from './private-card-input.mjs';
import { createPrivateCardFacade } from './private-card-facade.mjs';
import { contextInput, assembleSessionContext } from './session-context.mjs';
import { rangeInput, rangeOrder, validateRangeAnchor, rangePage, envelopeText } from './episode-reads.mjs';
import { isStorageBusy, busyTimeoutOption } from './database.mjs';
import { ADMISSION_LEASE_MS } from './episode-schema.mjs';
import { episodeOptions, episodeClient } from './episode-storage.mjs';
import { createHmac, timingSafeEqual } from "node:crypto";
import { createMemoryRuntime, readRecallJournalMode } from "./runtime.mjs";
import { createCaptureDeadline } from './capture-deadline.mjs';
import { uniqueIds, memoryGuards, placementProposal } from './placement-input.mjs';
import { countTokens, modelPortValue } from './model-budget.mjs';
import { isSourceContext } from './source-evidence.mjs';
import { classify } from './classification.mjs';
import { memoryRefs, fetchMemories } from './fetch.mjs';
import { recallMemories } from './recall.mjs';
import { captureEpisodeMessages, endEpisode, keepEpisodeCapture } from './episode-capture.mjs';
import { captureMessages, extractionRequest } from './capture.mjs';
import { captureSnapshot } from './capture-input.mjs';
import { requestFits } from './model-packing.mjs';
import { emitDiagnostic } from './model-diagnostics.mjs';
import { createQueryExcerpt, QUERY_EXCERPT_VERSION } from './query-excerpt.mjs';
import { createQueryScore, QUERY_CANDIDATE_VERSION, QUERY_SCAN_LIMIT,
  SOURCE_QUERY_CANDIDATE_VERSION, SOURCE_QUERY_RECEIPT_LIMIT,
  BOUNDED_KEYSET_SOURCE_CANDIDATES } from './query-candidates.mjs';
import { qualificationInput, qualificationSources } from './claim-qualification-input.mjs';
import { proposeRationale } from './rationale.mjs';
import { reviewSourceBasis } from './source-basis.mjs';
import {
  boundedText, fingerprint, identifier, limit, MemoryStoreError, object, revision, denseArray, fail, receiptEventTime,
} from "./validation.mjs";

// One constructor grammar for the base and its opt-in wrappers. Wrappers remove
// only their own option; all other legal options reach the retained validator.
const CORE_OPTIONS = Object.freeze(['path','model','captureQualification','captureQualifiedDuplicates','captureSourcePolicy',
  'captureRationale','captureEvidence','captureDeadlineMs','sourceCandidatePolicy','sessionEpisodes',
  'decisionReview','privateCards','methodPackages','assets','roleProfiles','existingStore','storeFence','contentSafety','busyTimeoutMs',
  'cardRelations','cardVectors']);
const OPEN_OPTIONS = Object.freeze([...CORE_OPTIONS, 'rawConversations', 'raw', 'rawSearch']);

const keepAdmissionKey = Symbol('keepAdmissionKey');

const kinds = ["fact", "preference", "decision", "instruction", "context"];
const statusOrder = ["filed", "unfiled"];
const stateOrder = ['active', 'historical'];

function contractNamespace(input) {
  object(input, ["ownerId", "scope", "projectId"]);
  if (!Object.hasOwn(input, "ownerId") || !Object.hasOwn(input, "scope") ||
      !Object.hasOwn(input, "projectId")) throw new MemoryStoreError("invalid_input");
  let ownerId;
  try { ownerId = identifier(input.ownerId); } catch { throw new MemoryStoreError("invalid_input"); }
  if (input.scope === "personal" && input.projectId === null) {
    return { ownerId, scope: "personal", projectId: "" };
  }
  if (input.scope === "project" && input.projectId !== null) {
    let projectId;
    try { projectId = identifier(input.projectId); } catch {
      throw new MemoryStoreError("invalid_input");
    }
    return { ownerId, scope: "project", projectId };
  }
  throw new MemoryStoreError("invalid_input");
}

function publicNamespace(ns) {
  return { ownerId: ns.ownerId, scope: ns.scope, projectId: ns.projectId || null };
}

function contractReadSet(input) {
  try {
    denseArray(input, 1, 2);
    const namespaces = input.map(contractNamespace);
    if (namespaces.length === 2 && (namespaces[0].ownerId !== namespaces[1].ownerId ||
        namespaces[0].scope === namespaces[1].scope)) throw new Error();
    return namespaces;
  } catch { throw new MemoryStoreError('invalid_read_set'); }
}

function contractReceipt(input) {
  object(input, ["client", "sessionId", "eventId", "role", "excerpt", "occurredAt"]);
  if (!["user", "assistant"].includes(input.role)) throw new MemoryStoreError("invalid_input");
  try {
    receiptEventTime(input.occurredAt);
    return {
      client: identifier(input.client),
      sessionId: identifier(input.sessionId),
      eventId: identifier(input.eventId),
      role: input.role,
      excerpt: boundedText(input.excerpt, 800, true),
    };
  } catch {
    throw new MemoryStoreError("invalid_input");
  }
}

function contractMemory(input, maxContent = 4000) {
  object(input, ["content", "kind"]);
  if (!kinds.includes(input.kind)) throw new MemoryStoreError("invalid_input");
  let content;
  try { content = boundedText(input.content, maxContent); } catch {
    throw new MemoryStoreError("invalid_input");
  }
  return { content, kind: input.kind, origin: "explicit", confidence: 1,
    fingerprint: fingerprint(content) };
}

function contractId(value) {
  try { return identifier(value); } catch { throw new MemoryStoreError("invalid_input"); }
}

function contractRevision(value) {
  try { return revision(value); } catch { throw new MemoryStoreError("invalid_input"); }
}

function contractConflictHints(value = []) {
  const hints = denseArray(value, 0, 5).map((hint) => {
    object(hint, ['memoryId', 'expectedRevision', 'relation']);
    if (hint.relation !== 'contradicts') throw new MemoryStoreError('invalid_input');
    return { memoryId: contractId(hint.memoryId),
      expectedRevision: contractRevision(hint.expectedRevision), relation: 'contradicts' };
  });
  if (new Set(hints.map((hint) => hint.memoryId)).size !== hints.length) {
    throw new MemoryStoreError('invalid_input');
  }
  return hints;
}

function contractLimit(value) {
  try { return limit(value); } catch { throw new MemoryStoreError("invalid_input"); }
}

function statuses(value = statusOrder) {
  if (!Array.isArray(value) || value.length === 0 ||
      value.some((item) => !statusOrder.includes(item)) || new Set(value).size !== value.length) {
    throw new MemoryStoreError("invalid_input");
  }
  return statusOrder.filter((item) => value.includes(item));
}

function states(value = stateOrder) {
  denseArray(value, 1, 2);
  if (value.some(state => !stateOrder.includes(state)) || new Set(value).size !== value.length) {
    throw new MemoryStoreError('invalid_input');
  }
  return stateOrder.filter(state => value.includes(state));
}

function success(value) {
  return { ok: true, value };
}

function failure(error) {
  let code = error instanceof MemoryStoreError ? error.code : "storage_error";
  if (isStorageBusy(error)) code = "storage_busy";
  if (["invalid_identifier", "invalid_text", "invalid_memory", "invalid_receipt",
    "invalid_revision", "invalid_limit"].includes(code)) code = "invalid_input";
  return { ok: false, error: { code, retryable: code === "storage_busy" } };
}

// Validate the trusted opt-in before composition can snapshot any constructor fields.
function qualifiedDuplicatesOption(input) {
  if (input && typeof input === 'object' && types.isProxy(input)) throw new MemoryStoreError('invalid_input');
  if (!input || typeof input !== 'object' || !('captureQualifiedDuplicates' in input)) return undefined;
  const clean = ownData(input, OPEN_OPTIONS);
  if (!Object.hasOwn(clean, 'captureQualifiedDuplicates') ||
      clean.captureQualifiedDuplicates !== 'append-matching-evidence-v1' || clean.captureQualification !== 'source-bound-v2' ||
      Object.hasOwn(clean, 'sessionEpisodes')) throw new MemoryStoreError('invalid_input');
  return clean.captureQualifiedDuplicates;
}

/** Model-free exact-namespace lifecycle and inspection facade. */
export function openMemoryCore(input) { return openWithRoleContext(input); }
function openWithRoleContext(input, roleContext) {
  const buildCore = (value, internal) => createMemoryCore(value, { ...internal, roleContext });
  if (input && typeof input === 'object' && types.isProxy(input)) throw new MemoryStoreError('invalid_input');
  busyTimeoutOption(input);
  // Strip only this opt-in before applying the retained constructor validation.
  if (input && typeof input === 'object' && 'contextRead' in input) {
    const { contextRead, ...base } = ownData(input, [...OPEN_OPTIONS, 'contextRead']);
    return openContextCore(base, contextRead, value => openWithRoleContext(value, contextRead));
  }
  qualifiedDuplicatesOption(input);
  if (!input || typeof input !== 'object' || Array.isArray(input)) return buildCore(input);
  if ('existingStore' in input) {
    input = ownData(input, OPEN_OPTIONS);
    input.existingStore = existingStoreOption(input.existingStore);
  }
  if ('storeFence' in input) {
    input = ownData(input, OPEN_OPTIONS);
    input.storeFence = storeFenceOption(input.storeFence);
    if ('existingStore' in input) fail('invalid_input');
  }
  let descriptor;
  try { descriptor = Object.getOwnPropertyDescriptor(input, 'rawConversations'); }
  catch { throw new MemoryStoreError('invalid_input'); }
  // Preserve the base constructor's inherited-option semantics when no Raw
  // wrapper was selected. Raw profiles still require strict own data.
  if (!descriptor && !('raw' in input) && !('rawSearch' in input)) return buildCore(input);
  const local = ownData(input, OPEN_OPTIONS);
  if (Object.hasOwn(local, 'raw') && typeof local.raw !== 'boolean' ||
      Object.hasOwn(local, 'rawSearch') && typeof local.rawSearch !== 'boolean' ||
      descriptor && Object.hasOwn(local, 'raw')) fail('invalid_input');
  const { raw, rawSearch, ...base } = local;
  if (!descriptor && raw !== true) return buildCore(base);
  if (!descriptor) {
    try { return composeRawCore(buildCore, base, defaultRawOptions(), {
      sources: false, lineage: true, deletion: true, localControls: true,
      rawTextReaders: false,
      captureDefault: true, searchDefault: rawSearch !== false, searchManager: localRawSearchManager(roleContext?.rawSearch), searchEmbedding: roleContext,
    }); } catch (error) {
      // Only the local Raw selection may degrade. Explicit journal profiles and
      // every other database refusal retain their existing construction errors.
      if (!isRawCapabilityRefusal(error)) throw error;
      // openDatabase has already rolled back and closed the rejected handle.
      const core = buildCore(base);
      const search = localRawSearchManager(roleContext?.rawSearch) ?? createLocalRawSearch(base.path, defaultRawOptions().port);
      search.unsupportedStore();
      return Object.freeze({ ...core, ...(rawSearch === false
        ? { getRawSearchStatus: search.methods.getRawSearchStatus } : search.methods), close() {
        const stopped = search.close(), result = core.close();
        return Promise.resolve(stopped).then(() => result);
      } });
    }
  }
  if (!Object.hasOwn(descriptor, 'value')) throw new MemoryStoreError('invalid_input');
  ownData(input, OPEN_OPTIONS);
  const options = rawOptions(descriptor.value);
  const fields = Object.getOwnPropertyDescriptors(input);
  delete fields.rawConversations;
  delete fields.rawSearch;
  const coreOptions = Object.create(Object.getPrototypeOf(input), fields);
  return composeRawCore(buildCore, coreOptions, options, {
    sources: Boolean(coreOptions.privateCards), lineage: true, deletion: true, localControls: true,
    captureDefault: true, searchDefault: rawSearch !== false, searchManager: localRawSearchManager(roleContext?.rawSearch), searchEmbedding: roleContext,
  });
}

/** Internal construction seam. Public openMemoryCore never forwards extensions. */
export function createMemoryCore(input, internal) {
  const captureQualifiedDuplicates = qualifiedDuplicatesOption(input);
  object(input, CORE_OPTIONS);
  const busyTimeoutMs = busyTimeoutOption(input);
  const privateCards = privateCardOptions(input.privateCards);
  const methodPackages = methodPackageOptions(input.methodPackages);
  if (privateCards?.currentDependencies && !methodPackages) fail('invalid_input');
  const assets = assetOptions(input.assets);
  const roleProfiles = roleProfileOptions(input.roleProfiles);
  const decisionReview = decisionReviewOption(input);
  const policyDescriptor = Object.getOwnPropertyDescriptor(input, 'captureSourcePolicy');
  const captureSourcePolicy = policyDescriptor?.value;
  const evidenceOnly = captureSourcePolicy === 'indexed-evidence-v1';
  if (policyDescriptor && (!Object.hasOwn(policyDescriptor, 'value') ||
      !['indexed-windows-v1', 'indexed-evidence-v1'].includes(captureSourcePolicy) ||
      evidenceOnly && ['captureQualification', 'captureEvidence', 'captureRationale', 'sessionEpisodes']
        .some(key => Object.hasOwn(input, key)))) {
    throw new MemoryStoreError('invalid_input');
  }
  const sourceCandidateDescriptor = Object.getOwnPropertyDescriptor(input, 'sourceCandidatePolicy');
  const sourceCandidatePolicy = sourceCandidateDescriptor?.value;
  if (sourceCandidateDescriptor && (!Object.hasOwn(sourceCandidateDescriptor, 'value') ||
      sourceCandidatePolicy !== BOUNDED_KEYSET_SOURCE_CANDIDATES.version)) {
    throw new MemoryStoreError('invalid_input');
  }
  const hasCaptureDeadline = Object.hasOwn(input, 'captureDeadlineMs');
  const captureDeadlineMs = hasCaptureDeadline ? input.captureDeadlineMs : undefined;
  if (hasCaptureDeadline && (!Number.isSafeInteger(captureDeadlineMs) ||
      captureDeadlineMs < 1 || captureDeadlineMs > 120_000)) throw new MemoryStoreError('invalid_input');
  const captureQualification = Object.hasOwn(input, 'captureQualification') ? input.captureQualification : undefined;
  if (Object.hasOwn(input, 'captureQualification') && !['source-bound-v1', 'source-bound-v2'].includes(captureQualification)) {
    throw new MemoryStoreError('invalid_input');
  }
  const captureRationale = evidenceOnly ? undefined : input.captureRationale;
  if (Object.hasOwn(input, 'captureRationale') && (captureRationale !== 'source-bound-v1' || captureQualification !== 'source-bound-v2')) {
    throw new MemoryStoreError('invalid_input');
  }
  const captureEvidence = evidenceOnly ? undefined : input.captureEvidence;
  if (Object.hasOwn(input, 'captureEvidence') && (captureEvidence !== 'staged-v1' || captureQualification !== 'source-bound-v2')) {
    throw new MemoryStoreError('invalid_input');
  }
  if (policyDescriptor && !evidenceOnly && (captureQualification !== 'source-bound-v2' ||
      captureEvidence !== undefined || captureRationale !== undefined)) {
    throw new MemoryStoreError('invalid_input');
  }
  const sessionEpisodes = Object.hasOwn(input, 'sessionEpisodes') ? episodeOptions(input.sessionEpisodes) : undefined;
  if (sessionEpisodes && (captureQualification !== 'source-bound-v2' || captureEvidence !== 'staged-v1')) throw new MemoryStoreError('invalid_input');
  const model = input.model;
  if (model?.onDiagnostic !== undefined && typeof model.onDiagnostic !== 'function') throw new MemoryStoreError('invalid_input');
  if (input.contentSafety !== undefined && input.contentSafety !== 's2h-v1') fail('invalid_input');
  const runtime = (internal?.createRuntime ?? createMemoryRuntime)({ path: input.path,
    ...(busyTimeoutMs !== undefined ? { busyTimeoutMs } : {}),
    ...(input.contentSafety !== undefined ? { contentSafety: input.contentSafety } : {}),
    ...(input.existingStore ? { existingStore: input.existingStore } : {}),
    ...(input.storeFence ? { storeFence: input.storeFence } : {}),
    ...(methodPackages ? { methodPackages } : {}),
    ...(assets ? { assets } : {}),
    ...(roleProfiles ? { roleProfiles } : {}),
    ...(privateCards ? { privateCards } : {}), ...(decisionReview ? { decisionReview: 'required-v1' } : {}), ...(sessionEpisodes ? { sessionEpisodes } : {}) },
    { engineCards: typeof model?.consolidate === 'function' });
  try {
  const { storeId, cursorSecret } = runtime.identity;
  let engineCards, engineCardsLoading;
  const engineConfigured = typeof model?.consolidate === 'function';
  for (const port of [input.cardRelations, input.cardVectors])
    if (port !== undefined && typeof port?.read !== 'function') fail('invalid_input');
  async function loadEngineCards() {
    engineCardsLoading ??= (async () => {
      const { createEngineCardMaintenance } = await import('./engine-card-maintenance.mjs');
      const storage = await runtime.engineCardStorage(); runtime.ready();
      return engineCards = createEngineCardMaintenance({ storage, model,
        relations: input.cardRelations, vectors: input.cardVectors });
    })();
    return engineCardsLoading;
  }

  function namespaceBinding(ns) {
    return createHmac("sha256", cursorSecret)
      .update(JSON.stringify(publicNamespace(ns))).digest("base64url");
  }

  function encodeCursor(payload) {
    const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
    const signature = createHmac("sha256", cursorSecret).update(body).digest("base64url");
    return `${body}.${signature}`;
  }

  function decodeCursor(cursor, binding, suppressionEpoch = false) {
    if (typeof cursor !== "string" || cursor.length > 8_192) {
      throw new MemoryStoreError("invalid_cursor");
    }
    const parts = cursor.split(".");
    if (parts.length !== 2 || parts.some((part) => !/^[A-Za-z0-9_-]+$/.test(part))) {
      throw new MemoryStoreError("invalid_cursor");
    }
    const expected = createHmac("sha256", cursorSecret).update(parts[0]).digest();
    const supplied = Buffer.from(parts[1], "base64url");
    if (supplied.toString("base64url") !== parts[1] || supplied.length !== expected.length ||
        !timingSafeEqual(supplied, expected)) {
      throw new MemoryStoreError("invalid_cursor");
    }
    let payload;
    try {
      const decoded = Buffer.from(parts[0], "base64url");
      if (decoded.toString("base64url") !== parts[0]) throw new Error("noncanonical");
      payload = JSON.parse(decoded.toString("utf8"));
    } catch {
      throw new MemoryStoreError("invalid_cursor");
    }
    const allowedKeys = [...Object.keys(binding), "e", "a", ...(suppressionEpoch ? ["h"] : [])];
    if (!payload || typeof payload !== "object" || Array.isArray(payload) ||
        Object.keys(payload).length !== allowedKeys.length ||
        Object.keys(payload).some((key) => !allowedKeys.includes(key)) ||
        Object.keys(binding).some((key) => payload[key] !== binding[key])) {
      throw new MemoryStoreError("invalid_cursor");
    }
    if (suppressionEpoch && typeof payload.h !== "string") throw new MemoryStoreError("invalid_cursor");
    if (!Number.isSafeInteger(payload.e) || payload.e < 1 || !payload.a ||
        typeof payload.a !== "object" || Array.isArray(payload.a)) {
      throw new MemoryStoreError("invalid_cursor");
    }
    return payload;
  }

  function invoke(work) {
    try { return success(work()); } catch (error) { return failure(error); }
  }

  function admit(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ["namespace", "memory", "receipts", "conflictHints", "qualification", "procedural"]);
      const ns = contractNamespace(input.namespace);
      const memory = contractMemory(input.memory);
      if (!Array.isArray(input.receipts) || input.receipts.length < 1 || input.receipts.length > 4) {
        throw new MemoryStoreError("invalid_input");
      }
      const receipts = input.receipts.map(contractReceipt);
      const conflictHints = contractConflictHints(input.conflictHints);
      if (Object.hasOwn(input, 'qualification')) qualificationSources(input.memory.content, input.receipts);
      const qualification = Object.hasOwn(input, 'qualification') ? qualificationInput(input.qualification, receipts) : undefined;
      const result = runtime.admit(ns, { ...memory, receipts, receiptTimes: input.receipts.map(receipt => receiptEventTime(receipt.occurredAt)), conflictHints, qualification, ...(Object.hasOwn(input, "procedural") ? { procedural: input.procedural } : {}) });
      return { memory: { id: result.memory.id, revision: result.memory.revision },
        deduplicated: result.deduplicated, indexRevision: result.indexRevision,
        ...(result.reviewEffects ? { reviewEffects: result.reviewEffects } : {}) };
    });
  }

  function list(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ["namespace", "statuses", "states", "limit", "cursor", "reviewState"]);
      const ns = contractNamespace(input.namespace);
      if (input.reviewState !== undefined && (!decisionReview || input.reviewState !== 'awaiting')) throw new MemoryStoreError('invalid_input');
      const selected = statuses(input.statuses);
      const selectedStates = states(input.states);
      const count = contractLimit(input.limit);
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: "list",
        f: selected.join(","), l: count,
        ...(input.reviewState ? { reviewState: input.reviewState } : {}),
        ...(selectedStates.length === 1 ? { states: selectedStates[0] } : {}) };
      let cursor;
      if (input.cursor !== undefined) cursor = decodeCursor(input.cursor, binding);
      const page = runtime.listPage(ns, selected, count, cursor?.a, cursor?.e, selectedStates, input.reviewState);
      const memories = page.rows.slice(0, count);
      const exhausted = page.rows.length <= count;
      const last = memories.at(-1);
      return { memories,
        nextCursor: exhausted ? null : encodeCursor({ ...binding, e: page.epoch,
          a: { updatedAt: last.updatedAt, id: last.id } }), exhausted };
    });
  }

  function get(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ["namespace", "memoryId", "receiptLimit", "receiptCursor", "includeQualification", "includeAwaiting"]);
      if (Object.hasOwn(input, 'includeAwaiting') && (typeof input.includeAwaiting !== 'boolean' || input.includeAwaiting && !decisionReview)) throw new MemoryStoreError('invalid_input');
      if (Object.hasOwn(input, 'includeQualification') && typeof input.includeQualification !== 'boolean') {
        throw new MemoryStoreError('invalid_input');
      }
      const ns = contractNamespace(input.namespace);
      const memoryId = contractId(input.memoryId);
      const count = contractLimit(input.receiptLimit);
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: "get",
        m: memoryId, l: count, ...(input.includeAwaiting ? { includeAwaiting: true } : {}) };
      let cursor;
      if (input.receiptCursor !== undefined) cursor = decodeCursor(input.receiptCursor, binding);
      const page = runtime.getPage(ns, memoryId, count, cursor?.a, cursor?.e, input.includeQualification === true, input.includeAwaiting === true);
      const receipts = page.receipts.slice(0, count);
      const exhausted = page.receiptComplete;
      return { memory: page.memory, receipts, ...(page.procedural ? { procedural: page.procedural } : {}), placements: page.placements, conflicts: page.conflicts,
        ...(input.includeQualification === true ? { qualification: page.qualification } : {}),
        ...(page.supersession ? { supersession: page.supersession } : {}),
        nextReceiptCursor: exhausted ? null : encodeCursor({ ...binding, e: page.epoch,
          a: { row: page.receiptScan } }), exhausted };
    });
  }

  function correct(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ["namespace", "memoryId", "expectedRevision", "content", "kind", "receipt"]);
      const ns = contractNamespace(input.namespace);
      const memoryId = contractId(input.memoryId);
      const expectedRevision = contractRevision(input.expectedRevision);
      const memory = contractMemory({ content: input.content, kind: input.kind });
      const receipt = contractReceipt(input.receipt);
      const result = runtime.correct(ns, memoryId, { ...memory, receipts: [receipt], receiptTimes: [receiptEventTime(input.receipt.occurredAt)] },
        expectedRevision, { detail: true });
      return { memory: result.detail, indexRevision: result.indexRevision };
    });
  }

  function listReviewConflicts(input) {
    return invoke(() => {
      runtime.ready(); object(input, ['namespace', 'limit', 'cursor', 'status']);
      const ns = contractNamespace(input.namespace), count = contractLimit(input.limit);
      const status = input.status ?? 'all';
      if (input.status === null || !['pending', 'restored', 'dropped', 'all'].includes(status)) throw new MemoryStoreError('invalid_input');
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'listReviewConflicts', l: count, q: status };
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding);
      const page = runtime.listReviewConflicts(ns, count, status, cursor?.a, cursor?.e);
      const rows = page.rows.slice(0, count), last = rows.at(-1), exhausted = page.rows.length <= count;
      return { conflicts: rows.map(row => ({ memoryId: row.memory_id, targetId: row.target_id,
          status: row.status === 'applied' ? 'restored' : row.status, reason: row.drop_reason })), exhausted,
        nextCursor: exhausted ? null : encodeCursor({ ...binding, e: page.epoch,
          a: { memoryId: last.memory_id, targetId: last.target_id } }) };
    });
  }

  function listReviewTransitions(input) {
    return invoke(() => {
      runtime.ready(); object(input, ['namespace', 'limit', 'cursor', 'status']);
      const ns = contractNamespace(input.namespace), count = contractLimit(input.limit);
      const status = input.status ?? 'unresolved';
      if (input.status === null || !['unresolved', 'applied', 'dropped', 'all'].includes(status)) throw new MemoryStoreError('invalid_input');
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'listReviewTransitions', l: count, q: status };
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding);
      const page = runtime.listReviewTransitions(ns, count, status, cursor?.a, cursor?.e);
      const rows = page.rows.slice(0, count), last = rows.at(-1), exhausted = page.rows.length <= count;
      return { transitions: rows.map(row => ({ ...JSON.parse(row.result),
          predecessor: { memoryId: row.previous_id, revision: row.predecessor_current_revision },
          replacement: { memoryId: row.replacement_id, revision: row.replacement_current_revision } })), exhausted,
        nextCursor: exhausted ? null : encodeCursor({ ...binding, e: page.epoch,
          a: { replacementId: last.replacement_id, predecessorId: last.previous_id } }) };
    });
  }

  function resolveReview(action, input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'memoryId', 'expectedRevision', 'actionId', ...(action === 'confirm' ? ['receipt'] : [])]);
      const ns = contractNamespace(input.namespace);
      const value = { memoryId: contractId(input.memoryId), expectedRevision: contractRevision(input.expectedRevision),
        actionId: contractId(input.actionId) };
      if (action === 'confirm') {
        value.receipt = contractReceipt(input.receipt);
        if (value.receipt.role !== 'user') throw new MemoryStoreError('invalid_input');
      }
      return runtime.resolveReview(ns, action, value);
    });
  }

  function forget(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ["namespace", "memoryId", "expectedRevision"]);
      const ns = contractNamespace(input.namespace);
      return runtime.forget(ns, contractId(input.memoryId),
        contractRevision(input.expectedRevision));
    });
  }

  function supersede(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'memoryId', 'expectedRevision', 'replacement', 'receipts']);
      const ns = contractNamespace(input.namespace);
      const id = contractId(input.memoryId);
      const expectedRevision = contractRevision(input.expectedRevision);
      const replacement = contractMemory(input.replacement);
      const receipts = denseArray(input.receipts, 1, 4).map(contractReceipt);
      return runtime.supersede(ns, id, { ...replacement, receipts, receiptTimes: input.receipts.map(receipt => receiptEventTime(receipt.occurredAt)) }, expectedRevision);
    });
  }

  function admissionKey(input) {
    if (typeof input.payloadDigest !== 'string' || !/^[a-f0-9]{64}$/.test(input.payloadDigest)) {
      throw new MemoryStoreError('invalid_input');
    }
    return { client: contractId(input.client), ...(input[keepAdmissionKey] ? { keepActionId: contractId(input.eventId) } : {}), eventId: contractId(input.eventId),
      payloadDigest: input.payloadDigest };
  }

  function exactFields(input, fields) {
    object(input, fields);
    if (fields.some(field => !Object.hasOwn(input, field))) throw new MemoryStoreError('invalid_input');
  }

  function qualifiedRef(input) {
    exactFields(input, ['memoryId', 'expectedRevision']);
    return { memoryId: contractId(input.memoryId), expectedRevision: contractRevision(input.expectedRevision) };
  }

  function bindQualifiedClaim(input) {
    return invoke(() => {
      runtime.ready();
      exactFields(input, ['namespace', 'memoryId', 'expectedRevision', 'slotId', 'singleClaim']);
      if (input.singleClaim !== true) throw new MemoryStoreError('invalid_input');
      const ns = contractNamespace(input.namespace);
      return runtime.bindQualifiedClaim(ns, { memoryId: contractId(input.memoryId),
        expectedRevision: contractRevision(input.expectedRevision),
        slotId: input.slotId === null ? null : contractId(input.slotId) });
    });
  }

  function transitionQualified(input) {
    return invoke(() => {
      runtime.ready();
      exactFields(input, ['namespace', 'predecessor', 'replacement']);
      return runtime.transitionQualified(contractNamespace(input.namespace), {
        predecessor: qualifiedRef(input.predecessor), replacement: qualifiedRef(input.replacement) });
    });
  }

  function transitionQualifiedSet(input) {
    return invoke(() => {
      runtime.ready();
      exactFields(input, ['namespace', 'predecessors', 'replacement']);
      const predecessors = denseArray(input.predecessors, 1, 5).map(qualifiedRef)
        .sort((left, right) => left.memoryId < right.memoryId ? -1 : left.memoryId > right.memoryId ? 1 : 0);
      return runtime.transitionQualifiedSet(contractNamespace(input.namespace), {
        predecessors, replacement: qualifiedRef(input.replacement) });
    });
  }

  function claimAdmission(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'client', 'eventId', 'payloadDigest', 'leaseMs']);
      const ns = contractNamespace(input.namespace);
      const key = admissionKey(input);
      const leaseMs = contractRevision(input.leaseMs);
      if (leaseMs > ADMISSION_LEASE_MS) throw new MemoryStoreError('invalid_input');
      return runtime.claimAdmission(ns, { ...key, leaseMs });
    });
  }

  function inspectAdmission(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'client', 'eventId', 'includeInitialClassification']);
      if (['namespace', 'client', 'eventId'].some(field => !Object.hasOwn(input, field)) ||
          Object.hasOwn(input, 'includeInitialClassification') &&
          typeof input.includeInitialClassification !== 'boolean') throw new MemoryStoreError('invalid_input');
      return runtime.inspectAdmission(contractNamespace(input.namespace), {
        client: contractId(input.client), eventId: contractId(input.eventId),
        ...(input.includeInitialClassification === true ? { includeInitialClassification: true } : {}),
      });
    });
  }

  function admissionItems(input, episode = false) {
    return denseArray(input, 0, 5).map((item) => {
      object(item, ['content', 'kind', 'confidence', 'receipts', 'conflictHints', 'qualification', ...(episode ? ['procedural'] : [])]);
      if (typeof item.confidence !== 'number' || !Number.isFinite(item.confidence) ||
          item.confidence < 0 || item.confidence > 1) throw new MemoryStoreError('invalid_input');
      const memory = contractMemory({ content: item.content, kind: item.kind }, 600);
      const receipts = denseArray(item.receipts, 1, 4).map(contractReceipt);
      const conflictHints = contractConflictHints(item.conflictHints);
      if (Object.hasOwn(item, 'qualification')) qualificationSources(item.content, item.receipts);
      const qualification = Object.hasOwn(item, 'qualification') ? qualificationInput(item.qualification, receipts) : undefined;
      return { ...memory, origin: 'agent-inferred', confidence: item.confidence, receipts, receiptTimes: item.receipts.map(receipt => receiptEventTime(receipt.occurredAt)), ...(episode ? { optionalReceiptTimes: true } : {}), conflictHints, qualification,
        ...(episode && Object.hasOwn(item, 'procedural') ? { procedural: item.procedural } : {}) };
    });
  }

  function finishAdmissionValidated(input, captureInitial, deadline, qualifiedDuplicates) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'client', 'eventId', 'payloadDigest', 'token', 'items']);
      const ns = contractNamespace(input.namespace);
      const key = admissionKey(input);
      const token = contractId(input.token);
      const items = admissionItems(input.items, captureInitial && Boolean(sessionEpisodes));
      return captureInitial ? runtime.finishCapturedAdmission(ns, { ...key, token, items }, deadline, qualifiedDuplicates) :
        runtime.finishAdmission(ns, { ...key, token, items });
    });
  }

  function finishAdmission(input) { return finishAdmissionValidated(input, false); }

  function beginInitialClassification(input, deadline) {
    return invoke(() => {
      runtime.ready();
      const ns = contractNamespace(input.namespace);
      const key = admissionKey(input);
      return runtime.beginInitialClassification(ns, key, input.admitted, input.selected, deadline);
    });
  }

  function failInitialClassification(input) {
    return invoke(() => {
      runtime.ready();
      const ns = contractNamespace(input.namespace);
      const key = admissionKey(input);
      return runtime.failInitialClassification(ns, key, contractId(input.token));
    });
  }

  function applyInitialPlacement(input, deadline) {
    return invoke(() => {
      runtime.ready();
      const ns = contractNamespace(input.namespace);
      const key = admissionKey(input);
      const proposal = placementProposal(input.proposal);
      const guards = memoryGuards(input.expectedMemoryRevisions,
        proposal.items.map(item => item.memoryId));
      return runtime.applyInitialPlacement(ns, key, contractId(input.token), proposal, guards,
        contractRevision(input.expectedIndexRevision), deadline);
    });
  }

  function abandonAdmission(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'client', 'eventId', 'payloadDigest', 'token']);
      const ns = contractNamespace(input.namespace);
      return runtime.abandonAdmission(ns, { ...admissionKey(input), token: contractId(input.token) });
    });
  }

  function inspectCaptureEvidence(input) {
    return invoke(() => {
      runtime.ready();
      exactFields(input, ['namespace', 'client', 'eventId']);
      return runtime.inspectCaptureEvidence(contractNamespace(input.namespace), {
        client: contractId(input.client), eventId: contractId(input.eventId),
      });
    });
  }

  function discardCaptureEvidence(input) {
    return invoke(() => {
      runtime.ready();
      exactFields(input, ['namespace', 'client', 'eventId']);
      return runtime.discardCaptureEvidence(contractNamespace(input.namespace), {
        client: contractId(input.client), eventId: contractId(input.eventId),
      });
    });
  }

  function rebuildIndex(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'expectedIndexRevision', 'limit', 'cursor']);
      const ns = contractNamespace(input.namespace);
      const expectedIndexRevision = contractRevision(input.expectedIndexRevision);
      const count = input.limit === undefined ? 500 : input.limit;
      if (!Number.isInteger(count) || count < 1 || count > 500) {
        throw new MemoryStoreError('invalid_input');
      }
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'rebuild',
        l: count, r: expectedIndexRevision };
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding);
      if (cursor && cursor.e !== expectedIndexRevision) throw new MemoryStoreError('invalid_cursor');
      const result = runtime.rebuildIndex(ns, { expectedIndexRevision, limit: count,
        ...(cursor ? { progress: cursor.a } : {}) });
      return { state: result.state, indexRevision: result.indexRevision,
        nextCursor: result.progress === null ? null : encodeCursor({ ...binding,
          e: expectedIndexRevision, a: result.progress }),
        exhausted: result.exhausted, invalidRefs: result.invalidRefs };
    });
  }

  function applyPlacement(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'proposal', 'expectedMemoryRevisions', 'expectedIndexRevision']);
      const ns = contractNamespace(input.namespace);
      const proposal = placementProposal(input.proposal);
      const guards = memoryGuards(input.expectedMemoryRevisions, proposal.items.map((item) => item.memoryId));
      return runtime.applyPlacement(ns, proposal, guards, contractRevision(input.expectedIndexRevision));
    });
  }

  function linkMocs(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'parentId', 'expectedParentRevision', 'childId',
        'expectedChildRevision', 'expectedIndexRevision']);
      return runtime.linkMocs(contractNamespace(input.namespace), {
        parentId: contractId(input.parentId), childId: contractId(input.childId),
        expectedParentRevision: contractRevision(input.expectedParentRevision),
        expectedChildRevision: contractRevision(input.expectedChildRevision),
        expectedIndexRevision: contractRevision(input.expectedIndexRevision),
      });
    });
  }

  function map(input) {
    return mapPage(input);
  }

  function mapPage(input, navigation, { catalogOnly = false } = {}) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'purpose', 'parentRef', 'limit', 'cursor', 'tokenBudget']);
      const ns = contractNamespace(input.namespace);
      const purpose = input.purpose ?? 'recall';
      if (!['recall', 'classification'].includes(purpose)) throw new MemoryStoreError('invalid_input');
      const count = contractLimit(input.limit ?? 100);
      const budget = contractRevision(input.tokenBudget ?? 4000);
      if (budget > 4000) throw new MemoryStoreError('invalid_input');
      let parentRef;
      if (input.parentRef !== undefined) {
        object(input.parentRef, ['mocId', 'revision']);
        parentRef = { mocId: contractId(input.parentRef.mocId), revision: contractRevision(input.parentRef.revision) };
      }
      // Require a counter before accessing content, even for an empty map.
      const safetyLayout = runtime.suppressionFence(ns, true);
      if(safetyLayout&&typeof modelPortValue(model,'countTokens','token_count_unavailable')!=='function')throw new MemoryStoreError('token_count_unavailable');
      if (!safetyLayout) countTokens(model, '');
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'map',
        p: parentRef ? JSON.stringify(parentRef) : '', f: purpose, l: count, b: budget };
      if (catalogOnly) binding.o = 'classification_catalog';
      if (navigation) Object.assign(binding, { o: 'recall_map',
        q: navigation.queryDigest, x: QUERY_EXCERPT_VERSION,
        policy: navigation.sourceCandidatePolicy ?? QUERY_CANDIDATE_VERSION,
        scan: navigation.sourceCandidatePolicy ? BOUNDED_KEYSET_SOURCE_CANDIDATES.scan : QUERY_SCAN_LIMIT });
      if (navigation?.sourceMode) Object.assign(binding, { sourceMode: navigation.sourceMode,
        sourcePolicy: SOURCE_QUERY_CANDIDATE_VERSION, sourceReceiptLimit: SOURCE_QUERY_RECEIPT_LIMIT });
      if (navigation?.sourceCandidatePolicy) Object.assign(binding, {
        physicalPage: BOUNDED_KEYSET_SOURCE_CANDIDATES.page,
        top: BOUNDED_KEYSET_SOURCE_CANDIDATES.top,
      });
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding, safetyLayout);
      if (cursor && (!Number.isSafeInteger(cursor.a.offset) || cursor.a.offset < 0 ||
          Object.keys(cursor.a).length !== 1)) throw new MemoryStoreError('invalid_cursor');
      const offset = cursor?.a.offset ?? 0;
      let page;
      if (navigation) {
        const key = namespaceBinding(ns);
        let snapshot = navigation.pages.get(key);
        if (!snapshot) {
          snapshot = runtime.queryCandidateRows(ns, { score: navigation.score, memoryLabel: navigation.excerpt,
            ...(navigation.sourceMode ? { sourceReceiptLimit: SOURCE_QUERY_RECEIPT_LIMIT } : {}),
            ...(navigation.sourceCandidatePolicy ? { sourceCandidatePolicy: navigation.sourceCandidatePolicy } : {}) });
          navigation.pages.set(key, snapshot);
        }
        if (safetyLayout && cursor && cursor.h !== snapshot.suppressionEpoch) throw new MemoryStoreError('invalid_cursor');
        if (cursor && cursor.e !== snapshot.epoch) throw new MemoryStoreError('cursor_stale');
        runtime.assertEpoch(ns, snapshot.epoch, snapshot.suppressionEpoch);
        if (offset > snapshot.rows.length) throw new MemoryStoreError('invalid_cursor');
        page = { ...snapshot, rows: snapshot.rows.slice(offset, offset + count + 1) };
      } else {
        page = runtime.mapRows(ns, { purpose, parentRef, limit: count, offset, expectedEpoch: cursor?.e, expectedSuppressionEpoch: safetyLayout ? cursor?.h : undefined,
          catalogOnly });
      }
      if (safetyLayout) {
        if (cursor && cursor.h !== page.suppressionEpoch) throw new MemoryStoreError('invalid_cursor');
        binding.h = page.suppressionEpoch;
        // The existing page transaction captures the request proof before any
        // caller port. The availability check above is inert; caller code runs
        // only after that transaction closes, with its normal E1 observation.
        countTokens(model, '');
      }
      const capacity = Math.min(count, page.rows.length);
      const probe = (take) => {
        const selected = page.rows.slice(0, take);
        const pageEnded = take === page.rows.length;
        const exhausted = pageEnded && page.scanExhausted !== false;
        const value = { items: selected.filter((row) => row.item).map((row) => row.item),
          nextCursor: pageEnded ? null : encodeCursor({ ...binding, e: page.epoch, a: { offset: offset + take } }),
          exhausted, truncatedBy: exhausted ? null : take < capacity ? 'token_budget' : 'page_limit',
          indexRevision: page.epoch,
          invalidRefs: selected.filter((row) => row.invalidRef).map((row) => row.invalidRef) };
        return countTokens(model, JSON.stringify(success(value))) <= budget ? value : null;
      };
      // The full page can lose its cursor/change flags, so probe it separately.
      // Only [1, capacity - 1] has the uniform token-budget envelope shape.
      let fitted = probe(capacity);
      // Keep a one-row budget miss to two counts before searching lower fits.
      if (!fitted && capacity > 1) fitted = probe(capacity - 1);
      if (!fitted) {
        let low = 1;
        let high = capacity - 2;
        while (low <= high) {
          const take = low + Math.floor((high - low) / 2);
          const value = probe(take);
          if (value) {
            fitted = value;
            low = take + 1;
          } else {
            high = take - 1;
          }
        }
      }
      if (fitted) {
        // Return the very object whose whole success envelope was counted.
        runtime.assertEpoch(ns, page.epoch, page.suppressionEpoch);
        return fitted;
      }
      throw new MemoryStoreError('context_item_too_large');
    });
  }

  function fetch(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'refs', 'view', 'cursor', 'tokenBudget', 'includeQualification', 'contextMode']);
      const includeQualification = Object.hasOwn(input, 'includeQualification') ? input.includeQualification : false;
      if (typeof includeQualification !== 'boolean') throw new MemoryStoreError('invalid_input');
      const contextMode = Object.hasOwn(input, 'contextMode') ? input.contextMode : undefined;
      if ((Object.hasOwn(input, 'contextMode') && !isSourceContext(contextMode)) ||
          (isSourceContext(contextMode) && includeQualification)) throw new MemoryStoreError('invalid_input');
      const ns = contractNamespace(input.namespace);
      const refs = memoryRefs(input.refs);
      const view = input.view === undefined ? 'current' : input.view;
      if (!['current', 'historical'].includes(view)) throw new MemoryStoreError('invalid_input');
      if (contextMode === 'rationale-evidence' && view !== 'current') throw new MemoryStoreError('invalid_input');
      const budget = contractRevision(input.tokenBudget ?? 4000);
      if (budget > 4000) throw new MemoryStoreError('invalid_input');
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'fetch', b: budget,
        r: createHmac('sha256', cursorSecret).update(JSON.stringify(refs)).digest('base64url'),
        ...(view === 'historical' ? { view } : {}),
        ...(includeQualification ? { includeQualification: true } : {}),
        ...(isSourceContext(contextMode) ? { contextMode } : {}) };
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding);
      return fetchMemories({ runtime, model, ns, refs, view, budget, cursor, binding, encodeCursor, includeQualification, contextMode });
    });
  }

  function sourceSnapshot(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['readSet', 'limit', 'tokenBudget']);
      const namespaces = contractReadSet(input.readSet);
      const count = Object.hasOwn(input, 'limit') ? contractRevision(input.limit) : 6;
      const budget = Object.hasOwn(input, 'tokenBudget') ? contractRevision(input.tokenBudget) : 4000;
      if (count > 12 || budget > 4000) throw new MemoryStoreError('invalid_input');
      // The injected counter is caller code: validate it before reading sources,
      // then invoke it only outside the snapshot's database transactions.
      countTokens(model, '');
      const snapshot = runtime.sourceSnapshot(namespaces, count);
      const encoded = JSON.stringify(success(snapshot));
      if (Buffer.byteLength(encoded, 'utf8') > 24000 || countTokens(model, encoded) > budget) {
        throw new MemoryStoreError('context_item_too_large');
      }
      // No caller callback follows this authoritative, complete reread.
      return runtime.sourceSnapshot(namespaces, count, snapshot);
    });
  }

  async function recall(input) {
    try {
      runtime.ready();
      object(input, ['readSet', 'query', 'limit', 'includeQualification', 'contextMode', 'selectionMode', 'diagnostics']);
      const enabled = Object.hasOwn(input, 'diagnostics') ? input.diagnostics : false;
      const started = enabled === true ? performance.now() : undefined;
      if (typeof enabled !== 'boolean') throw new MemoryStoreError('invalid_input');
      const diagnostics = enabled ? { hostWaitMs: 0, storageMs: 0, storageCalls: 0, storageMaxMs: 0, storageMaxCall: null } : undefined;
      const includeQualification = Object.hasOwn(input, 'includeQualification') ? input.includeQualification : false;
      if (typeof includeQualification !== 'boolean') throw new MemoryStoreError('invalid_input');
      const contextMode = Object.hasOwn(input, 'contextMode') ? input.contextMode : undefined;
      const selectionMode = input.selectionMode;
      if (Object.hasOwn(input, 'selectionMode') &&
          (selectionMode !== 'bounded-source-scan' || !isSourceContext(contextMode))) {
        throw new MemoryStoreError('invalid_input');
      }
      if ((Object.hasOwn(input, 'contextMode') && !isSourceContext(contextMode)) ||
          (isSourceContext(contextMode) && includeQualification)) throw new MemoryStoreError('invalid_input');
      const namespaces = contractReadSet(input.readSet);
      const query = boundedText(input.query, 4000);
      const count = contractRevision(input.limit ?? 6);
      if (count > 12) throw new MemoryStoreError('invalid_input');
      const navigation = { excerpt: createQueryExcerpt(query), score: createQueryScore(query), pages: new Map(),
        ...(isSourceContext(contextMode) ? { sourceMode: contextMode } : {}),
        ...(sourceCandidatePolicy && isSourceContext(contextMode) ? { sourceCandidatePolicy } : {}),
        queryDigest: createHmac('sha256', cursorSecret)
          .update(JSON.stringify([QUERY_EXCERPT_VERSION, query])).digest('base64url') };
      const validateFresh = (candidates = []) => runtime.recallSnapshot(candidates.map((candidate) => ({
        namespace: namespaces[candidate.namespaceIndex], memoryId: candidate.memoryId,
        revision: candidate.revision,
        receiptLimit: candidate.receiptCap ?? candidate.item?.receipts?.length ?? 0,
        ...(candidate.receiptCap ? { receiptOrder: 'recent' } : {}),
      })), [], namespaces.flatMap((namespace) => {
        const page = navigation.pages.get(namespaceBinding(namespace));
        return page ? [{ namespace, indexRevision: page.epoch, suppressionEpoch: page.suppressionEpoch }] : [];
      }), includeQualification);
      const storage = { map: (request) => mapPage(request, navigation), fetch, validateFresh,
        recentReceipts: (ref, limit) => runtime.recentReceipts(namespaces[ref.namespaceIndex], ref, limit),
        finalize: (candidates, selected) => runtime.recallSnapshot(candidates.map((candidate) => ({
          namespace: namespaces[candidate.namespaceIndex], memoryId: candidate.memoryId,
          revision: candidate.revision, receiptLimit: candidate.receiptCap ?? candidate.item.receipts.length,
          ...(candidate.receiptCap ? { receiptOrder: 'recent' } : {}),
          ...(isSourceContext(contextMode) ? { sourceEvidence: candidate.item } : {}),
        })), selected, namespaces.map((namespace) => ({ namespace,
          indexRevision: navigation.pages.get(namespaceBinding(namespace)).epoch,
          suppressionEpoch: navigation.pages.get(namespaceBinding(namespace)).suppressionEpoch })), includeQualification, contextMode),
      };
      if (diagnostics) for (const name of Object.keys(storage)) {
        const call = storage[name];
        storage[name] = (...args) => {
          const start = performance.now();
          try { return call(...args); }
          finally {
            const elapsed = performance.now() - start;
            diagnostics.storageMs += elapsed;
            diagnostics.storageCalls++;
            if (diagnostics.storageCalls === 1 || elapsed > diagnostics.storageMaxMs) {
              diagnostics.storageMaxMs = elapsed;
              diagnostics.storageMaxCall = name;
            }
          }
        };
      }
      const value = await recallMemories({ model, readSet: namespaces.map(publicNamespace), query,
        limit: count, ...storage, includeQualification, contextMode, selectionMode, diagnostics });
      if (diagnostics) {
        const journalMode = readRecallJournalMode(runtime);
        const ms = value => Math.round(Math.max(0, value) * 10) / 10;
        value.diagnostics = Object.freeze({ recallMs: ms(performance.now() - started),
          hostWaitMs: ms(diagnostics.hostWaitMs), storageMs: ms(diagnostics.storageMs),
          storageCalls: diagnostics.storageCalls, storageMaxMs: ms(diagnostics.storageMaxMs),
          storageMaxCall: diagnostics.storageMaxCall, journalMode });
      }
      return success(value);
    } catch (error) { return failure(error); }
  }

  async function reviewRationaleValidated(input, deadline) {
    try {
      runtime.ready();
      object(input, ['namespace', 'refs', 'inputMode']);
      const inputMode = input.inputMode;
      if (Object.hasOwn(input, 'inputMode') && inputMode !== 'claim-focus-v1') throw new MemoryStoreError('invalid_input');
      const ns = contractNamespace(input.namespace);
      denseArray(input.refs, 1, 6);
      const refs = memoryRefs(input.refs);
      const snapshot = runtime.rationaleSnapshot(ns, refs, inputMode);
      const validateFresh = () => {
        if (JSON.stringify(runtime.rationaleSnapshot(ns, refs, inputMode)) !== JSON.stringify(snapshot)) {
          throw new MemoryStoreError('revision_conflict');
        }
      };
      deadline?.check();
      const proposals = await proposeRationale(model, snapshot.sources, validateFresh, deadline);
      deadline?.check();
      return success({ ...runtime.commitRationale(ns, refs, snapshot, proposals, deadline),
        ...(inputMode ? { inputMode } : {}) });
    } catch (error) { return failure(error); }
  }

  async function reviewRationale(input) { return reviewRationaleValidated(input); }

  async function reviewDecisionBasis(input) {
    try {
      runtime.ready();
      object(input, ['namespace', 'refs', 'inputMode']);
      if (Object.hasOwn(input, 'inputMode') && !['source-context-v1', 'source-addressed-v1'].includes(input.inputMode)) {
        throw new MemoryStoreError('invalid_input');
      }
      const inputMode = input.inputMode;
      const ns = contractNamespace(input.namespace);
      denseArray(input.refs, 1, 6);
      const refs = memoryRefs(input.refs);
      const snapshot = runtime.rationaleSnapshot(ns, refs);
      const validateFresh = () => {
        if (JSON.stringify(runtime.rationaleSnapshot(ns, refs)) !== JSON.stringify(snapshot)) {
          throw new MemoryStoreError('revision_conflict');
        }
      };
      const proposal = await reviewSourceBasis(model, snapshot.sources, validateFresh, inputMode);
      const result = { ...proposal, sources: snapshot.sources, indexRevision: snapshot.indexRevision,
        ...(inputMode ? { inputMode } : {}),
        status: 'unassessed', interpretationStatus: 'model-proposed', persistence: 'not-stored' };
      if (JSON.stringify(result).length > 24000) throw new MemoryStoreError('context_item_too_large');
      validateFresh();
      return success(result);
    } catch (error) { return failure(error); }
  }

  function getRationale(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'memoryId', 'revision', 'view']);
      if (Object.hasOwn(input, 'view') && !['decision-context', 'incident-proposals'].includes(input.view)) {
        throw new MemoryStoreError('invalid_input');
      }
      return runtime.getRationale(contractNamespace(input.namespace), {
        memoryId: contractId(input.memoryId), revision: contractRevision(input.revision),
      }, input.view);
    });
  }

  async function capture(input, keepInput, rawRegistration) {
    try {
      let deadline = sessionEpisodes || captureDeadlineMs === undefined ? undefined : createCaptureDeadline(captureDeadlineMs);
      runtime.ready();
      if (!keepInput) object(input, ['namespace', 'client', 'eventId', 'sessionId', 'messages', ...(sessionEpisodes ? ['episodeContext'] : ['causal'])]);
      const ns = contractNamespace(input.namespace);
      const namespace = publicNamespace(ns);
      const captureKey = value => keepInput ? { ...value, [keepAdmissionKey]: true } : value;
      if ((captureEvidence || evidenceOnly) && Object.hasOwn(input, 'causal')) throw new MemoryStoreError('invalid_input');
      return success(await (keepInput ? keepEpisodeCapture : sessionEpisodes ? captureEpisodeMessages : captureMessages)({ model, captureQualification, captureSourcePolicy,
        runtime, ns, sessionEpisodes, keepInput, rawRegistration,
        startAdmission: () => (deadline = captureDeadlineMs === undefined ? undefined : createCaptureDeadline(captureDeadlineMs)),
        captureRationale, captureEvidence,
        deadline, input: { ...input, namespace },
        operations: { filterCaptureSources: sources => runtime.filterCaptureSources(ns, sources),
          assertCaptureSources: sources => runtime.assertCaptureSources(ns, sources),
          // Preserve private pre-dispatch busy provenance across this internal
          // operation, including the runtime facade's entry/delivery checks.
          beginCaptureDispatch: value => {
            try { return runtime.assertCaptureEvidence(ns, { ...value, [captureDispatch]: true }, deadline); }
            catch (error) { if (isStorageBusy(error)) throw captureSourceBusy(); throw error; }
          },
          claimAdmission: (value, sources) => invoke(() => runtime.claimCapturedAdmission(ns, {
          ...admissionKey(value), leaseMs: ADMISSION_LEASE_MS,
        }, deadline, rawRegistration, sources)),
          finishAdmission: value => finishAdmissionValidated(captureKey(value), true, deadline,
            keepInput || sessionEpisodes ? undefined : captureQualifiedDuplicates),
          abandonAdmission: (value, retryable) => retryable
            ? invoke(() => runtime.abandonAdmission(ns, { ...admissionKey(captureKey(value)),
              token: contractId(value.token), retryable: true }))
            : abandonAdmission(captureKey(value)), get, map, isAwaiting: id => runtime.isAwaiting(ns, id),
          beginInitialClassification: value => beginInitialClassification(captureKey(value), deadline),
          failInitialClassification: value => failInitialClassification(captureKey(value)),
          applyInitialPlacement: value => applyInitialPlacement(captureKey(value), deadline),
          claimCaptureEvidence: (value, sources) => invoke(() => runtime.claimCaptureEvidence(ns, {
            ...admissionKey(value), leaseMs: ADMISSION_LEASE_MS, view: value.view,
          }, deadline, rawRegistration, sources)),
          assertCaptureEvidence: value => invoke(() => runtime.assertCaptureEvidence(ns, {
            ...admissionKey(captureKey(value)), token: contractId(value.token),
          })),
          reviewRationale: value => reviewRationaleValidated(value, deadline),
          discoverRationale: ({ refs, query }) => invoke(() => {
            runtime.rationaleSnapshot(ns, refs);
            const page = runtime.queryCandidateRows(ns, { score: createQueryScore(query), memoryLabel: () => '' });
            const found = [...refs]; const seen = new Set(refs.map(ref => ref.memoryId));
            for (const { item } of page.rows) {
              const ref = item.type === 'unfiled' ? item.ref : { memoryId: item.ref.childId, revision: item.ref.childRevision };
              if (!seen.has(ref.memoryId)) { seen.add(ref.memoryId); found.push(ref); }
            }
            runtime.assertEpoch(ns, page.epoch, page.suppressionEpoch);
            return { refs: found.slice(0, 6), scanExhausted: page.scanExhausted, candidatesTruncated: found.length > 6 };
          }),
          classifyPlacement: value => classifyPlacementValidated(value, deadline), applyPlacement,
          ordered: {
            claim: (snapshot, sources) => invoke(() => runtime.claimOrdered(ns, snapshot, deadline, rawRegistration, sources)),
            prepare(snapshot, order, extracted) {
              return invoke(() => {
                const items = admissionItems(extracted.map(({ sourceIndices, receiptTimes, ...item }) =>
                  receiptTimes ? { ...item, receipts: item.receipts.map((receipt, index) =>
                    ({ ...receipt, occurredAt: receiptTimes[index] })) } : item));
                return { items, discovery: runtime.discoverOrdered(ns, snapshot, order, items) };
              });
            },
            assertPrepared(snapshot, order, prepared) {
              return invoke(() => {
                if (runtime.suppressionFence(ns) === null) return;
                const current = runtime.discoverOrdered(ns, snapshot, order, prepared.items);
                if (JSON.stringify(current) !== JSON.stringify(prepared.discovery)) fail('revision_conflict');
              });
            },
            finish: (snapshot, token, order, prepared, judged) =>
              invoke(() => runtime.finishOrdered(ns, snapshot, token, order, prepared, judged, deadline)),
          } } }));
    } catch (error) { return failure(error); }
  }

  // Split messages into capture batches by whole messages, in order, so each
  // batch's extraction request fits exactly as capture measures it and meets
  // capture's own message, length and window limits. A message that cannot fit
  // alone is listed, never split. Planning makes no model call and no write.
  function planCaptureBatches(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['messages']);
      const episode = Boolean(sessionEpisodes);
      const messages = denseArray(input.messages, 1, 240).map((message) => {
        object(message, ['id', 'role', 'content', ...(episode ? ['occurredAt'] : [])]);
        return { id: message.id, role: message.role, content: message.content };
      });
      // Only message text enters an extraction request; identity is a placeholder.
      const snapshot = (batch) => captureSnapshot({ namespace: { ownerId: 'plan', scope: 'personal', projectId: null },
        client: 'plan', eventId: 'plan', sessionId: 'plan', messages: batch },
      episode ? 'source-bound-v2' : captureQualification, episode ? undefined : captureSourcePolicy);
      for (const message of messages) snapshot([message]);
      if (new Set(messages.map((message) => message.id)).size !== messages.length) throw new MemoryStoreError('invalid_input');
      countTokens(model, '');
      const fitsRequest = requestFits(model, 'extract');
      const fits = (indices) => {
        let request;
        try {
          request = extractionRequest(snapshot(indices.map((index) => messages[index])),
            { captureQualification, captureSourcePolicy, episode });
        } catch (error) {
          if (error instanceof MemoryStoreError && ['invalid_input', 'invalid_text'].includes(error.code)) return false;
          throw error;
        }
        return fitsRequest(request.system, request.input);
      };
      const batches = [];
      const oversizedMessageIndices = [];
      let batch = [];
      for (const index of messages.keys()) {
        if (batch.length && fits([...batch, index])) { batch.push(index); continue; }
        if (batch.length) batches.push(batch);
        batch = [];
        if (fits([index])) batch = [index]; else oversizedMessageIndices.push(index);
      }
      if (batch.length) batches.push(batch);
      return { batches, oversizedMessageIndices };
    });
  }

  async function endEpisodeSession(input) {
    try {
      runtime.ready();
      if (!sessionEpisodes) throw new MemoryStoreError('episode_mode_required');
      object(input, ['namespace', 'client', 'sessionId', 'generation', 'eventId']);
      const ns = contractNamespace(input.namespace);
      episodeClient(input.client);
      for (const key of ['sessionId', 'generation', 'eventId']) contractId(input[key]);
      return success(await endEpisode({ runtime, ns, model, input }));
    } catch (error) { return failure(error); }
  }

  async function keepEpisode(input) {
    try {
      runtime.ready();
      if (!sessionEpisodes) throw new MemoryStoreError('episode_mode_required');
      object(input, ['namespace', 'episodeId', 'expectedRevision', 'actionId']);
      contractId(input.episodeId);
      contractId(input.actionId);
      contractRevision(input.expectedRevision);
      return await capture({ namespace: input.namespace }, { ...input });
    } catch (error) { return failure(error); }
  }

  async function classifyPlacementValidated(input, deadline) {
    try {
      runtime.ready();
      object(input, ['namespace', 'memoryIds', 'expectedMemoryRevisions', 'mapRevision']);
      const ns = contractNamespace(input.namespace);
      const ids = uniqueIds(input.memoryIds, 5, 1);
      const guards = memoryGuards(input.expectedMemoryRevisions, ids);
      const index = contractRevision(input.mapRevision);
      if (typeof model?.classify !== 'function') {
        emitDiagnostic(model, 'classify', 'core_call', 'model_not_configured');
        throw new MemoryStoreError('model_not_configured');
      }
      const snapshot = runtime.classificationSnapshot(ns, ids, guards, index);
      const mapped = mapPage({ namespace: input.namespace, purpose: 'classification' },
        undefined, { catalogOnly: true });
      if (!mapped.ok) return mapped;
      if (mapped.value.indexRevision !== index) throw new MemoryStoreError('index_revision_conflict');
      const validateFresh = () => {
        const current = runtime.classificationSnapshot(ns, ids, guards, index);
        if (current.suppressionEpoch !== snapshot.suppressionEpoch) fail('revision_conflict');
      };
      deadline?.check();
      const value = await classify({ model, snapshot, map: mapped.value, validateFresh, deadline });
      deadline?.check();
      return success(value);
    } catch (error) { return failure(error); }
  }

  async function classifyPlacement(input) { return classifyPlacementValidated(input); }

  function episodeMutation(method, allowed, input) {
    return invoke(() => {
      runtime.ready(); object(input, ['namespace', ...allowed]);
      const ns = contractNamespace(input.namespace);
      if (input.episodeId !== undefined) contractId(input.episodeId);
      if (input.expectedRevision !== undefined) contractRevision(input.expectedRevision);
      return runtime[method](ns, input);
    });
  }
  const forgetEpisode = input => episodeMutation('forgetEpisode', ['episodeId','expectedRevision'], input);
  const correctEpisode = input => episodeMutation('correctEpisode', ['episodeId','expectedRevision','patch'], input);
  const closeEpisodeNextStep = input => episodeMutation('closeEpisodeNextStep', ['episodeId','expectedRevision','stepId','actionId','action'], input);
  const releaseEpisodeCorrection = input => episodeMutation('releaseEpisodeCorrection', ['episodeId','expectedRevision','fields'], input);
  const getCaptureControl = input => episodeMutation('getCaptureControl', [], input);
  const setCapturePaused = input => episodeMutation('setCapturePaused', ['expectedGeneration','paused'], input);
  const setProjectCapture = input => episodeMutation('setProjectCapture', ['expectedGeneration','enabled'], input);
  function setProceduralMemory(input) {
    return invoke(() => {
      runtime.ready(); object(input, ['namespace','memoryId','expectedRevision','expectedTagRevision','procedural']);
      if (!Object.hasOwn(input, 'procedural') || !Number.isSafeInteger(input.expectedTagRevision) || input.expectedTagRevision < 0) throw new MemoryStoreError('invalid_input');
      return runtime.setProceduralMemory(contractNamespace(input.namespace), { ...input,
        memoryId: contractId(input.memoryId), expectedRevision: contractRevision(input.expectedRevision) });
    });
  }
  function sessionStartContext(input) {
    return invoke(() => {
      runtime.ready();
      const config = contextInput(input), ns = contractNamespace(input.namespace);
      return assembleSessionContext({ runtime, model, ns, config });
    });
  }
  function timeRange(input, operation) {
    return invoke(() => {
      runtime.ready();
      const filter = rangeInput(input, operation), ns = contractNamespace(input.namespace);
      const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: operation,
        f: JSON.stringify(filter), l: filter.limit, order: rangeOrder(operation, filter) };
      const cursor = input.cursor === undefined ? undefined : decodeCursor(input.cursor, binding);
      if (cursor) validateRangeAnchor(cursor.a, operation === 'listMemoriesByTime' && filter.timeBasis === 'receipt');
      return rangePage(runtime.episodeRange(ns, operation, filter, cursor), filter, binding, encodeCursor, operation);
    });
  }
  const listEpisodes = input => timeRange(input, 'listEpisodes');
  const listMemoriesByTime = input => timeRange(input, 'listMemoriesByTime');
  function getEpisode(input) {
    return invoke(() => {
      runtime.ready();
      object(input, ['namespace', 'episodeId', 'sourceLimit', 'sourceCursor', 'memoryLimit', 'memoryCursor',
        'policyLimit', 'policyCursor', 'keepLimit', 'keepCursor']);
      const ns = contractNamespace(input.namespace), episodeId = contractId(input.episodeId);
      const pages = {}, bindings = {};
      const pageSpecs = [['source', 'sources', 'id'], ['memory', 'memoryLinks', 'id'],
        ['policy', 'policies', 'position'], ['keep', 'keepActions', 'ordinal']];
      for (const name of ['source', 'memory', 'policy', 'keep']) {
        const count = input[`${name}Limit`] === undefined ? 20 : input[`${name}Limit`];
        if (!Number.isSafeInteger(count) || count < 1 || count > 50) throw new MemoryStoreError('invalid_input');
        const binding = { v: 1, s: storeId, n: namespaceBinding(ns), o: 'getEpisode', m: episodeId, p: name, l: count };
        const cursor = input[`${name}Cursor`] === undefined ? undefined : decodeCursor(input[`${name}Cursor`], binding);
        if (cursor && (Object.keys(cursor.a).join() !== 'id' || (['policy', 'keep'].includes(name)
          ? !Number.isSafeInteger(cursor.a.id) || cursor.a.id < 0 : typeof cursor.a.id !== 'string'))) throw new MemoryStoreError('invalid_cursor');
        bindings[name] = binding;
        pages[name] = { limit: count, after: cursor?.a.id, epoch: cursor?.e };
      }
      const result = runtime.getEpisode(ns, { episodeId }, pages);
      const output = { episode: result.episode };
      for (const [name, key, idKey] of pageSpecs) {
        const values = result[key].slice(0, pages[name].limit), exhausted = result[key].length <= pages[name].limit;
        output[key] = { items: values, exhausted, nextCursor: exhausted ? null : encodeCursor({ ...bindings[name], e: result.epoch, a: { id: values.at(-1)[idKey] } }) };
      }
      output.status = 'complete';
      for (const [name, key, idKey] of [...pageSpecs].reverse()) {
        while (Buffer.byteLength(envelopeText(output), 'utf8') > 65536 && output[key].items.length) {
          output[key].items.pop();
          output[key].exhausted = false;
          output.status = 'budget_exhausted';
          const after = output[key].items.at(-1)?.[idKey] ?? pages[name].after ?? (['policy', 'keep'].includes(name) ? 0 : '');
          output[key].nextCursor = encodeCursor({ ...bindings[name], e: result.epoch, a: { id: after } });
        }
      }
      if (Buffer.byteLength(envelopeText(output), 'utf8') > 65536 ||
          (output.status === 'budget_exhausted' && !output.sources.items.length && !output.memoryLinks.items.length && !output.policies.items.length && !output.keepActions.items.length)) throw new MemoryStoreError('context_item_too_large');
      return output;
    });
  }

  internal?.attachCapture?.((input, registration) => capture(input, undefined, registration));
  const contentReads = new Set(['get','list','map','fetch','recall','sourceSnapshot','getEpisode','listEpisodes','listMemoriesByTime',
    'sessionStartContext','getRationale','inspectAdmission','inspectCaptureEvidence','listReviewTransitions','listReviewConflicts']);
  return contentSafetyFacade({
    ...(engineConfigured ? {
      async maintainCards(input) { try { runtime.ready(); return success(await (await loadEngineCards()).maintain(input)); } catch (error) { return failure(error); } },
      getEngineCardStatus(input) { try {
        runtime.ready();
        if (engineCards) return success(engineCards.status(input));
        object(input, ['namespace']); cardNamespace(input.namespace);
        return success({ configured: true, state: runtime.engineCardAvailable() ? 'ready' : 'unsupported_store',
          limits: ENGINE_CARD_LIMITS, lastPass: null });
      } catch (error) { return failure(error); } },
    } : {}),
    ...createMethodPackageFacade(runtime.methodPackages, methodPackages, runtime.ready,assets),
    ...createAssetFacade(runtime.assets, assets, runtime.ready),
    ...createRoleProfileFacade(runtime.roleProfiles, roleProfiles, { path: input.path, readOnly: Boolean(input.existingStore), context: internal?.roleContext, assets }),
    ...createPrivateCardFacade(runtime.privateCards, privateCards, runtime.ready, internal?.rawSources ? runtime.rawSourceReader : undefined),
    sessionStartContext, closeEpisodeNextStep, listEpisodes, listMemoriesByTime, getEpisode, forgetEpisode, correctEpisode, releaseEpisodeCorrection,
    getCaptureControl, setCapturePaused, setProjectCapture, setProceduralMemory,
    listReviewTransitions, listReviewConflicts,
    confirm: input => resolveReview('confirm', input), reject: input => resolveReview('reject', input),
    admit, list, get, correct, forget, supersede, bindQualifiedClaim, transitionQualified, transitionQualifiedSet,
    claimAdmission, finishAdmission, abandonAdmission, inspectAdmission,
    inspectCaptureEvidence, discardCaptureEvidence,
    applyPlacement, linkMocs, map, fetch, recall, sourceSnapshot, capture: input => capture(input), planCaptureBatches, keepEpisode, endEpisodeSession, classifyPlacement, rebuildIndex,
    reviewRationale, getRationale, reviewDecisionBasis,
    close() {
      runtime.close();
      return success(null);
    },
  }, { check: runtime.assertContentScope, portGuard: runtime.contentPortGuard, failure, asyncMethods: ['capture','maintainCards'],
    requestScope: (work, method) => contentWriteMethodClass(method) === 'read' ? withContentSuppressionRequest(work) : work(),
    isFailedCapture(result) {
      // Admission committed before the paused classifier. After close only its
      // failed-classification completion is deliverable; no retained identities,
      // receipts, counts or content survive this projection.
      return result?.ok===true&&result.value?.classification?.status==='failed';
    },
    validate: (method,args,result,scopes) => { if(contentReads.has(method)&&result?.ok)runtime.assertContentOutput(result.value,scopes); }, noOwner: ['close',
    'getPrivateCardCapabilities','getAssetCapabilities','getMethodPackageCapabilities'] });
  } catch (error) {
    try { runtime.close(); } catch { /* Preserve the construction failure. */ }
    throw error;
  }
}
