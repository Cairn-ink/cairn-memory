import { contentSuppressionRequestInside, hasContentSuppressionRequestInside } from './content-suppression-storage.mjs';
import { cachedContentLayout } from './content-safety-schema.mjs';
import { assertContentOutput, assertContentScopes } from './content-safety-boundary.mjs';
import { writeContentSuppressionInside, allocateContentKey, requireSuppressionTransaction, registerEngineCardPurgeInside } from './content-suppression-storage.mjs';
import { contentReadSafety, sourceReadSafety, cardContributorsInside, createContentReadMemo } from './content-safety.mjs';
import { createCardCurrentStorage, cardDependencyFence } from './card-current-storage.mjs';
import { CARD_CURRENT_METHODS } from './card-current-input.mjs';
import { createOperationLedger, createPrivateEffectWriter, createPrivateCursor } from './private-operation-helpers.mjs';
import { transaction } from './database.mjs';
import { fail } from './validation.mjs';
import { EVIDENCE_METHODS } from './private-evidence-input.mjs';
import { createPrivateEvidenceStorage } from './private-evidence-storage.mjs';
import { cardApplicabilityInside, reviewCardApplicabilityInside } from './private-evidence-schema.mjs';
import { ORGANIZATION_METHODS, ORGANIZATION_READS } from './private-organization-input.mjs';
import { createPrivateOrganizationStorage } from './private-organization-storage.mjs';
import { createCardReceiptSources } from './card-receipt-sources.mjs';
import { createCardRawSources } from './card-raw-sources.mjs';
import { cardText, keyed, noteInput, OWNER_NOTE_CAP, pageLimit, refs, sourceRef } from './private-card-input.mjs';
import { hasCardLineage, collectCardBodySourcesInside, sealCardBodyInside, checkCardActionInside,
  recordCardActionInside, cardBodyDigest } from './card-lineage.mjs';
import { isEngineCard, engineCardMetadataInside } from './content-safety.mjs';

const boundary = ns => [ns.ownerId, ns.scope, ns.projectId ?? ''];
const where = 'owner_id=? AND scope=? AND project_id=?';
const now = () => new Date().toISOString();
const size = value => Buffer.byteLength(JSON.stringify({ ok: true, value }), 'utf8');
const attribution = () => ({ sourceAuthor: null, claimant: null, subject: null,
  eventTime: null, commitment: 'unknown', status: 'unassessed' });

// Cache only successful presence probes per handle, never rows or a miss.
// installPrivateCards/installCardMemorySources run only in openDatabase startup,
// offline upgradeLayoutBase, or engine maintenance's ensureLayout transaction.
// Those installers finish before mutation work; none calls forgetting or
// owner/namespace erasure. Safety/lineage migration seeds retained incarnation/
// span facts only. No purge shares an uncommitted table-creation transaction.
// Unsupported external DDL/rollback can make a later purge fail closed.
const memoryBindingTables = new WeakSet();

// The caller owns the forget/suppression transaction. Do not use serving
// eligibility here: stale bodies and older rebuild rows must also be erased.
export function purgeEngineCardsInside(db, ns, actionId, memoryId) {
  requireSuppressionTransaction(db);
  if (!memoryBindingTables.has(db)) {
    if (!db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='card_memory_bindings'").get()) return;
    memoryBindingTables.add(db);
  }
  const rows = db.prepare(`SELECT c.* FROM private_cards c
    JOIN card_operations o ON (o.owner_id,o.scope,o.project_id,o.action_id,o.target_id)=
      (c.owner_id,c.scope,c.project_id,c.id,c.id)
    WHERE c.owner_id=? ${ns.scope === 'owner' ? '' : 'AND c.scope=? AND c.project_id=?'}
      AND o.method='consolidate' AND json_extract(o.result,'$.origin')='engine'
      AND (c.title IS NOT NULL OR c.body IS NOT NULL)
      ${memoryId === undefined ? '' : `AND EXISTS(SELECT 1 FROM card_memory_bindings b
        WHERE b.card_id=c.id AND b.memory_id=?)`}
    ORDER BY c.id`).all(ns.ownerId, ...(ns.scope === 'owner' ? [] : [ns.scope, ns.projectId ?? '']),
      ...(memoryId === undefined ? [] : [memoryId]));
  if (!rows.length) return;
  const identity = db.prepare('SELECT store_id AS storeId,cursor_secret AS cursorSecret FROM store_metadata WHERE singleton=1').get();
  const writers = createPrivateCardStorage({ db, identity, ready() {} }).engineCardWriters();
  const namespaces = new Map();
  for (const row of rows) {
    const namespace = { ownerId: row.owner_id, scope: row.scope, projectId: row.project_id };
    writers.purge(namespace, row, actionId);
    namespaces.set(JSON.stringify(namespace), namespace);
  }
  for (const namespace of namespaces.values()) db.prepare(`INSERT INTO card_epochs VALUES(?,?,?,2)
    ON CONFLICT(owner_id,scope,project_id) DO UPDATE SET generation=generation+1`)
    .run(namespace.ownerId, namespace.scope, namespace.projectId);
}

registerEngineCardPurgeInside(purgeEngineCardsInside);

/** Uses the same canonical SQLite handle as all existing Memory operations. */
export function createPrivateCardStorage({ db, identity, ready, memoryMapInside, memoryTopicInside, rawSources = false }) {
  const dependencies = createCardCurrentStorage({ db, identity });
  const secret = identity.cursorSecret;
  const binding = (purpose, value) => keyed(secret, purpose, [identity.storeId, value]);
  const receiptSources = createCardReceiptSources(db, binding);
  const raw = createCardRawSources(db, identity);
  const epoch = ns => db.prepare(`SELECT generation FROM card_epochs WHERE ${where}`)
    .get(...boundary(ns))?.generation ?? 1;
  function advance(ns) {
    db.prepare(`INSERT INTO card_epochs VALUES(?,?,?,2) ON CONFLICT(owner_id,scope,project_id)
      DO UPDATE SET generation=generation+1`).run(...boundary(ns));
  }
  const note = (ns, id) => db.prepare(`SELECT * FROM card_notes WHERE ${where} AND id=?`).get(...boundary(ns), id);
  const card = (ns, id) => db.prepare(`SELECT * FROM private_cards WHERE ${where} AND id=?`).get(...boundary(ns), id);
  function refFor(ns, row) {
    return { type: 'submitted-note', namespace: ns, sourceId: row.id, revision: row.revision,
      contentIdentity: binding('submitted-note-content-v1', [ns, row.id, row.revision, row.text]),
      completeness: 'provided-note' };
  }
  function resolve(ns, ref, memo = createContentReadMemo(db)) {
    sourceRef(ref, ns, rawSources);
    if (!sourceReadSafety(db, { identity, namespace: ns, ref, strict: true, memo }).allowed) fail('source_unavailable');
    return memo.sources.get(JSON.stringify(ref)).value;
  }
  function validateRefs(ns, values, existing = [], currentCardId = '') {
    const selected = refs(values, ns, rawSources, hasCardLineage(db)), rawBudget = raw.budget();
    let bytes = 0;
    for (const ref of selected) {
      if (ref.type === 'raw') {
        try { raw.resolve(ns,ref,rawBudget); }
        catch (error) {
          if (error.code === 'source_budget_exceeded') fail('invalid_input');
          if (!['source_unavailable','source_excluded'].includes(error.code) ||
              !existing.some(old => JSON.stringify(old) === JSON.stringify(ref))) throw error;
        }
        continue;
      }
      const table = ref.type === 'receipt' ? 'card_memory_bindings' : 'card_bindings';
      const key = ref.type === 'receipt' ? 'memory_id' : 'source_id';
      const dependents = db.prepare(`SELECT count(*) AS n FROM (SELECT DISTINCT c.id FROM ${table} b
        JOIN private_cards c ON c.id=b.card_id WHERE b.${key}=?
        AND c.state IN ('draft','confirmed') AND c.id!=? LIMIT 128)`)
        .get(ref.memoryId ?? ref.sourceId, currentCardId).n;
      if (dependents >= 128) fail('dependency_limit_reached');
      try { bytes += resolve(ns, ref).byte_count; }
      catch (error) {
        if (error.code !== 'source_unavailable' || !existing.some(old => JSON.stringify(old) === JSON.stringify(ref))) throw error;
      }
    }
    raw.checkFanout(selected, currentCardId);
    if (bytes+rawBudget.used > 64_000) fail('invalid_input');
    return selected;
  }
  function insertNote(ns, input) {
    const value = noteInput(input), bytes = Buffer.byteLength(value.text, 'utf8');
    const used = db.prepare('SELECT byte_count FROM card_note_usage WHERE owner_id=?').get(ns.ownerId)?.byte_count ?? 0;
    if (used + bytes > OWNER_NOTE_CAP) fail('quota_reached');
    const id = allocateContentKey(db, ns, 'submitted-note'), timestamp = now();
    db.prepare('INSERT INTO card_notes VALUES(?,?,?,?,1,\'available\',?,?,?,?)')
      .run(id, ...boundary(ns), value.text, bytes, value.occurredAt, timestamp);
    db.prepare(`INSERT INTO card_note_usage VALUES(?,?) ON CONFLICT(owner_id)
      DO UPDATE SET byte_count=byte_count+excluded.byte_count`).run(ns.ownerId, bytes);
    return refFor(ns, note(ns, id));
  }
  function getRefs(id, memo) {
    const values = cardContributorsInside(db, id, memo);
    if (!rawSources && values.some(ref => ref.type === 'raw')) fail('source_unavailable');
    return values;
  }
  function putRefs(id, values) {
    raw.put(id,values);
    db.prepare('DELETE FROM card_bindings WHERE card_id=?').run(id);
    db.prepare('DELETE FROM card_memory_bindings WHERE card_id=?').run(id);
    const insert = db.prepare('INSERT INTO card_bindings VALUES(?,?,?,?)');
    const memoryInsert = db.prepare('INSERT INTO card_memory_bindings VALUES(?,?,?,?,?,?)');
    values.forEach((ref, position) => ref.type === 'raw' ? undefined : ref.type === 'receipt'
      ? memoryInsert.run(id, ref.memoryId, ref.memoryRevision, ref.receiptId, JSON.stringify(ref), position)
      : insert.run(id, ref.sourceId, JSON.stringify(ref), position));
  }
  function support(ns, values, memo) {
    const available = values.length > 0 && values.every(ref => {
      try { resolve(ns, ref, memo); return true; }
      catch (error) { if (error.code === 'source_unavailable' || ref.type === 'raw' &&
        ['source_excluded','raw_crypto_unavailable'].includes(error.code)) return false; throw error; }
    });
    return { status: available ? 'eligible' : 'unavailable', applicability: 'unknown',
      reasons: [available ? 'unassessed' : values.some(ref => ref.type === 'receipt') ? 'memory_changed' : 'source_deleted'] };
  }
  function metadata(ns, row, readSet = [ns], { historicalReason = false, deadlineAt = Infinity } = {}, memo = createContentReadMemo(db)) {
    const review = cardApplicabilityInside(db, row), currentDependency = historicalReason ? null : dependencies.compare(ns, row, readSet, { deadlineAt });
    const engine = isEngineCard(row.id) ? engineCardMetadataInside(db, ns, row) : null;
    return { id: row.id, namespace: ns, revision: row.revision, state: row.state,
      bodyRevision: row.body_revision, origin: engine ? 'engine' : 'authored',
      ...(engine ? { builtAt: engine.builtAt, clusterKey: engine.clusterKey, status: 'current', sourceRevisions: engine.sourceRevisions } : {}),
      support: { ...(engine ? { status: 'eligible', applicability: 'current', reasons: ['unassessed'] } : hasCardLineage(db) && memo?.cardBodies?.get(row.id)?.header.origin === 'user-authored'
        ? {status:'eligible',applicability:'unknown',reasons:['unassessed']} : support(ns, hasCardLineage(db)?memo?.cardBodies?.get(row.id)?.refs??getRefs(row.id,memo):getRefs(row.id, memo), memo)),
        applicability: review.applicability,
        applicabilityReviewedRevision: review.reviewedRevision, checkedAt: row.updated_at,
        ...(currentDependency ? { currentDependency } : {}) },
      createdAt: row.created_at, updatedAt: row.updated_at, confirmedAt: row.confirmed_at };
  }
  function cardSafe(ns, row, method = 'getCard', memo) {
    return contentReadSafety(db, { identity, namespace: ns, method, memo, ref: { type: 'card', namespace: ns,
      cardId: row.id, revision: row.revision, bodyRevision: row.body_revision } }).allowed;
  }
  function detail(ns, row, readSet, intent) {
    const memo = intent?.safetyMemo ?? createContentReadMemo(db);
    if (!row || !cardSafe(ns, row, 'getCard', memo)) return null;
    return { ...metadata(ns, row, readSet, intent, memo), title: row.title, body: row.body,
      bindings: getRefs(row.id, memo).map(ref => ({ id: ref.type === 'raw' ? raw.bindingId(ref) : ref.sourceId ?? ref.receiptId, source: ref,
        dependency: ref.type === 'receipt' ? 'memory-interpretation' : 'source-only',
        memoryRef: ref.type === 'receipt' ? { type: 'memory', namespace: ns,
          memoryId: ref.memoryId, revision: ref.memoryRevision } : null,
        receiptId: ref.receiptId ?? null,
        role: 'required', attribution: attribution() })), triggerMemoryRefs: [] };
  }
  function existing(ns, input, state) {
    const row = card(ns, input.cardId);
    if (!row) fail('card_not_found');
    if (row.revision !== input.expectedRevision) fail('revision_conflict');
    if (row.state !== state) fail('card_state_conflict');
    return row;
  }
  const effect = createPrivateEffectWriter(db, 'card_effects');
  const ledger = createOperationLedger(db, 'card_operations');
  const receipt = (row, effectCount = 0) => ({ id: row.id, revision: row.revision,
    state: row.state, bodyRevision: row.body_revision ?? null, effectCount });
  function purgeCard(ns, row, state, actionId, timestamp = now()) {
    writeContentSuppressionInside(db, { namespace: ns, kind: 'card', key: row.id, reason: 'purge', actionId });
    db.prepare(`UPDATE private_cards SET state=?,revision=revision+1,title=NULL,body=NULL,
      updated_at=? WHERE id=?`).run(state, timestamp, row.id);
    db.prepare('DELETE FROM card_bindings WHERE card_id=?').run(row.id);
    db.prepare('DELETE FROM card_memory_bindings WHERE card_id=?').run(row.id);
    raw.put(row.id,[]);
    effect(ns, state === 'deleted' ? 'card_deleted' : 'evidence_invalidated', 'card', row.id, row.revision + 1, actionId);
    return card(ns, row.id);
  }
  function mutate(method, ns, input, currentAccess, claim) {
    if (CARD_CURRENT_METHODS.includes(method)) {
      const row = existing(ns, input, 'confirmed');
      validateRefs(ns, getRefs(row.id), [], row.id);
      return dependencies.write(ns, row, { ...input, method }, currentAccess);
    }
    if (method === 'submitSourceNote') return { source: insertNote(ns, { text: input.text, occurredAt: input.occurredAt }) };
    if (method === 'createCardDraft') {
      const value = input.input;
      const lineage=hasCardLineage(db), own=lineage && value.authoredInput !== undefined;
      const selected = own ? [] : value.authoredInput !== undefined ? [insertNote(ns, value.authoredInput)]
        : value.memoryRefs !== undefined ? receiptSources.fromMemories(ns, value.memoryRefs) : value.sources;
      const sources = validateRefs(ns, selected);
      const id = allocateContentKey(db, ns, 'card'), timestamp = now();
      db.prepare(`INSERT INTO private_cards VALUES(?,?,?,?,1,'draft',?,?,${lineage?'1':'NULL'},?,?,NULL)`)
        .run(id, ...boundary(ns), cardText(value.title, 200), cardText(value.body, 20_000), timestamp, timestamp);
      putRefs(id, sources);
      if(lineage) sealAuthored(ns,id,sources,claim,{newBody:true,own});
      return receipt(card(ns, id));
    }
    if (method === 'deleteSourceNote') {
      const row = note(ns, input.sourceId);
      if (!row) fail('source_not_found');
      if (row.revision !== input.expectedRevision) fail('revision_conflict');
      if (row.state !== 'available') fail('source_unavailable');
      writeContentSuppressionInside(db, { namespace: ns, kind: 'submitted-note', key: row.id, reason: 'purge', actionId: input.actionId });
      db.prepare(`UPDATE card_notes SET text=NULL,byte_count=0,state='deleted',revision=revision+1 WHERE id=?`).run(row.id);
      db.prepare('UPDATE card_note_usage SET byte_count=byte_count-? WHERE owner_id=?').run(row.byte_count, ns.ownerId);
      // Admission caps each note at 128 live dependents. Verify the invariant
      // before invalidation; the whole deletion rolls back if a store is corrupt.
      let count = 0;
      const dependents = db.prepare(`SELECT c.id FROM private_cards c JOIN card_bindings b ON b.card_id=c.id
        WHERE b.source_id=? AND c.state IN ('draft','confirmed') ORDER BY c.id LIMIT 129`).all(row.id);
      if (dependents.length > 128 && !hasCardLineage(db)) fail('dependency_limit_reached');
      for (const { id } of dependents) {
        const dependent = card(ns, id);
        if (dependent.state === 'draft' && !hasCardLineage(db)) purgeCard(ns, dependent, 'cancelled', input.actionId);
        else {
          db.prepare('UPDATE private_cards SET revision=revision+1,updated_at=? WHERE id=?').run(now(), id);
          effect(ns, 'evidence_invalidated', 'card', id, dependent.revision + 1, input.actionId);
        }
        count++;
      }
      effect(ns, 'evidence_invalidated', 'submitted-note', row.id, row.revision + 1, input.actionId);
      return { id: row.id, revision: row.revision + 1, state: 'deleted', bodyRevision: null, effectCount: count + 1 };
    }
    const confirmed = ['editKnowledgeCard', 'deleteKnowledgeCard'].includes(method);
    const row = existing(ns, input, confirmed ? 'confirmed' : 'draft');
    if (method === 'cancelCardDraft' || method === 'deleteKnowledgeCard') {
      return receipt(purgeCard(ns, row, method === 'cancelCardDraft' ? 'cancelled' : 'deleted', input.actionId), 1);
    }
    // Explicit human own-writing supplies a complete new body without consuming
    // the retained old bindings, including unavailable Raw sources.
    const lineage=hasCardLineage(db), own=lineage && ['keep-as-own','user-rewrite'].includes(claim?.authorization_kind);
    if(!own)getRefs(row.id);
    if (method === 'confirmCardDraft') {
      if (!cardSafe(ns, row, method)) fail('source_unavailable');
      validateRefs(ns, getRefs(row.id), [], row.id);
      db.prepare(`UPDATE private_cards SET state='confirmed',revision=revision+1,body_revision=${hasCardLineage(db)?'body_revision':'1'},
        confirmed_at=?,updated_at=? WHERE id=?`).run(now(), now(), row.id);
      if (input.applicability !== undefined) reviewCardApplicabilityInside(db, row.id, row.revision + 1, input.applicability);
      if (input.currentDependencies) dependencies.write(ns, card(ns, row.id), { ...input, expectedRevision: row.revision + 1, expectedDependencyRevision: null }, currentAccess);
      return receipt(card(ns, row.id));
    }
    const selected = validateRefs(ns, input.bindings, confirmed && !own ? getRefs(row.id) : [], row.id);
    const title = cardText(input.title, 200), body = cardText(input.body, 20_000);
    const changed=row.title!==title||row.body!==body||own;
    const bodyRevision = lineage ? row.body_revision+Number(changed) : confirmed ? row.body_revision + Number(changed) : null;
    db.prepare('UPDATE private_cards SET revision=revision+1,title=?,body=?,body_revision=?,updated_at=? WHERE id=?')
      .run(title, body, bodyRevision, now(), row.id);
    putRefs(row.id, selected);
    if(lineage)sealAuthored(ns,row.id,selected,claim,{newBody:changed,own});
    if (confirmed) reviewCardApplicabilityInside(db, row.id, row.revision + 1, input.applicability);
    effect(ns, 'evidence_invalidated', 'card', row.id, row.revision + 1, input.actionId);
    return receipt(card(ns, row.id), 1);
  }
  function sealAuthored(ns,id,values,claim,{newBody,own}) {
    if(own && values.length)fail('authority_required');
    if(own && !['authored-input','keep-as-own','user-rewrite'].includes(claim.authorization_kind))fail('authority_required');
    const sources=collectCardBodySourcesInside(db,identity,ns,values,ref=>sourceReadSafety(db,{identity,namespace:ns,ref,strict:newBody}).allowed);
    if(own) {
      const row=card(ns,id);
      Object.assign(claim,{card_id:id,body_revision:row.body_revision,body_digest:cardBodyDigest(identity,ns,row)});
      recordCardActionInside(db,claim);
    }
    sealCardBodyInside(db,{identity,namespace:ns,cardId:id,sources,newBody,authorization:own?claim:null});
  }
  const cardEpoch = ns => { const fence = cardDependencyFence(db, ns); return Object.keys(fence).length ? binding('card-dependency-cursor-v1', [epoch(ns), fence]) : epoch(ns); };
  const cardCursor = createPrivateCursor({ binding, purpose: 'card-cursor-v1', epoch: cardEpoch });
  const legacyCursor = createPrivateCursor({ binding, purpose: 'card-cursor-v1', epoch });
  function read(method, ns, input) {
    if (method === 'getCard') {
      const result = { card: detail(ns, card(ns, input.cardId)) };
      if (size(result) > (input.responseByteLimit ?? 65536)) fail('context_item_too_large');
      return result;
    }
    if (method === 'getPrivateCardUsage') assertContentScopes(db,[{ownerId:ns.ownerId,scope:'owner',projectId:''}]);
    if (method === 'getPrivateCardUsage' && cachedContentLayout(db)?.suppressionRevision) {
      const rows=db.prepare(`SELECT n.* FROM card_notes n WHERE n.owner_id=? AND n.state='available' AND EXISTS(
        SELECT 1 FROM content_suppressions f INDEXED BY content_suppression_target WHERE f.owner_id=n.owner_id
        AND f.scope=n.scope AND f.project_id=n.project_id AND f.kind='submitted-note' AND f.stable_key=n.id AND f.incarnation=n.id) LIMIT 129`).all(ns.ownerId);
      if(rows.length>128)fail('source_unavailable');
      for(const row of rows){const scope={ownerId:row.owner_id,scope:row.scope,projectId:row.project_id||null};
        if(!sourceReadSafety(db,{identity,namespace:scope,ref:refFor(scope,row)}).allowed)fail('source_unavailable');}
    }
    if (method === 'getPrivateCardUsage') return { version: 'submitted-note-usage-v1',
      ownerId: ns.ownerId, submittedNoteBytes: db.prepare('SELECT byte_count FROM card_note_usage WHERE owner_id=?').get(ns.ownerId)?.byte_count ?? 0,
      retainedSourceBytes: db.prepare('SELECT byte_count FROM card_note_usage WHERE owner_id=?').get(ns.ownerId)?.byte_count ?? 0,
      limitBytes: OWNER_NOTE_CAP, raw: 'not-implemented' };
    if (method === 'inspectCardOperation') {
      const row = db.prepare(`SELECT * FROM card_operations WHERE ${where} AND action_id=?`).get(...boundary(ns), input.operationActionId);
      return { operation: row ? { namespace: ns, actionId: row.action_id, revision: 1,
        method: row.method, targetId: row.target_id, state: 'completed', leaseId: null,
        leaseUntil: null, providerOutcome: 'not-started', result: JSON.parse(row.result),
        errorCode: null, createdAt: row.created_at, updatedAt: row.created_at } : null };
    }
    const count = pageLimit(input.limit);
    const expected = { store: identity.storeId, namespace: ns, method, limit: count,
      ...(method === 'listCards' ? { states: [...input.states].sort() } : {}),
      ...(method === 'getSource' ? { source: sourceRef(input.source, ns) } : {}) };
    const { encode: cursorEncode, decode: cursorDecode } = method === 'listCards' ? cardCursor : legacyCursor;
    const cursor = cursorDecode(input.cursor, expected, ns);
    if (method === 'getSource') {
      const row = resolve(ns, input.source), parts = [];
      let start = cursor?.after ?? 0;
      if (!Number.isSafeInteger(start) || start < 0 || start >= row.text.length ||
          (start > 0 && /[\uDC00-\uDFFF]/.test(row.text[start]))) fail('invalid_cursor');
      while (start < row.text.length && parts.length < count) {
        let end = Math.min(start + 4000, row.text.length);
        if (end < row.text.length && /[\uDC00-\uDFFF]/.test(row.text[end])) end--;
        parts.push({ start, end, text: row.text.slice(start, end) }); start = end;
      }
      let result;
      do {
        const end = parts.at(-1)?.end ?? (cursor?.after ?? 0), complete = end === row.text.length;
        result = { source: sourceRef(input.source, ns), parts: [...parts], coverage: {
          status: complete ? 'complete' : 'budget_exhausted', completeness: input.source.completeness,
          conversationCoverage: 'unknown', included: parts.length, omitted: complete ? 0 : null },
        nextCursor: complete ? null : cursorEncode({ binding: expected, epoch: epoch(ns), after: end }) };
        if (size(result) <= 65536) return result;
        parts.pop();
      } while (parts.length);
      fail('context_item_too_large');
    }
    const isCards = method === 'listCards';
    const memo = createContentReadMemo(db);
    let cardAfter, cardComplete;
    const cardRows = [];
    if (isCards) {
      const after = typeof cursor?.after === 'number' ? db.prepare(`SELECT id FROM private_cards WHERE ${where} AND rowid=?`)
        .get(...boundary(ns), cursor.after)?.id : cursor?.after ?? '';
      if (after === undefined) fail('cursor_stale');
      if (hasCardLineage(db)) {
        const probe = db.prepare(`SELECT rowid AS cursor_row,id,revision,state,body_revision,created_at,updated_at,confirmed_at
          FROM private_cards WHERE ${where} AND state=? AND id>? ORDER BY id LIMIT ?`);
        const visible = [];
        let scanned = 0, scanAfter = after;
        cardComplete = false;
        while (scanned < 1024 && visible.length <= count) {
          const batchLimit = Math.min(128, 1024 - scanned);
          const rows = input.states.flatMap(state => probe.all(...boundary(ns), state, scanAfter, batchLimit))
            .sort((a,b) => Buffer.compare(Buffer.from(a.id), Buffer.from(b.id))).slice(0, batchLimit);
          for (const row of rows) {
            scanned++; scanAfter = row.id; cardAfter = row.cursor_row;
            if (cardSafe(ns, row, 'listCards', memo)) visible.push(row);
            if (visible.length > count) break;
          }
          if (rows.length < batchLimit) { cardComplete = true; break; }
        }
        if (visible.length > count) {
          cardComplete = false;
          cardAfter = visible[count - 1].cursor_row;
        }
        // If denied bodies exhaust this turn, the cursor resumes after the
        // last examined row, including when the page contains no visible IDs.
        cardRows.push(...visible.slice(0, count));
      } else {
        const rows = db.prepare(`SELECT rowid AS cursor_row,id,revision,state,body_revision,created_at,updated_at,confirmed_at
        FROM private_cards WHERE ${where} AND state IN (${input.states.map(() => '?').join(',')}) AND id>? ORDER BY id LIMIT ?`)
          .all(...boundary(ns), ...input.states, after, count + 1);
        cardComplete = rows.length <= count;
        cardAfter = rows.slice(0, count).at(-1)?.cursor_row;
        cardRows.push(...rows.slice(0, count).filter(row => cardSafe(ns, row, 'listCards', memo)));
      }
    }
    let items = isCards ? cardRows.map(row => metadata(ns, row, undefined, undefined, memo)) :
      db.prepare(`SELECT * FROM card_effects WHERE ${where} AND ordinal>? ORDER BY ordinal LIMIT ?`)
        .all(...boundary(ns), cursor?.after ?? 0, count + 1).map(row => ({ effectId: row.effect_id,
          namespace: ns, kind: row.kind, entity: { type: row.entity_type, id: row.entity_id },
          revision: row.revision, actionId: row.action_id, affectedIds: [], cursor: null, ordinal: row.ordinal }));
    let complete = isCards ? cardComplete : items.length <= count;
    items = items.slice(0, count);
    while (true) {
      const result = { [isCards ? 'cards' : 'effects']: items,
        coverage: { status: complete ? 'complete' : 'budget_exhausted', included: items.length, omitted: complete ? 0 : null },
        nextCursor: complete ? null : cursorEncode({ binding: expected, epoch: isCards ? cardEpoch(ns) : epoch(ns),
          after: isCards ? cardAfter : items.at(-1)?.ordinal }) };
      if (size(result) <= 65536) return result;
      complete = false; items.pop();
      if (isCards) cardAfter = cardRows[items.length - 1]?.cursor_row;
      if (!items.length) fail('context_item_too_large');
    }
  }
  const evidence = createPrivateEvidenceStorage({ db, identity,
    cardDetailInside: (ns, id, readSet, options) => detail(ns, card(ns, id), readSet, options),
    receiptRefInside: (ns, memory, receipt) => receiptSources.refInside(ns, memory, receipt) });
  const organization = createPrivateOrganizationStorage({ db, identity, memoryMapInside, memoryTopicInside,
    cardDetailInside: (ns, id, readSet, options) => detail(ns, card(ns, id), readSet, options) });
  return Object.freeze({ assertContentOutput(value, scopes) { if(!cachedContentLayout(db)?.suppressionRevision)return; return assertContentOutput(db,identity,value,scopes); }, assertContentScope: (scopes,{delivery=false}={}) => { ready(); if(!cachedContentLayout(db)?.suppressionRevision)return; if(!delivery && scopes.length && hasContentSuppressionRequestInside(db) && !db.isTransaction) { contentSuppressionRequestInside(db,scopes,{defer:true}); return; } assertContentScopes(db,scopes); },
    lineageEnabled:()=>hasCardLineage(db),
    // Canonical internal writers; maintenance cannot obtain a fact-only sink.
    engineCardWriters() { return {
      seal(ns, id, refs) {
        if (hasCardLineage(db)) sealCardBodyInside(db, { identity, namespace: ns, cardId: id,
          sources: collectCardBodySourcesInside(db, identity, ns, refs,
            ref => sourceReadSafety(db, { identity, namespace: ns, ref }).allowed) });
      },
      purge(ns, row, actionId, timestamp) { purgeCard(ns, row, 'deleted', actionId, timestamp); },
    }; },
    // Internal shared-read seams: caller owns scope authorization and transaction.
    cardDetailInside(ns, id, readSet, intent) { ready(); return detail(ns, card(ns, id), readSet, intent); },
    cardMetadataInside(ns, row) { ready(); const memo = createContentReadMemo(db); return row && cardSafe(ns, row, 'listCards', memo) ? metadata(ns, row, undefined, undefined, memo) : null; },
    receiptRefInside(ns, memoryRow, receiptRow) { ready(); return receiptSources.refInside(ns, memoryRow, receiptRow); },
    payloadBinding: value => binding('card-action-v1', value),
    call(method, ns, input, payloadBinding, isRead, context) {
      ready();
      return transaction(db, () => {
        if (EVIDENCE_METHODS.includes(method)) return evidence.call(method, ns, input, context.accessGeneration);
        if (ORGANIZATION_READS.includes(method)) return organization.call(method, ns, input, context.accessGeneration);
        if (isRead) return read(method, ns, input);
        if(cachedContentLayout(db)?.suppressionRevision&&db.prepare('SELECT 1 FROM owner_suppression_epochs WHERE owner_id=?').get(ns.ownerId)&&!/^(delete|cancel|disable)/.test(method))assertContentOutput(db,identity,input,[ns],{factsOnly:true});
        const action=hasCardLineage(db)?checkCardActionInside(db,identity,ns,method,input,payloadBinding,context.audit):null;
        if(action)action.claim.authorization_kind=context.audit.authorizationKind;
        const replay = ledger.replay(ns, input.actionId, method, payloadBinding, input);
        if (replay !== undefined) return replay;
        const result = ORGANIZATION_METHODS.includes(method) ? organization.call(method, ns, input, context.accessGeneration) : mutate(method, ns, input, context.access,action?.claim);
        if (size(result) > 65536) fail('context_item_too_large');
        const target = result.source?.sourceId ?? result.id;
        ledger.record(ns, input.actionId, method, payloadBinding, target, result, now());
        if(action && !action.claim.card_id) {
          if(action.claim.authorization_kind!=='operation')fail('authority_required');
          recordCardActionInside(db,action.claim);
        }
        advance(ns);
        return result;
      });
    },
  });
}
