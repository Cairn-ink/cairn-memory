import { captureSnapshot } from './capture-input.mjs';
import { bindCommitRuntime, dispatchSynchronousCommit, withSynchronousCommitScope } from './commit-dispatch.mjs';
import { captureDispatch, captureSourceBusy } from './capture-source-safety.mjs';
import { registerContentWriteBoundary } from './content-write-context.mjs';
import { contentScopeEpochGuard, assertContentOutput, contentReceiptCount, assertContentScopes, contentSafetyFacade } from './content-safety-boundary.mjs';
import { hasLocalRawPrivacy, receiptEventTimeEnabled, cachedContentLayout, installedContentLayout, checkInstalledContentSafety } from './content-safety-schema.mjs';
import { writeContentSuppressionInside, suppressReceiptsInside, withContentSuppressionReadInside, requireSuppressionTransaction, allocateContentKey, contentSuppressionReasonInside, memoryCorrectionDenialsInside, contentSuppressionRequestFenceInside, assertContentSuppressionRequestInside, contentSuppressionRequestInside, hasContentSuppressionRequestInside, cachedContentSuppressionRequestInside } from './content-suppression-storage.mjs';
import { contentReadSafety, memoryContentIdentity, receiptReadSafety, anchoredReadSafety, createContentReadMemo, withheldReceiptIdsInside, withheldStoredReceiptIdsInside, withheldReceiptPageInside, withheldMemoryReceiptIdsInside } from './content-safety.mjs';
import { roleProfileOptions } from './role-profile-input.mjs';
import { createRoleProfileStorage } from './role-profile-storage.mjs';
import { assetOptions } from './asset-input.mjs';
import { createAssetStorage } from './asset-storage.mjs';
import { methodPackageOptions } from './method-package-input.mjs';
import { createMethodPackageStorage } from './method-package-storage.mjs';
import { decisionReviewOption, createConfirmationStorage, createHeldReviewResolver, dropHeldWork, recordHeldRetirement } from './confirmation-storage.mjs';
import { createSessionContextStorage } from './session-context.mjs';
import { createEpisodeReadProjection, createEpisodeReads } from './episode-reads.mjs';
import { createEpisodeStorage, episodeOptions } from './episode-storage.mjs';
import { createProceduralStorage } from './procedural-storage.mjs';
import { createHash } from "node:crypto";
import { openDatabase, transaction, readTransaction, isConnectionDiscarded, isStorageBusy, busyTimeoutOption } from "./database.mjs";
import { createMocStorage } from "./moc-storage.mjs";
import { createAdmissionStorage } from "./admission-storage.mjs";
import { createClassificationJournalStorage } from './classification-journal-storage.mjs';
import { createStagedEvidenceStorage } from './staged-evidence-storage.mjs';
import { createConflictStorage } from "./conflict-storage.mjs";
import { createIndexStorage } from "./index-storage.mjs";
import { createSupersessionStorage } from "./supersession-storage.mjs";
import { createOrderedCaptureStorage } from './ordered-capture-storage.mjs';
import { createQualificationStorage } from './claim-qualification-storage.mjs';
import { sourceEvidence, isSourceContext } from './source-evidence.mjs';
import { createQualifiedTransitionStorage } from './qualified-transition-storage.mjs';
import { createRationaleStorage } from './rationale-storage.mjs';
import { fail, MemoryStoreError, object, receiptEventTime } from "./validation.mjs";
import { privateCardOptions } from './private-card-input.mjs';
import { createPrivateCardStorage, purgeEngineCardsInside } from './private-card-storage.mjs';
import { createRawCardInvalidation } from './card-raw-sources.mjs';
import { purgeEngineCardOperationsInside } from './private-card-schema.mjs';
import { createRawSourceRoots } from './raw-source-roots.mjs';
import { createRawDeletionStorage } from './raw-deletion-storage.mjs';
import { createRawLineageStorage, isSourceSnapshotOverflow, SOURCE_SNAPSHOT_MS } from './raw-lineage-storage.mjs';
import { installLocalRawPrivacy } from './local-authority-schema.mjs';
import { createLocalRawPrivacyStorage } from './local-authority-storage.mjs';
import { suppressedFingerprintSQL } from './suppression-content.mjs';

const where = "owner_id = ? AND scope = ? AND project_id = ?";
const boundary = (ns) => [ns.ownerId, ns.scope, ns.projectId];
const suppressedFingerprint = suppressedFingerprintSQL();

// Internal diagnostics only; the weak key keeps the cache scoped to one open runtime.
const recallJournalModes = new WeakMap();
export function normalizeRecallJournalMode(value) {
  const mode = typeof value === 'string' ? value.toLowerCase() : '';
  return ['delete', 'truncate', 'persist', 'memory', 'wal', 'off', 'other', 'unknown'].includes(mode) ? mode : 'other';
}
export function readRecallJournalMode(runtime) {
  try {
    const entry = recallJournalModes.get(runtime);
    if (entry.mode === undefined) entry.mode = normalizeRecallJournalMode(
      entry.db.prepare('PRAGMA journal_mode').get().journal_mode);
    return entry.mode;
  } catch { return 'unknown'; }
}

/** Shared persistence runtime used by both the legacy and envelope facades. */
export function createMemoryRuntime(input, internal) {
  object(input, ["path", "sessionEpisodes", "decisionReview", "privateCards", "methodPackages", "assets", "roleProfiles", "existingStore", "storeFence", "contentSafety", "busyTimeoutMs"]);
  const busyTimeoutMs = busyTimeoutOption(input);
  const privateCards = privateCardOptions(input.privateCards);
  const methodPackages = methodPackageOptions(input.methodPackages);
  if (privateCards?.currentDependencies && !methodPackages) fail('invalid_input');
  const assets = assetOptions(input.assets);
  const roleProfiles = roleProfileOptions(input.roleProfiles);
  const sessionEpisodes = input.sessionEpisodes === undefined ? undefined : episodeOptions(input.sessionEpisodes);
  const decisionReview = decisionReviewOption(input);
  const db = openDatabase(input.path, { ...(busyTimeoutMs !== undefined ? { busyTimeoutMs } : {}), privateCards: Boolean(privateCards), currentDependencies: Boolean(privateCards?.currentDependencies) || Boolean(input.contentSafety && internal?.rawCapture), methodPackages: Boolean(methodPackages), assets: Boolean(assets), roleProfiles: Boolean(roleProfiles), rawCapture: Boolean(internal?.rawCapture),
    rawLineage: Boolean(internal?.rawLineage), rawDeletion: Boolean(internal?.rawDeletion), rawSources: Boolean(internal?.rawSources), localControls: Boolean(internal?.localControls), existingStore: input.existingStore, storeFence: input.storeFence, contentSafety: input.contentSafety });
  try {
  if (internal?.localRawPrivacy && !hasLocalRawPrivacy(db)) transaction(db, () => installLocalRawPrivacy(db));
  const localRawPrivacy = internal?.localRawPrivacy ? createLocalRawPrivacyStorage(db) : null;
  const rawLineage = createRawLineageStorage(db);
  const sourceRoots = createRawSourceRoots(db);
  const rawCards = createRawCardInvalidation(db);
  let deletion;
  let identity;
  identity = db.prepare(`SELECT store_id AS storeId, cursor_secret AS cursorSecret
      FROM store_metadata WHERE singleton = 1`).get();
  if (!identity) fail("unsupported_database");
  let closed = false;
  let mocStorage;
  const ready = () => { if (closed || !db.isOpen || isConnectionDiscarded(db)) fail("store_closed"); };
  const internalNamespace = ns => ({ ...ns, projectId: ns.projectId ?? '' });
  const cardStorage = privateCards ? createPrivateCardStorage({ db, identity, ready, rawSources: Boolean(internal?.rawSources),
    memoryMapInside: (ns, request) => mocStorage.mapRowsInside(internalNamespace(ns), request),
    memoryTopicInside: (ns, ref) => mocStorage.topicInside(internalNamespace(ns), ref) }) : undefined;

  const methodStorage = methodPackages || roleProfiles ? createMethodPackageStorage({ db, identity, ready,
    cardDetailInside: createPrivateCardStorage({ db,identity,ready,rawSources: true }).cardDetailInside }) : undefined;

  const roleStorage = roleProfiles ? createRoleProfileStorage({db,identity,ready,methods:methodStorage.roleRead}) : undefined;
  const assetStorage = assets ? createAssetStorage({ db, identity, ready }) : undefined;

  function activeRow(ns, id, contentRead = false) {
    return db.prepare(`SELECT memories.*${contentRead ? memoryAncestry() : ''} FROM memories WHERE ${where} AND id = ? AND deleted = 0`)
      .get(...boundary(ns), id);
  }

  function visibleRow(ns, id, contentRead = false) {
    const row = activeRow(ns, id, contentRead);
    return row?.review_state !== 'awaiting' ? row : undefined;
  }

  function memoryWriteSafety(ns,row) {
    if(row&&cachedContentLayout(db)?.suppressionRevision&&!contentReadSafety(db,{namespace:ns,
      ref:{type:'memory',namespace:ns,memoryId:row.id,revision:row.revision},intent:'history'}).allowed)fail('memory_suppressed');
    return row;
  }
  function currentRow(ns, id, contentRead = false) {
    const row = visibleRow(ns, id, contentRead);
    return row?.currentness === 'current' ? row : undefined;
  }

  function epoch(ns) {
    const proof=cachedContentSuppressionRequestInside(db,ns.ownerId);
    if(proof?.layout.suppressionRevision){
      // Fold the fresh denial fence into this existing canonical read. In
      // particular, caller-queued microtasks must be observed before a model
      // invocation resumes; this adds no statement or E1 allowance.
      const row=db.prepare(`SELECT n.epoch,coalesce(f.epoch_hi,0) epoch_hi,coalesce(f.epoch_lo,0) epoch_lo
        FROM (SELECT 1) anchor LEFT JOIN namespace_epochs n ON n.owner_id=? AND n.scope=? AND n.project_id=?
        LEFT JOIN owner_suppression_epochs f ON f.owner_id=?`).get(...boundary(ns),ns.ownerId);
      if(`${row.epoch_hi}:${row.epoch_lo}`!==proof.epoch)fail('evidence_unavailable');
      return row.epoch??1;
    }
    return db.prepare(`SELECT epoch FROM namespace_epochs WHERE
      owner_id = ? AND scope = ? AND project_id = ?`).get(...boundary(ns))?.epoch ?? 1;
  }

  function advanceEpoch(ns) {
    db.prepare(`INSERT INTO namespace_epochs(owner_id, scope, project_id, epoch)
      VALUES (?, ?, ?, 2) ON CONFLICT(owner_id, scope, project_id)
      DO UPDATE SET epoch = epoch + 1`).run(...boundary(ns));
    return epoch(ns);
  }

  // admitMutation retains its existing-row content-safety check too.
  function isSuppressed(ns, value) {
    if(db.prepare(suppressedFingerprint).get(...boundary(ns),value))return true;
    if(cachedContentLayout(db)?.suppressionRevision){
      const row=db.prepare(`SELECT id,revision FROM memories WHERE ${where} AND fingerprint=? AND deleted=0`).get(...boundary(ns),value);
      if(row&&!contentReadSafety(db,{namespace:ns,ref:{type:'memory',namespace:ns,memoryId:row.id,revision:row.revision},intent:'history'}).allowed)return true;
    }
    return false;
  }

  function assertNotSuppressed(ns, value) {
    if (isSuppressed(ns, value)) fail("memory_suppressed");
  }

  function suppress(ns, value) {
    db.prepare(`INSERT OR IGNORE INTO suppressed
      (owner_id, scope, project_id, fingerprint) VALUES (?, ?, ?, ?)`)
      .run(...boundary(ns), value);
  }

  const receiptKey = receipt => createHash("sha256").update(JSON.stringify(receipt)).digest("hex");

  function attach(id, receipt, now, inserted = [], origin = 'independent', occurredAt = null) {
    occurredAt = receiptEventTime(occurredAt, now);
    const eventTime = receiptEventTimeEnabled(cachedContentLayout(db));
    if (!eventTime) occurredAt = null;
    const key = receiptKey(receipt);
    // Read retained dedup first: BEFORE INSERT guards must also stop REPLACE.
    const retained = db.prepare('SELECT * FROM receipts WHERE memory_id=? AND receipt_key=?').get(id, key);
    if (retained && (retained.client !== receipt.client || retained.session_id !== receipt.sessionId ||
        retained.event_id !== receipt.eventId || retained.role !== receipt.role || retained.excerpt !== receipt.excerpt ||
        retained.occurred_at != null && occurredAt !== null && retained.occurred_at !== occurredAt)) fail('storage_error');
    const parent = db.prepare('SELECT owner_id,scope,project_id FROM memories WHERE id=?').get(id);
    const receiptId = retained?.id ?? allocateContentKey(db, { ownerId: parent.owner_id, scope: parent.scope, projectId: parent.project_id }, 'receipt');
    const changes = retained ? 0 : db.prepare(`INSERT INTO receipts
      (id, memory_id, receipt_key, client, session_id, event_id, role, excerpt, created_at${eventTime ? ", occurred_at" : ""})
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?${eventTime ? ", ?" : ""})`).run(receiptId, id, key, receipt.client,
      receipt.sessionId, receipt.eventId, receipt.role, receipt.excerpt, now, ...(eventTime ? [occurredAt] : [])).changes;
    if (changes) inserted.push(receiptId);
    let provenanceChanged = false;
    if (rawLineage.enabled()) {
      const memory = db.prepare('SELECT owner_id,scope,project_id FROM memories WHERE id=?').get(id);
      const actual = changes ? receiptId : db.prepare('SELECT id FROM receipts WHERE memory_id=? AND receipt_key=?').get(id, key).id;
      provenanceChanged = rawLineage.attach({ ownerId: memory.owner_id, scope: memory.scope, projectId: memory.project_id }, actual, receipt,
        changes ? origin : 'unknown');
    }
    if (changes || provenanceChanged) {
      const memory = db.prepare('SELECT owner_id,scope,project_id FROM memories WHERE id=?').get(id);
      sourceRoots.touchMemory({ ownerId: memory.owner_id, scope: memory.scope, projectId: memory.project_id }, id, receipt);
    }
    return changes;
  }

  // Selection already owns the canonical row. Its S1 decision and fact stage
  // are reused by output validation in this request; no second read is needed.
  function privacyMemoryDenied(memory) {
    if (!cachedContentLayout(db)?.suppressionRevision) return false;
    const namespace = { ownerId: memory.owner_id, scope: memory.scope, projectId: memory.project_id };
    return !contentReadSafety(db, { namespace, intent: 'history', selectedMemory: memory,
      ref: { type: 'memory', namespace, memoryId: memory.id, revision: memory.revision } }).allowed;
  }
  const memoryAncestry = () => cachedContentLayout(db)?.suppressionRevision && cachedContentLayout(db)?.rawLineage
    ? `,EXISTS(SELECT 1 FROM receipts ar JOIN raw_receipt_lineage al ON al.receipt_id=ar.id
        LEFT JOIN raw_conversations ac ON ac.id=al.conversation_id
        WHERE ar.memory_id=memories.id AND (ac.owner_id IS NOT memories.owner_id
          OR ac.scope IS NOT memories.scope OR ac.project_id IS NOT memories.project_id)) AS invalid_raw_ancestry` : '';


  function legacyDto(memory, delivery) {
    if (!memory || privacyMemoryDenied(memory)) return null;
    const ns = { ownerId: memory.owner_id, scope: memory.scope, projectId: memory.project_id || null };
    const original = db.prepare('SELECT * FROM receipts WHERE memory_id=? ORDER BY created_at,receipt_key').all(memory.id);
    const receipts = safeReceipts(ns, original, undefined, delivery ? new Set() : undefined);
    const dto = {
      id: memory.id, content: memory.content, kind: memory.kind,
      scope: memory.scope, projectId: memory.project_id || null,
      origin: memory.origin, confidence: memory.confidence, revision: memory.revision,
      createdAt: memory.created_at, updatedAt: memory.updated_at,
      receipts: receipts.map(receipt => ({ client: receipt.client, sessionId: receipt.session_id, eventId: receipt.event_id,
        role: receipt.role, excerpt: receipt.excerpt, createdAt: receipt.created_at })),
    };
    delivery?.push({ dto, receipts });
    return dto;
  }

  function legacyDtos(ns, memories) {
    const delivery = [];
    const result = memories.map(memory => legacyDto(memory, delivery)).filter(Boolean);
    const withheld = withheldReceiptIdsInside(db, ns, delivery.flatMap(value => value.receipts));
    if (withheld.size) for (const { dto, receipts } of delivery) {
      dto.receipts = dto.receipts.filter((_, index) => !withheld.has(receipts[index].id));
    }
    return result;
  }

  function metadataDto(memory) {
    return {
      id: memory.id,
      namespace: {
        ownerId: memory.owner_id,
        scope: memory.scope,
        projectId: memory.project_id || null,
      },
      kind: memory.kind,
      origin: memory.origin,
      confidence: memory.confidence,
      revision: memory.revision,
      state: memory.currentness === 'historical' ? 'historical' : 'active',
      filing: { status: memory.filing_status },
      ...(decisionReview ? { reviewState: memory.review_state } : {}),
      receiptCount: contentReceiptCount(db, { ownerId:memory.owner_id,scope:memory.scope,projectId:memory.project_id || null }, memory, memory.receipt_count),
      createdAt: memory.created_at,
      updatedAt: memory.updated_at,
    };
  }

  function storedReceiptCount(id) {
    return db.prepare("SELECT count(*) AS n FROM receipts WHERE memory_id = ?").get(id).n;
  }

  function detailDto(memory) {
    const withCount = { ...memory, receipt_count: storedReceiptCount(memory.id) };
    return { ...metadataDto(withCount), content: memory.content };
  }

  function memoryDto(memory, includeContent = false) {
    const result = detailDto(memory);
    return includeContent ? result : metadataDto({ ...memory, receipt_count: result.receiptCount });
  }

  function admit(ns, value, projection = {}) {
    ready();
    return transaction(db, () => {
      const now = new Date().toISOString();
      validateReceiptTimes(value, now);
      rawLineage.assertReceipts(ns, value.receipts);
      assertNotSuppressed(ns, value.fingerprint);
      conflictStorage.validateTargets(ns, value.conflictHints);
      const result = admitMutation(ns, value, projection, now);
      if (value.procedural !== undefined) proceduralStorage.write(result.memory, value.procedural, 'explicit', value.receipts);
      const changed = conflictStorage.insertBatch(ns,
        [{ memoryId: result.memory.id, hints: value.conflictHints }], "explicit-hint");
      return { ...result, changed: result.changed || changed, indexRevision: epoch(ns) };
    });
  }

  function validateReceiptTimes(value, now) {
    value.receiptTimes = (value.receiptTimes ?? []).map(time => {
      try { return receiptEventTime(time, now); }
      catch (error) {
        // Episode capture already applied its pre-existing input contract.
        if (value.optionalReceiptTimes) return null;
        throw error;
      }
    });
  }

  // Caller owns the transaction, including admission-claim completion when used
  // in a batch. Explicit and inferred writes share all mutation/invalidation rules.
  function admitMutation(ns, value, projection = {}, now = new Date().toISOString()) {
    validateReceiptTimes(value, now);
    rawLineage.assertReceipts(ns, value.receipts);
    assertNotSuppressed(ns, value.fingerprint);
    const receiptOrigin = !projection.automatic && value.origin === 'explicit' ? 'independent' : 'unknown';
    const insertedReceiptIds = [];
    const existing = db.prepare(`SELECT * FROM memories WHERE ${where}
      AND fingerprint = ? AND deleted = 0`).get(...boundary(ns), value.fingerprint);
    if (existing) {
      // Same content-free refusal as the forgotten-fingerprint path above.
      if(!contentReadSafety(db,{namespace:ns,ref:{type:'memory',namespace:ns,memoryId:existing.id,revision:existing.revision},intent:'history'}).allowed)fail('memory_suppressed');
      if (value.qualification !== undefined && value.content !== existing.content) fail('qualification_conflict');
      let changed = false;
      for (const [index, receipt] of value.receipts.entries()) changed = Boolean(attach(existing.id, receipt, now, insertedReceiptIds, receiptOrigin, value.receiptTimes?.[index])) || changed;
      qualificationStorage.bind(existing, value.qualification, value.receipts, true, value.content,
        projection.captureQualifiedDuplicates);
      const explicit = value.origin === "explicit";
      const reviewState = explicit && existing.review_state === 'awaiting' ? 'none' : existing.review_state;
      const kind = explicit ? value.kind : existing.kind;
      const origin = explicit ? "explicit" : existing.origin;
      const confidence = !explicit && existing.origin === "explicit"
        ? existing.confidence : Math.max(existing.confidence, value.confidence);
      if (reviewState !== existing.review_state || kind !== existing.kind || origin !== existing.origin || confidence !== existing.confidence) {
        changed = true;
      }
      if (changed) {
        conflictStorage.invalidateMemory(existing.id, { preserveHeld: true });
        mocStorage.invalidateMemory(ns, existing.id, now);
        db.prepare(`UPDATE memories SET kind = ?, origin = ?, confidence = ?, review_state = ?,
          revision = revision + 1, updated_at = ? WHERE id = ?`)
          .run(kind, origin, confidence, reviewState, now, existing.id);
      }
      const memory = memoryWriteSafety(ns,activeRow(ns, existing.id));
      const reviewEffects = existing.review_state === 'awaiting' && reviewState !== 'awaiting'
        ? resolveHeld(ns, memory) : undefined;
      return {
        ...(decisionReview && reviewEffects ? { reviewEffects } : {}),
        memory, ...(projection.legacy ? { legacyMemory: legacyDto(memory) } : {}), deduplicated: true,
        indexRevision: changed ? advanceEpoch(ns) : epoch(ns), changed, insertedReceiptIds,
      };
    }
    const id = allocateContentKey(db, ns, 'memory');
    db.prepare(`INSERT INTO memories
      (id, owner_id, scope, project_id, fingerprint, content, kind, origin,
       confidence, revision, deleted, created_at, updated_at, review_state) VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?, ?, ?)`).run(id, ...boundary(ns),
      value.fingerprint, value.content, value.kind, value.origin, value.confidence, now, now,
      decisionReview && projection.automatic && value.origin === 'agent-inferred' && value.kind === 'decision' ? 'awaiting' : 'none');
    for (const [index, receipt] of value.receipts.entries()) attach(id, receipt, now, insertedReceiptIds, receiptOrigin, value.receiptTimes?.[index]);
    const memory = memoryWriteSafety(ns,activeRow(ns, id));
    qualificationStorage.bind(memory, value.qualification, value.receipts, false, value.content);
    return { memory, ...(projection.legacy ? { legacyMemory: legacyDto(memory) } : {}), deduplicated: false,
      indexRevision: advanceEpoch(ns), changed: true, insertedReceiptIds };
  }

  function correct(ns, id, value, expectedRevision, projection = {}) {
    ready();
    return transaction(db, () => {
      try {
        memoryWriteSafety(ns,visibleRow(ns,id));
      } catch (error) {
        if (error?.code !== 'memory_suppressed') throw error;
        // The old allow path is complete. Only explain an actual denial, using
        // that receipt-less Memory target and its Raw ancestry, never receipt facts.
        try {
          const current = visibleRow(ns, id);
          const safety = contentReadSafety(db, { namespace: ns, intent: 'history',
            ref: { type: 'memory', namespace: ns, memoryId: current.id, revision: current.revision } });
          const denials = memoryCorrectionDenialsInside(db, ns, { memoryId: current.id, revision: current.revision });
          if (safety.allowed || !denials.some(denial => denial.reason === safety.reason) ||
              denials.some(denial => denial.kind !== 'raw' || denial.matchMode !== 'span' || denial.matchPath !== 'raw-ancestry'))
            fail('memory_suppressed');
        } catch { fail('memory_suppressed'); }
      }
      const result=rawCards.mutate(ns,'memory-correct-'+id+'-'+expectedRevision,() => {
      const current = visibleRow(ns, id);
      if (!current) fail("memory_not_found");
      if (current.revision !== expectedRevision) fail("revision_conflict");
      if (current.currentness === 'historical') fail('memory_historical');
      assertNotSuppressed(ns, value.fingerprint);
      const other = db.prepare(`SELECT id FROM memories WHERE ${where}
        AND fingerprint = ? AND deleted = 0 AND id != ?`)
        .get(...boundary(ns), value.fingerprint, id);
      if (other) fail("memory_conflict");
      const suppression = { reason: 'correction_supersession', actionId: 'memory-correct-'+id+'-'+expectedRevision };
      // Resolve legacy keep proof before Episode source invalidation removes its IDs.
      if (localRawPrivacy) rawLineage.excludeMemory(ns, id, suppression);
      localRawPrivacy?.invalidateMemoryEpisodesInside(ns, current, episodes);
      localRawPrivacy?.hideMemoryInside(ns, current);
      const retired = sourceRoots.touchMemory(ns, id);
      writeContentSuppressionInside(db, { namespace: ns, kind: 'memory', key: id, matchMode: 'revision-through',
        sourceVersion: JSON.stringify(['memory-revision-through-v1', current.revision]), ...suppression });
      suppressReceiptsInside(db, ns, id, suppression, undefined, { rows: retired, replacements: value.receipts.map(receipt => ({
        receipt_key: receiptKey(receipt), client: receipt.client, session_id: receipt.sessionId, event_id: receipt.eventId, role: receipt.role,
      })) });
      if (!localRawPrivacy) rawLineage.excludeMemory(ns, id, suppression);
      stagedEvidence.purgeNamespace(ns);
      if (current.fingerprint !== value.fingerprint) suppress(ns, current.fingerprint);
      const now = new Date().toISOString();
      conflictStorage.invalidateMemory(id);
      mocStorage.invalidateMemory(ns, id, now);
      qualificationStorage.clear(id);
      proceduralStorage.clear(id);
      episodes.invalidateMemory(ns, id);
      db.prepare(`UPDATE memories SET content = ?, fingerprint = ?, kind = ?,
        origin = 'explicit', confidence = 1, revision = revision + 1, updated_at = ?
        WHERE id = ?`).run(value.content, value.fingerprint, value.kind, now, id);
      db.prepare("DELETE FROM receipts WHERE memory_id = ?").run(id);
      for (const [index, receipt] of value.receipts.entries()) attach(id, receipt, now, [], 'independent', value.receiptTimes?.[index]);
      const memory = activeRow(ns, id);
      return { memory,
        ...(projection.legacy ? { legacyMemory: legacyDto(memory) } : {}),
        ...(projection.detail ? { detail: detailDto(memory) } : {}),
        indexRevision: advanceEpoch(ns) };
      });
      if(result.memory&&contentSuppressionReasonInside(db,ns,{kind:'memory',key:result.memory.id,revision:result.memory.revision,
        version:JSON.stringify(['memory-revision-v1',result.memory.revision])}))fail('memory_suppressed');
      return result;
    });
  }

  function forgetMutation(ns, id, expectedRevision, reason = 'forgotten', suppressionReason = reason === 'forgotten' ? 'user_forget' : 'purge', { cascade = false } = {}) {
    return rawCards.mutate(ns,'memory-forget-'+id,() => forgetMutationInside(ns,id,expectedRevision,reason,suppressionReason,cascade === true));
  }
  function forgetMutationInside(ns, id, expectedRevision, reason, suppressionReason, cascade) {
      const current = activeRow(ns, id);
      if (!current) return { forgotten: false, indexRevision: epoch(ns) };
      if (expectedRevision !== undefined && current.revision !== expectedRevision) fail("revision_conflict");
      let retired;
      // Cascades manage their Episodes after all Memories have used the sources.
      if (cascade) {
        localRawPrivacy?.hideMemoryInside(ns, current);
        retired = sourceRoots.touchMemory(ns, id);
        suppress(ns, current.fingerprint);
      }
      const suppression = { reason: suppressionReason, actionId: 'memory-forget-'+id };
      if (!cascade) {
        // Resolve legacy keep proof before Episode source invalidation removes its IDs.
        if (localRawPrivacy) rawLineage.excludeMemory(ns, id, suppression);
        localRawPrivacy?.invalidateMemoryEpisodesInside(ns, current, episodes);
        localRawPrivacy?.hideMemoryInside(ns, current);
        retired = sourceRoots.touchMemory(ns, id);
        suppress(ns, current.fingerprint);
      }
      writeContentSuppressionInside(db, { namespace: ns, kind: 'memory', key: id, ...suppression });
      suppressReceiptsInside(db, ns, id, suppression, undefined,
        suppressionReason === 'user_forget' || reason === 'rejected' ? { rows: retired } : undefined);
      if (cascade && localRawPrivacy) rawLineage.excludeMemory(ns, id, suppression);
      if (!localRawPrivacy) rawLineage.excludeMemory(ns, id, suppression);
      stagedEvidence.purgeNamespace(ns);
      const now = new Date().toISOString();
      const effects = conflictStorage.invalidateMemory(id, { reason });
      mocStorage.invalidateMemory(ns, id, now);
      qualificationStorage.clear(id);
      proceduralStorage.clear(id);
      episodes.invalidateMemory(ns, id, current.review_state === 'awaiting');
      purgeEngineCardsInside(db, ns, suppression.actionId, id);
      purgeEngineCardOperationsInside(db, ns, id);
      db.prepare(`UPDATE memories SET content = NULL, deleted = 1,
        revision = revision + 1, updated_at = ? WHERE id = ?`).run(now, id);
      db.prepare("DELETE FROM receipts WHERE memory_id = ?").run(id);
      const reviewEffects = decisionReview ? effects : undefined;
      return { forgotten: true, indexRevision: advanceEpoch(ns), ...(reviewEffects ? { reviewEffects } : {}) };
  }

  function forget(ns, id, expectedRevision) {
    ready();
    return transaction(db, () => forgetMutation(ns, id, expectedRevision));
  }
  function removeReceipts(ns, id, receiptIds, suppression = { reason: 'purge', actionId: 'receipt-remove-'+id }) {
    requireSuppressionTransaction(db);
    suppressReceiptsInside(db, ns, id, suppression, receiptIds);
    const current = activeRow(ns, id); if (!current) fail('memory_not_found');
    sourceRoots.touchMemory(ns, id);
    const now = new Date().toISOString();
    conflictStorage.invalidateMemory(id);
    mocStorage.invalidateMemory(ns, id, now);
    qualificationStorage.clear(id); proceduralStorage.clear(id);
    episodes.invalidateMemory(ns, id, current.review_state === 'awaiting');
    db.prepare('UPDATE memories SET revision=revision+1,updated_at=? WHERE id=?').run(now, id);
    for (const receiptId of receiptIds) db.prepare('DELETE FROM receipts WHERE memory_id=? AND id=?').run(id, receiptId);
    advanceEpoch(ns);
  }

  function supersede(ns, id, value, expectedRevision) {
    ready();
    return transaction(db, () => {
      const previous = memoryWriteSafety(ns,visibleRow(ns, id));
      if (!previous) fail('memory_not_found');
      if (previous.revision !== expectedRevision) fail('revision_conflict');
      if (previous.currentness === 'historical') fail('memory_historical');
      if (previous.fingerprint === value.fingerprint) fail('invalid_ref');
      const result = admitMutation(ns, value);
      const receiptIds = [...new Set(value.receipts.map(receipt => db.prepare(
        'SELECT id FROM receipts WHERE memory_id = ? AND receipt_key = ?')
        .get(result.memory.id, receiptKey(receipt)).id))];
      const retired = supersessionStorage.retire(ns, previous, result.memory, receiptIds);
      memoryWriteSafety(ns,activeRow(ns,previous.id));
      return { ...retired, memory: { id: result.memory.id, revision: result.memory.revision },
        deduplicated: result.deduplicated };
    });
  }

  function qualifiedRow(ns, ref) {
    const memory = memoryWriteSafety(ns,visibleRow(ns, ref.memoryId));
    if (!memory) fail('memory_not_found');
    if (memory.revision !== ref.expectedRevision) fail('revision_conflict');
    if (memory.currentness !== 'current') fail('memory_historical');
    return memory;
  }

  function bindQualifiedClaim(ns, input) {
    ready();
    return transaction(db, () => qualifiedTransitionStorage.bind(ns, qualifiedRow(ns, input), input.slotId));
  }

  function transitionQualified(ns, input) {
    ready();
    return transaction(db, () => {
      if (input.predecessor.memoryId === input.replacement.memoryId) fail('invalid_ref');
      const previous = qualifiedRow(ns, input.predecessor);
      const replacement = qualifiedRow(ns, input.replacement);
      const result=supersessionStorage.retireQualified(ns, previous, replacement);
      memoryWriteSafety(ns,activeRow(ns,previous.id));
      return result;
    });
  }

  function transitionQualifiedSet(ns, input) {
    ready();
    return transaction(db, () => {
      const ids = input.predecessors.map(ref => ref.memoryId);
      if (new Set(ids).size !== ids.length || ids.includes(input.replacement.memoryId)) fail('invalid_ref');
      const previous = input.predecessors.map(ref => qualifiedRow(ns, ref));
      const replacement = qualifiedRow(ns, input.replacement);
      const result=supersessionStorage.retireQualifiedSet(ns, previous, replacement);
      for(const row of previous)memoryWriteSafety(ns,activeRow(ns,row.id));
      return result;
    });
  }

  function legacyGet(ns, id) {
    ready();
    return transaction(db, () => legacyDto(currentRow(ns, id, true)));
  }

  function legacyList(ns, count) {
    ready();
    return transaction(db, () => legacyDtos(ns, db.prepare(`SELECT memories.*${memoryAncestry()} FROM memories WHERE ${where}
      AND deleted = 0 AND review_state != 'awaiting' AND currentness = 'current' ORDER BY updated_at DESC, id LIMIT ?`)
      .all(...boundary(ns), count)));
  }

  function legacySearch(ns, terms, count) {
    ready();
    return transaction(db, () => legacyDtos(ns, db.prepare(`SELECT memories.*${memoryAncestry()} FROM memories WHERE ${where}
      AND deleted = 0 AND review_state != 'awaiting' AND currentness = 'current'`).all(...boundary(ns))
      .map((memory) => ({ memory, score: terms.reduce((n, term) =>
        n + Number(memory.content.toLowerCase().includes(term)), 0) }))
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score || b.memory.updated_at.localeCompare(a.memory.updated_at)
        || a.memory.id.localeCompare(b.memory.id))
      .slice(0, count).map(({ memory }) => memory)));
  }

  function listPage(ns, statuses, count, anchor, expectedEpoch, states = ['active', 'historical'], reviewState) {
    ready();
    if (reviewState === 'awaiting' && !decisionReview) fail('decision_review_required');
    return transaction(db, () => {
      const currentEpoch = epoch(ns);
      if (expectedEpoch !== undefined && currentEpoch !== expectedEpoch) fail("cursor_stale");
      let sql = `SELECT memories.*${memoryAncestry()}, (SELECT count(*) FROM receipts
        WHERE receipts.memory_id = memories.id) AS receipt_count
        FROM memories WHERE ${where} AND deleted = 0
        AND review_state ${reviewState === 'awaiting' ? "= 'awaiting'" : "!= 'awaiting'"}
        AND filing_status IN (${statuses.map(() => "?").join(",")})`;
      const params = [...boundary(ns), ...statuses];
      if (states.length === 1) {
        sql += ' AND currentness = ?';
        params.push(states[0] === 'active' ? 'current' : 'historical');
      }
      const batchSize = count + 1;
      const visible = [];
      let scanAnchor = anchor;
      while (true) {
        let pageSql = sql;
        const pageParams = [...params];
        if (scanAnchor) {
          pageSql += " AND (updated_at < ? OR (updated_at = ? AND id > ?))";
          pageParams.push(scanAnchor.updatedAt, scanAnchor.updatedAt, scanAnchor.id);
        }
        pageSql += " ORDER BY updated_at DESC, id ASC LIMIT ?";
        const batch = db.prepare(pageSql).all(...pageParams, batchSize);
        for (const row of batch) {
          if (privacyMemoryDenied(row)) continue;
          visible.push(row);
          if (visible.length === batchSize) break;
        }
        if (visible.length === batchSize || batch.length < batchSize) break;
        const last = batch.at(-1);
        scanAnchor = { updatedAt: last.updated_at, id: last.id };
      }
      return { rows: visible.map(metadataDto), epoch: currentEpoch };
    }, undefined, { deferred: true });
  }

  function getPage(ns, id, count, anchor, expectedEpoch, includeQualification = false, includeAwaiting = false) {
    ready();
    return transaction(db, () => {
      const currentEpoch = epoch(ns);
      if (expectedEpoch !== undefined && currentEpoch !== expectedEpoch) fail("cursor_stale");
      const memory = db.prepare(`SELECT memories.*${memoryAncestry()}, (SELECT count(*) FROM receipts
        WHERE receipts.memory_id = memories.id) AS receipt_count FROM memories
        WHERE ${where} AND id = ? AND deleted = 0`).get(...boundary(ns), id);
      if (!memory || privacyMemoryDenied(memory) || (memory.review_state === 'awaiting' && !(decisionReview && includeAwaiting))) fail("memory_not_found");
      if (anchor && Object.hasOwn(anchor, 'row')) {
        if (Object.keys(anchor).length !== 1 || !Number.isSafeInteger(anchor.row) || anchor.row < 1) fail('invalid_cursor');
        const stored = db.prepare('SELECT created_at AS createdAt,id FROM receipts WHERE memory_id=? AND rowid=?').get(id, anchor.row);
        if (!stored) fail('cursor_stale');
        anchor = stored;
      }
      let sql = `SELECT rowid AS cursor_row,* FROM receipts WHERE memory_id = ?`;
      const params = [id];
      if (anchor) {
        sql += " AND (created_at > ? OR (created_at = ? AND id > ?))";
        params.push(anchor.createdAt, anchor.createdAt, anchor.id);
      }
      sql += " ORDER BY created_at ASC, id ASC LIMIT ?";
      params.push(count + 1);
      const original = db.prepare(sql).all(...params);
      const withheld = original.length === count + 1 ? withheldMemoryReceiptIdsInside(db, [[ns, id]])
        : withheldReceiptIdsInside(db, ns, original);
      const procedural = safeProcedural(ns, id);
      const visible = original.some(receipt => withheld.has(receipt.id))
        ? fillReceiptPage(id, original, withheld, count + 1).visible : original;
      const scanned = visible.slice(0, count);
      return { receiptComplete: visible.length <= count, receiptScan: scanned.at(-1)?.cursor_row, memory: { ...metadataDto(memory), content: memory.content },
        receipts: safeReceipts(ns, scanned, undefined, new Set()).map(receipt => ({ id: receipt.id, client: receipt.client,
          sessionId: receipt.session_id, eventId: receipt.event_id, role: receipt.role, excerpt: receipt.excerpt, createdAt: receipt.created_at })),
        ...(procedural ? { procedural } : {}),
        placements: mocStorage.placementRefs(ns, id),
        conflicts: conflictStorage.inspect(ns, id),
        ...(includeQualification ? { qualification: safeQualification(ns, memory) } : {}),
        ...(memory.currentness === 'historical'
          ? { supersession: safeSupersession(ns, id) } : {}), epoch: currentEpoch };
    }, undefined, { deferred: true });
  }

  function safeSupersession(ns, id) {
    const supersession = supersessionStorage.inspect(ns, id);
    const receiptIds = supersession?.receiptIds ?? [];
    const withheld = withheldStoredReceiptIdsInside(db, ns, receiptIds);
    if (!withheld.size) return supersession;
    return { ...supersession, receiptIds: receiptIds.filter(id => !withheld.has(id)), evidenceAvailable: false };
  }

  function safeQualification(ns, row, withheld) {
    const value = qualificationStorage.inspect(row);
    return value && !anchoredReadSafety(db, { namespace: ns, memoryId: row.id, anchors: value.anchors, project: true, withheld }).allowed ? null : value;
  }
  function safeProcedural(ns, id) {
    const value = proceduralStorage.inspect(id);
    return value && !anchoredReadSafety(db, { namespace: ns, memoryId: id, anchors: value.anchors, project: true }).allowed ? null : value;
  }
  function safeReceipts(ns, receipts, memo = createContentReadMemo(db), withheld = withheldReceiptIdsInside(db, ns, receipts)) {
    return receipts.filter(receipt => receiptReadSafety(db, { namespace: ns, receipt, memo, withheld }).allowed);
  }
  function fillReceiptPage(id, original, withheld, limit, recent = false) {
    const visible = [], offsets = new Map();
    let batch = original, physical = 0, moreVisible = false;
    const add = rows => {
      for (const receipt of rows) {
        physical++;
        if (withheld.has(receipt.id)) continue;
        if (visible.length >= limit) { moreVisible = true; continue; }
        visible.push(receipt);
        offsets.set(receipt.id, physical);
      }
    };
    add(batch);
    const direction = recent ? '<' : '>';
    const order = recent ? 'DESC' : 'ASC';
    while (batch.length === limit && visible.length < limit) {
      const after = batch.at(-1);
      batch = db.prepare(`SELECT rowid AS cursor_row,* FROM receipts WHERE memory_id=?
        AND (created_at ${direction} ? OR (created_at=? AND id>?)) ORDER BY created_at ${order},id ASC LIMIT ?`)
        .all(id, after.created_at, after.created_at, after.id, limit);
      add(batch);
    }
    return { visible, offsets, physical, complete: batch.length < limit && !moreVisible };
  }
  const receiptPageOffsets = new WeakMap();
  function receiptPage(ns, row, offset, count, recent = false, withheld) {
    const original = db.prepare(`SELECT * FROM receipts WHERE memory_id=?
      ORDER BY created_at ${recent ? 'DESC' : 'ASC'},id LIMIT ? OFFSET ?`).all(row.id, count, offset);
    const memo = createContentReadMemo(db);
    withheld ??= original.length > 0 && original.length === count
      ? withheldMemoryReceiptIdsInside(db, [[ns, row.id]]) : withheldReceiptIdsInside(db, ns, original);
    const page = original.some(receipt => withheld.has(receipt.id))
      ? fillReceiptPage(row.id, original, withheld, count, recent) : null;
    // Refill rows carry a physical cursor column outside the receipt record.
    const visible = page ? page.visible.map(({ cursor_row, ...receipt }) => receipt) : original;
    const rows = safeReceipts(ns, visible, memo, new Set());
    if (!row || !contentReadSafety(db, { identity, namespace: ns, intent: 'history', memo,
      ref: { type: 'memory', namespace: ns, memoryId: row.id, revision: row.revision }, receipts: rows }).allowed) fail('revision_conflict');
    const result = rows.map(receipt => ({ id: receipt.id, client: receipt.client, sessionId: receipt.session_id, eventId: receipt.event_id,
      role: receipt.role, excerpt: receipt.excerpt, createdAt: receipt.created_at }));
    const end = offset + (page?.physical ?? original.length);
    const offsets = rows.map(receipt => offset + (page?.offsets.get(receipt.id) ?? original.indexOf(receipt) + 1));
    if (page?.complete && offsets.length) offsets[offsets.length - 1] = end;
    receiptPageOffsets.set(result, { offsets, end, withheld: page !== null });
    return result;
  }
  function receiptPrefix(ns, row, offset, count, withheld) { return receiptPage(ns, row, offset, count, false, withheld); }

  // A capped recall receipt list: most recent first, ties broken by ID.
  function receiptRecent(ns, row, count, withheld) { return receiptPage(ns, row, 0, count, true, withheld); }

  // Read before ranking only; the final recall snapshot rereads the same list.
  function recentReceipts(ns, ref, count) {
    ready();
    return transaction(db, () => {
      const row = currentRow(ns, ref.memoryId);
      if (!row || row.revision !== ref.revision) fail('revision_conflict');
      return receiptRecent(ns, row, count);
    }, undefined, { deferred: true });
  }

  function readSourceEvidence(row, withheld, qualificationOptions) {
    const original = db.prepare('SELECT * FROM receipts WHERE memory_id = ? ORDER BY created_at, id LIMIT 101').all(row.id);
    const ns = { ownerId: row.owner_id, scope: row.scope, projectId: row.project_id || null };
    if (qualificationStorage.inspect(row, qualificationOptions) === false) return null;
    if (qualificationOptions?.withholdDenied) {
      return sessionSourceEvidence(ns, row, original);
    }
    const full = sourceEvidence(row, original, detailDto(row).receiptCount, receiptKey);
    const memo = createContentReadMemo(db);
    const retained = withheld ? safeReceipts(ns, original, memo, new Set()) : original;
    if (withheld && !retained.length) fail('source_unavailable');
    const receipts = withheld?.size ? retained.filter(receipt => !withheld.has(receipt.id)) : retained;
    const ids = new Set(receipts.map(receipt => receipt.id));
    const evidence = withheld ? { ...full, receipts: full.receipts.filter(receipt => ids.has(receipt.id)), receiptCount: retained.length } : full;
    if (!contentReadSafety(db, { identity, namespace: ns, intent: 'history', memo, ref: { type: 'memory', namespace: ns,
      memoryId: row.id, revision: row.revision }, receipts }).allowed) fail('revision_conflict');
    return evidence;
  }

  function sessionSourceEvidence(ns, row, original) {
    const { total, hasMarkers } = db.prepare(`SELECT count(*) AS total,
      EXISTS(SELECT 1 FROM suppressed WHERE ${where} AND fingerprint GLOB 'rs1:*') AS hasMarkers
      FROM receipts WHERE memory_id = ?`).get(ns.ownerId, ns.scope, ns.projectId ?? '', row.id);
    const memo = createContentReadMemo(db);
    const safety = cachedContentLayout(db)?.suppressionRevision;
    const ref = { type: 'memory', namespace: ns, memoryId: row.id, revision: row.revision };
    const readable = receipts => contentReadSafety(db, { identity, namespace: ns, intent: 'history', memo, ref, receipts }).allowed;
    const withheldReceiptIds = hasMarkers ? withheldReceiptIdsInside(db, ns, original) : new Set();
    if (total <= 100 && !withheldReceiptIds.size) {
      const full = sourceEvidence(row, original, total, receiptKey);
      if (readable(original)) return full;
      if (!safety) fail('revision_conflict');
    }

    const receipts = [];
    let batch = original, scanned = original.length;
    while (true) {
      for (const receipt of batch) {
        if (withheldReceiptIds.has(receipt.id)) continue;
        if (!safety || receiptReadSafety(db, { namespace: ns, receipt, memo }).allowed) receipts.push(receipt);
        else withheldReceiptIds.add(receipt.id);
      }
      if (receipts.length > 100) fail('context_item_too_large');
      if (scanned >= total) break;
      batch = db.prepare('SELECT * FROM receipts WHERE memory_id = ? ORDER BY created_at, id LIMIT 101 OFFSET ?').all(row.id, scanned);
      if (!batch.length) fail('storage_error');
      scanned += batch.length;
      if (hasMarkers) for (const id of withheldReceiptIdsInside(db, ns, batch)) withheldReceiptIds.add(id);
    }
    // An empty legacy receipt set retains the existing Raw lineage refusal.
    const emptyLegacy = !safety && total <= 100 && !receipts.length;
    if (!readable(receipts) || (emptyLegacy && !readable(original))) fail('revision_conflict');
    return { ...sourceEvidence(row, receipts, receipts.length, receiptKey, { allowEmpty: true }), withheldReceiptIds };
  }

  function safeMemory(ns, row, intent = 'current', expectedMemoryIdentity, method = 'retrieval') {
    return row && contentReadSafety(db, { identity, namespace: ns, intent, method, expectedMemoryIdentity, ref: { type: 'memory', namespace: ns,
      memoryId: row.id, revision: row.revision } }).allowed;
  }

  const fetchPageIdentities = new WeakMap();
  function fetchPage(ns, ref, offset, expectedEpoch, view = 'current', includeQualification = false, contextMode, expectedPage) {
    ready();
    return transaction(db, () => {
      const currentEpoch = epoch(ns);
      if (expectedEpoch !== undefined && currentEpoch !== expectedEpoch) fail('cursor_stale');
      const candidate = view === 'historical' ? activeRow(ns, ref.memoryId) : currentRow(ns, ref.memoryId);
      const row = candidate?.currentness === view ? candidate : undefined;
      const reason = !safeMemory(ns, row, view === 'historical' ? 'history' : 'current', expectedPage && fetchPageIdentities.get(expectedPage), 'fetch') ? 'not_found' : row.revision !== ref.revision ? 'stale' : null;
      if (reason) return { invalidRef: { memoryId: ref.memoryId, reason }, epoch: currentEpoch };
      if (isSourceContext(contextMode)) {
        const [source] = readUsageEvidencePage([row], [{ namespace: ns }], contextMode);
        const page = { source, epoch: currentEpoch };
        fetchPageIdentities.set(page, memoryContentIdentity(row));
        return page;
      }
      const memory = detailDto(row);
      const receipts = receiptPrefix(ns, row, offset, 101), positions = receiptPageOffsets.get(receipts);
      const page = { memory, receipts, receiptOffsets: positions.offsets, receiptEnd: positions.end, epoch: currentEpoch,
        ...(includeQualification ? { qualification: safeQualification(ns, row) } : {}),
        ...(view === 'historical' ? { supersession: safeSupersession(ns, row.id) } : {}) };
      // Recall uses this internal fact without changing fetch's serialized page comparison.
      if (positions.withheld) Object.defineProperty(page, 'receiptsWithheld', { value: true });
      return page;
    }, undefined, { deferred: true });
  }

  function readUsageEvidencePage(rows, candidates, mode, revalidate = false) {
    const rationale = mode === 'rationale-evidence';
    const withheld = withheldMemoryReceiptIdsInside(db, rows.map(({ id }, index) => [candidates[index].namespace, id]), rationale);
    return rows.map((row, index) => {
      const evidence = readSourceEvidence(row, withheld);
      if (rationale) evidence.rationale = rationaleStorage.inspectInside(candidates[index].namespace,
        { memoryId: row.id, revision: row.revision }, undefined, withheld);
      if (revalidate && JSON.stringify(evidence) !== JSON.stringify(candidates[index].sourceEvidence)) fail('revision_conflict');
      return evidence;
    });
  }

  const sourceSnapshotIdentities = new WeakMap();
  function sourceSnapshot(namespaces, count, expected) {
    ready();
    return transaction(db, () => {
      const boundaries = namespaces.map((namespace, index) => {
        indexStorage.assertAvailable(namespace);
        const indexRevision = epoch(namespace);
        if (expected && expected.namespaces[index].indexRevision !== indexRevision) fail('index_revision_conflict');
        return { namespace: { ownerId: namespace.ownerId, scope: namespace.scope,
          projectId: namespace.projectId || null }, indexRevision };
      });
      // Enumerate the physical current set independently of MOC navigation.
      // The limit+1 probe bounds work and detects overflow before source reads.
      const identities = namespaces.flatMap((namespace, namespaceIndex) => db.prepare(`
        SELECT id, revision FROM memories INDEXED BY capture_current_memories
        WHERE ${where} AND deleted = 0 AND review_state != 'awaiting' AND currentness = 'current' ORDER BY id LIMIT ?`)
        .all(...boundary(namespace), count + 1).map(row => ({ ...row, namespaceIndex })));
      if (identities.length > count) fail(expected ? 'revision_conflict' : 'context_item_too_large');
      const contentIdentities = [], previousIdentities = expected && sourceSnapshotIdentities.get(expected);
      if (expected && !previousIdentities) fail('revision_conflict');
      const memories = identities.map(({ id, revision, namespaceIndex }, index) => {
        const namespace = namespaces[namespaceIndex];
        // An incomplete active projection is an error, never a smaller claim
        // of completeness. Preserve the shared index generation's authority.
        if (!db.prepare(`SELECT id FROM index_read_memories WHERE ${where} AND id = ? AND revision = ?`)
          .get(...boundary(namespace), id, revision)) fail('index_revision_conflict');
        const row = currentRow(namespace, id);
        if (!safeMemory(namespace, row, 'current', previousIdentities?.[index])) fail('revision_conflict');
        contentIdentities.push(memoryContentIdentity(row));
        return { namespaceIndex, ...readSourceEvidence(row) };
      });
      for (let index = 0; index < namespaces.length; index++) {
        const selected = memories.filter(memory => memory.namespaceIndex === index);
        const ids = selected.flatMap(memory => memory.receipts.map(receipt => receipt.id));
        const withheld = withheldStoredReceiptIdsInside(db, namespaces[index], ids);
        if (withheld.size) for (const memory of selected) {
          memory.receipts = memory.receipts.filter(receipt => !withheld.has(receipt.id));
        }
      }
      const snapshot = { memories, namespaces: boundaries, coverage: 'complete-current-admitted',
        semanticCoverage: 'unassessed', evidenceTrust: 'untrusted-data-not-instructions' };
      if (expected && JSON.stringify(snapshot) !== JSON.stringify(expected)) fail('revision_conflict');
      sourceSnapshotIdentities.set(snapshot, contentIdentities);
      return snapshot;
    }, undefined, { deferred: true });
  }

  function recallSnapshot(candidates, selected, namespaces = [], includeQualification = false, contextMode) {
    ready();
    return transaction(db, () => {
      // This transaction is the return linearization point across the read set.
      const rows = candidates.map(({ namespace, memoryId, revision }) => {
        const row = currentRow(namespace, memoryId);
        if (!safeMemory(namespace, row) || row.revision !== revision) fail('revision_conflict');
        return row;
      });
      const markerPages = [];
      let indexFailure;
      try {
        for (const { namespace, indexRevision, suppressionEpoch, receiptProofs } of namespaces) {
          indexStorage.assertAvailable(namespace);
          if (epoch(namespace) !== indexRevision || cachedContentLayout(db)?.suppressionRevision && suppressionEpoch !== undefined && suppressionEpoch !== contentSuppressionRequestFenceInside(db, namespace.ownerId)) fail('index_revision_conflict');
          if (receiptProofs?.length) markerPages.push([namespace, receiptProofs]);
        }
      } catch (error) { indexFailure = { error }; }
      if (withheldReceiptPageInside(db, markerPages).size) fail('revision_conflict');
      if (indexFailure) throw indexFailure.error;
      if (isSourceContext(contextMode)) {
        const sources = readUsageEvidencePage(rows, candidates, contextMode, true);
        return selected.map(index => sources[index]);
      }
      const receiptIndexes = includeQualification ? rows.map((_, index) => index) : selected.filter(index => candidates[index].receiptLimit > 0);
      const withheld = withheldMemoryReceiptIdsInside(db, receiptIndexes.map(index => [candidates[index].namespace, rows[index].id]));
      const qualifications = includeQualification ? rows.map((row, index) => safeQualification(candidates[index].namespace, row, withheld)) : null;
      return selected.map((index) => {
        const memory = detailDto(rows[index]);
        const capped = candidates[index].receiptOrder === 'recent';
        const receipts = capped ? receiptRecent(candidates[index].namespace, rows[index], candidates[index].receiptLimit, withheld)
          : receiptPrefix(candidates[index].namespace, rows[index], 0, candidates[index].receiptLimit, withheld);
        const delivered = receipts.length || !receiptPageOffsets.get(receipts).withheld ? receipts : [{
          id: 'withheld', client: 'withheld', sessionId: 'withheld', eventId: 'withheld',
          role: 'user', excerpt: '[source not available]', createdAt: memory.createdAt }];
        return { memory, receipts: delivered, receiptCount: memory.receiptCount,
          ...(capped ? { receiptsOmitted: memory.receiptCount - receipts.length } : {}),
          ...(includeQualification ? { qualification: qualifications[index] } : {}) };
      });
    }, undefined, { deferred: true });
  }

  const conflictStorage = createConflictStorage({ db, activeRow: currentRow, rawRow: activeRow, advanceEpoch,
    dropHeldWork: (id, reason) => dropHeldWork(db, id, reason) });
  const rationaleStorage = createRationaleStorage({ db, currentRow, readSourceEvidence, epoch, advanceEpoch });
  const qualificationStorage = createQualificationStorage({ db, receiptKey,
    assertStoredReceipts: rawLineage.assertStoredReceipts });
  const qualifiedTransitionStorage = createQualifiedTransitionStorage({ db, qualificationStorage, advanceEpoch, epoch });
  const indexStorage = createIndexStorage({ db, epoch, advanceEpoch });
  const classificationJournal = createClassificationJournalStorage({ db });
  mocStorage = createMocStorage({ db, epoch, advanceEpoch, memoryDto,
    invalidateConflicts: conflictStorage.invalidateMemory, assertIndexAvailable: indexStorage.assertAvailable,
    rationaleStorage, receiptKey, classificationJournal });
  const supersessionStorage = createSupersessionStorage({ db, activeRow: visibleRow, suppress, advanceEpoch,
    invalidateConflicts: conflictStorage.invalidateMemory, invalidateMemory: mocStorage.invalidateMemory,
    evaluateQualified: qualifiedTransitionStorage.evaluate,
    evaluateQualifiedSet: qualifiedTransitionStorage.evaluateSet, epoch,
    recordHeldRetirement: (previous, replacement, linked) => recordHeldRetirement(db, previous, replacement, linked) });
  const stagedEvidence = createStagedEvidenceStorage({ db });
  let rawCapture;
  rawCapture = internal?.attachRaw?.(db);
  const episodeProjection = createEpisodeReadProjection({ db, epoch });
  function assertEpisodeRead(ns, row, budget = { remaining: 4096, bytesRemaining: 4*1024*1024 }, mode, withheldSources) {
    if (!(cachedContentLayout(db) ?? installedContentLayout(db)).suppressionRevision) return;
    if (contentSuppressionReasonInside(db, ns)) fail('episode_not_found');
    const proof = cachedContentSuppressionRequestInside(db, ns.ownerId);
    const deniedSources = new Set();
    let anchors, metadataDenial, firstSourceDenial;
    const checkedSources = new Set();
    // A denied source may stand alone in the detail page. An anchored source
    // also denies the published Episode that depends on it.
    function withholdSource(id, code) {
      firstSourceDenial ??= code;
      if (!anchors) {
        const record = JSON.parse(row.record);
        anchors = new Set([...Object.values(record.anchors ?? {}).flat(), ...(record.nextStep?.anchors ?? [])]
          .map(anchor => anchor.sourceId));
      }
      if (anchors.has(id)) {
        metadataDenial = new MemoryStoreError(code);
        throw metadataDenial;
      }
      deniedSources.add(id);
    }
    function validate() {
      if (row.episode_read_overflow) fail('episode_sources_unavailable');
      if (row.episode_read_proof !== undefined) {
        budget.bytesRemaining -= Buffer.byteLength(row.episode_read_proof, 'utf8');
        if (budget.bytesRemaining < 0) fail('episode_sources_unavailable');
        let evidence = JSON.parse(row.episode_read_proof);
        if (withheldSources?.size) evidence = evidence.filter(source => !withheldSources.has(source.id));
        if (mode === 'detail') {
          for (const source of evidence) checkedSources.add(source.id);
          if (evidence.some(source => source.deleted)) firstSourceDenial = 'revision_conflict';
        }
        const fallback = !proof?.facts || row.episode_read_incomplete;
        const indexedDenials = fallback ? rawLineage.completeEpisodeProof(ns, evidence, budget, row.episode_read_incomplete, Boolean(mode)) : undefined;
        rawLineage.assertEpisodeProof(ns, evidence, proof?.facts ?? [], budget, indexedDenials, mode ? withholdSource : undefined);
        if (!fallback) return;
      }
      // Outside the bounded fact/index-input population, finish with the existing
      // indexed validator. A complete projected hardening check still ran above.
      const sources = db.prepare(`SELECT s.*,e.client AS origin_client,e.session_key AS origin_session,
        e.owner_id,e.scope,e.project_id,e.deleted FROM episode_sources s
        LEFT JOIN session_episodes e ON e.id=s.origin_episode_id WHERE s.episode_id=?`).all(row.id);
      for (const source of sources) {
        if (mode === 'detail') checkedSources.add(source.id);
        if (source.owner_id !== ns.ownerId || source.scope !== ns.scope ||
            source.project_id !== (ns.projectId ?? '')) fail('revision_conflict');
        if (withheldSources?.has(source.id)) continue;
        if (source.deleted && !deniedSources.has(source.id)) {
          if (!mode) fail('revision_conflict');
          withholdSource(source.id, 'revision_conflict');
        }
      }
      const eligible = deniedSources.size || withheldSources?.size
        ? sources.filter(source => !deniedSources.has(source.id) && !withheldSources?.has(source.id)) : sources;
      rawLineage.assertReceipts(ns, eligible.map(source => ({ client: source.origin_client, sessionId: source.origin_session,
        eventId: source.message_id, role: source.role, excerpt: source.text })), false, undefined, undefined,
        mode ? (index, code) => withholdSource(eligible[index].id, code) : undefined);
    }
    try { validate(); }
    catch (error) {
      if (mode === 'batch' && error === metadataDenial) return false;
      if (mode === 'detail' && firstSourceDenial && error instanceof MemoryStoreError) fail(firstSourceDenial);
      throw error;
    }
    return { deniedSources, checkedSources };
  }
  const episodeReads = createEpisodeReads({ db, epoch, decisionReview, assertEpisodeRead, episodeProjection });
  const proceduralStorage = createProceduralStorage({ db, activeRow:(ns,id)=>memoryWriteSafety(ns,visibleRow(ns,id)), advanceEpoch, epoch });
  const sessionContextStorage = createSessionContextStorage({ db, epoch, indexStorage, proceduralStorage, decisionReview, assertEpisodeRead, episodeProjection,
    readSourceEvidence: row => readSourceEvidence(row, undefined, { withholdDenied: true }) });
  let episodes;
  episodes = createEpisodeStorage({ db, options: sessionEpisodes, stagedEvidence, advanceEpoch, epoch,
    forgetMutation, rawCapture, sourceAuthority: rawLineage, sourceRoots, assertEpisodeRead, episodeProjection,
    deleteEpisode: (ns, input) => sourceRoots.enabled() ? deletion.forgetEpisode(ns, input) : undefined });
  stagedEvidence.setEpisodes(episodes);
  deletion = createRawDeletionStorage({ db, localRawPrivacy, roots: sourceRoots, episodes, forgetMutation, removeReceipts, advanceEpoch });
  const admissionStorage = createAdmissionStorage({
    db, admitMutation, validateReceiptTimes, isSuppressed, activeRow, epoch, conflictStorage, stagedEvidence,
    classificationJournal, episodes, proceduralStorage, assertSources: rawLineage.assertReceipts, sourceRoots, memoryAncestry, privacyMemoryDenied,
  });
  const orderedStorage = createOrderedCaptureStorage({ db, admissionStorage, epoch, activeRow,
    supersessionStorage, receiptKey, isSuppressed });

  const resolveHeld = createHeldReviewResolver({ db, activeRow, supersessionStorage, conflictStorage });
  const resolveReview = createConfirmationStorage({ db, enabled: decisionReview, activeRow, attach, forgetMutation, advanceEpoch, resolveHeld,
    assertConfirm(ns,row,boundRevision,result) {
      if(!cachedContentLayout(db)?.suppressionRevision)return;
      if(!row)fail('memory_suppressed');
      if(boundRevision===undefined)memoryWriteSafety(ns,row);
      else if(contentSuppressionReasonInside(db,ns,{kind:'memory',key:row.id,revision:boundRevision,
        version:JSON.stringify(['memory-revision-v1',boundRevision])}))fail('memory_suppressed');
      if(result)assertContentOutput(db,identity,result,[ns],{factsOnly:true});
    } });

  let captureSourceDepth = 0;
  const assertContentScope = (scopes, { delivery = false } = {}) => { ready();
    if (!cachedContentLayout(db)?.suppressionRevision) return;
    if (!delivery && scopes.length && hasContentSuppressionRequestInside(db) && !db.isTransaction) {
      contentSuppressionRequestInside(db, scopes, { defer: true }); return;
    }
    const check = () => {
      if (delivery) assertContentSuppressionRequestInside(db, scopes);
      assertContentScopes(db, scopes, 'memory_not_found');
    };
    // Capture may be nested in a writer's deliberately uncached context. Its
    // entry/delivery scope lookup must not run an unbounded fact fallback in
    // an implicit SHARED snapshot either. Acquire writer priority first.
    if (captureSourceDepth && !db.isTransaction && scopes.some(ns =>
        { const proof=cachedContentSuppressionRequestInside(db,ns.ownerId);
          return !proof?.facts || !proof.readSet.some(selected=>selected.scope==='owner' ||
            selected.scope===ns.scope && (selected.projectId??'')===(ns.projectId??'')); })) return dispatchSynchronousCommit(db, () => transaction(db, check));
    check();
  };
  function captureSourceRead(ns, work) {
    const layout = cachedContentLayout(db);
    if (!layout) fail('unsupported_database');
    // Legacy source checks retain their exact direct-call cost and semantics.
    // Safety first tries a bounded coherent read; uncertainty uses the complete
    // writer validator after releasing SHARED.
    if (!layout.suppressionRevision) return work();
    const deadline = performance.now()+SOURCE_SNAPSHOT_MS;
    try { return readTransaction(db, () => {
      // Reattest the installed safety layout inside this source snapshot.
      checkInstalledContentSafety(db);
      return withContentSuppressionReadInside(db,[ns],proof=>rawLineage.sourceSnapshot(work,proof,deadline));
    }); }
    catch (error) {
      if (isSourceSnapshotOverflow(error)) {
        // The incomplete read has rolled back and released SHARED. Respect an
        // earlier RESERVED writer before validating the entire source population.
        try { return dispatchSynchronousCommit(db, () => transaction(db,work)); }
        catch (failure) { if(isStorageBusy(failure))throw captureSourceBusy(); throw failure; }
      }
      if (isStorageBusy(error)) throw captureSourceBusy();
      throw error;
    }
  }
  for(const boundary of [assertContentScope,ready,cardStorage,methodStorage,assetStorage,roleStorage])registerContentWriteBoundary(boundary,db);
  function createRuntimeFacade() {
  return contentSafetyFacade({
    assertContentScope,
    contentPortGuard(scopes) { ready(); return contentScopeEpochGuard(db,scopes); },
    assertContentOutput(value, scopes) { ready(); if (!(cachedContentLayout(db) ?? installedContentLayout(db)).suppressionRevision) return;
      return assertContentOutput(db,identity,value,scopes); },
    listReviewConflicts(ns, count, status, after, expectedEpoch) {
      ready();
      if (!decisionReview) fail('decision_review_required');
      return transaction(db, () => {
        const current = epoch(ns);
        if (expectedEpoch !== undefined && current !== expectedEpoch) fail('cursor_stale');
        const rows = db.prepare(`SELECT c.* FROM confirmation_conflicts c JOIN memories m ON m.id=c.memory_id
          WHERE m.owner_id=? AND m.scope=? AND m.project_id=? AND (?='all' OR c.status=?)
          AND (c.memory_id,c.target_id) > (?,?) ORDER BY c.memory_id,c.target_id LIMIT ?`)
          .all(...boundary(ns), status, status === 'restored' ? 'applied' : status,
            after?.memoryId ?? '', after?.targetId ?? '', count + 1);
        if (cachedContentLayout(db)?.suppressionRevision) for (const row of rows) assertContentOutput(db,identity,[
          {type:'memory',namespace:ns,memoryId:row.memory_id,revision:row.memory_revision},
          {type:'memory',namespace:ns,memoryId:row.target_id,revision:row.target_revision}], [ns]);
        return { rows, epoch: current };
      }, undefined, { deferred: true });
    },
    listReviewTransitions(ns, count, status, after, expectedEpoch) {
      ready();
      if (!decisionReview) fail('decision_review_required');
      return transaction(db, () => {
        const current = epoch(ns);
        if (expectedEpoch !== undefined && current !== expectedEpoch) fail('cursor_stale');
        const statement = db.prepare(`SELECT t.*,p.revision AS predecessor_current_revision,m.revision AS replacement_current_revision
          FROM confirmation_supersessions t JOIN memories m ON m.id=t.replacement_id JOIN memories p ON p.id=t.previous_id
          WHERE m.owner_id=? AND m.scope=? AND m.project_id=? AND t.result IS NOT NULL AND (?='all' OR t.status=?)
          AND (t.replacement_id,t.previous_id) > (?,?) ORDER BY t.replacement_id,t.previous_id LIMIT ?`);
        const rows = [];
        const size = count + 1;
        const safety = cachedContentLayout(db)?.suppressionRevision;
        let anchor = after;
        while (true) {
          const batch = statement.all(...boundary(ns), status, status,
            anchor?.replacementId ?? '', anchor?.predecessorId ?? '', size);
          for (const row of batch) {
            try {
              if (safety) {
                const predecessor = {type:'memory',namespace:ns,memoryId:row.previous_id,revision:row.previous_revision};
                const replacement = {type:'memory',namespace:ns,memoryId:row.replacement_id,revision:row.replacement_revision};
                assertContentOutput(db, identity, [predecessor, replacement,
                  {namespace:ns,receiptIds:[...JSON.parse(row.previous_receipt_ids),...JSON.parse(row.receipt_ids)]}], [ns]);
                // The contract emits the current revisions as well as retaining
                // the transition's bound evidence for authorization.
                if (cachedContentSuppressionRequestInside(db, ns.ownerId)?.facts?.length !== 0) {
                  const emitted = [[predecessor, row.predecessor_current_revision], [replacement, row.replacement_current_revision]];
                  for (const [ref, revision] of emitted) {
                    if (revision !== ref.revision) assertContentOutput(db, identity, { ...ref, revision }, [ns]);
                  }
                }
              }
            } catch (error) {
              if (error.code === 'evidence_unavailable') continue;
              throw error;
            }
            rows.push(row);
            if (rows.length === size) break;
          }
          if (rows.length === size || batch.length < size) break;
          const last = batch.at(-1);
          anchor = { replacementId: last.replacement_id, predecessorId: last.previous_id };
        }
        return { rows, epoch: current };
      }, undefined, { deferred: true });
    },
    isSuppressed(ns, value) { ready(); return readTransaction(db, () => isSuppressed(ns, value)); },
    isAwaiting(ns, id) { ready(); return activeRow(ns, id)?.review_state === 'awaiting'; },
    resolveReview(ns, action, input) { ready(); return resolveReview(ns, action, input); },
    prepareEpisodeKeep(ns,input) { ready(); return episodes.prepareKeep(ns,input); },
    failEpisodeKeep(ns,input,code) { ready(); return episodes.failKeep(ns,input,code); },
    assertEpisodeKeep(ns,input,delivery) { ready(); return episodes.assertKeep(ns,input,delivery); },
    validateEpisodeBatch(ns, input) { ready(); return episodes.validateBatch(ns, input); },
    episodeCaptureState(ns, input) { ready(); return episodes.captureState(ns, input); },
    pendingEpisodeSession(ns, input) { ready(); return episodes.pendingSession(ns, input); },
    episodeDraftSnapshot(ns, input) { ready(); return episodes.draftSnapshot(ns, input); },
    startEpisodeAttempt(ns, input, deadline) { ready(); return episodes.startAttempt(ns, input, deadline); },
    settleEpisodeAttempt(ns, input) { ready(); return episodes.settleAttempt(ns, input); },
    episodeSessionKey(ns, client, sessionId) { ready(); return episodes.sessionKey(ns, client, sessionId); },
    reserveEpisodeBatch(ns, input, registration) { ready(); return episodes.reserveBatch(ns, input, registration); },
    setEpisodePolicy(ns,input) { ready(); return episodes.setPolicy(ns,input); },
    claimEpisodeWriter(ns, input, deadline) { ready(); return episodes.claimWriter(ns, input, deadline); },
    releaseEpisodeWriter(ns, input) { ready(); return episodes.releaseWriter(ns, input); },
    claimEpisodeDraft(ns, input, deadline) { ready(); return episodes.claimDraft(ns, input, deadline); },
    episodeDraftOutcome(ns, input) { ready(); return episodes.draftOutcome(ns, input); },
    failEpisodeDraft(ns, input) { ready(); return episodes.failDraft(ns, input); },
    commitEpisodeDraft(ns, input, deadline) { ready(); return episodes.commitDraft(ns, input, deadline); },
    getEpisode(ns, input, pages) { ready(); return episodes.inspect(ns, input, pages); },
    forgetEpisode(ns, input) { ready(); return episodes.forget(ns, input); },
    correctEpisode(ns, input) { ready(); return episodes.correct(ns, input); },
    releaseEpisodeCorrection(ns, input) { ready(); return episodes.releaseCorrection(ns, input); },
    getCaptureControl(ns) { ready(); return episodes.getControl(ns); },
    setCapturePaused(ns, input) { ready(); return episodes.setControl(ns, input); },
    setProjectCapture(ns, input) { ready(); return episodes.setControl(ns, input, true); },
    setProceduralMemory(ns, input) { ready(); return proceduralStorage.set(ns, input); },
    closeEpisodeNextStep(ns, input) { ready(); return episodes.closeNextStep(ns, input); },
    sessionContextSnapshot(ns, groups, expected) { ready(); return sessionContextStorage(ns, groups, expected); },
    episodeRange(ns, operation, filter, cursor) { ready(); return episodeReads(ns, operation, filter, cursor); },
    privateCards: privateCards ? bindCommitRuntime(cardStorage, db) : undefined,
    ...(internal?.engineCards ? {
      engineCardAvailable() { ready(); return Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name='card_applicability_reviews'").get()) ||
        !input.existingStore && !input.storeFence && [18,20,21,22].includes(db.prepare('PRAGMA user_version').get().user_version); },
      async engineCardStorage() {
        ready();
        const { createEngineCardStorage } = await import('./engine-card-storage.mjs');
        ready(); return withSynchronousCommitScope('lazy Card storage init', () => bindCommitRuntime(createEngineCardStorage({ db, identity, ready, rawReader: rawCapture?.engineSourceReader(),
          upgrade: !input.existingStore && !input.storeFence }), db));
      },
    } : {}),
    methodPackages: methodStorage,
    roleProfiles: roleStorage,
    assets: assetStorage,
    rawSourceReader: internal?.rawSources ? rawCapture?.sourceReader : undefined,
    previewDeleteConversation(input) { ready(); return deletion.preview(input); },
    deleteConversation(input) { ready(); return deletion.remove(input); },
    listRawEffects(input) { ready(); return deletion.list(input); },
    identity, ready, admit, correct, forget, supersede, bindQualifiedClaim, transitionQualified, transitionQualifiedSet,
    legacyGet, legacyList, legacySearch,
    listPage, getPage, fetchPage, recentReceipts, recallSnapshot, sourceSnapshot,
    rationaleSnapshot(ns, refs, inputMode) { ready(); return rationaleStorage.snapshot(ns, refs, inputMode); },
    commitRationale(ns, refs, snapshot, proposals, deadline) {
      ready(); return rationaleStorage.commit(ns, refs, snapshot, proposals, deadline);
    },
    getRationale(ns, ref, view) { ready(); return rationaleStorage.inspect(ns, ref, view); },
    claimOrdered(ns, snapshot, deadline, registration, sources) { ready(); return orderedStorage.claim(ns, snapshot, deadline, registration, sources); },
    discoverOrdered(ns, snapshot, order, items) {
      ready(); return orderedStorage.discover(ns, snapshot, order, items);
    },
    finishOrdered(ns, snapshot, token, order, prepared, judged, deadline) {
      ready(); return orderedStorage.finish(ns, snapshot, token, order, prepared.discovery,
        prepared.items, judged.decisions, judged.reason, deadline);
    },
    rebuildIndex(ns, input) { ready(); return indexStorage.rebuildIndex(ns, input); },
    inspectAdmission(ns, input) { ready(); return admissionStorage.inspectAdmission(ns, input); },
    claimAdmission(ns, input, deadline) { ready(); return admissionStorage.claimAdmission(ns, input, undefined, undefined, deadline); },
    filterCaptureSources(ns, sources) { ready(); return captureSourceRead(ns, () => rawLineage.filter(ns, sources)); },
    assertCaptureSources(ns, sources) { ready(); return captureSourceRead(ns, () => rawLineage.assertReceipts(ns, sources)); },
    captureSnapshot(ns, input, qualification, policy) {
      ready();
      // Old layouts validate new times, then omit them before hashing or staging.
      return captureSnapshot(input, qualification, policy,
        receiptEventTimeEnabled(cachedContentLayout(db)), new Date().toISOString());
    },
    claimCapturedAdmission(ns, input, deadline, registration, sources) {
      ready(); return admissionStorage.claimAdmission(ns, input, undefined, undefined, deadline, registration, sources);
    },
    claimCaptureEvidence(ns, input, deadline, registration, sources) {
      ready();
      if (input.view === undefined) fail('invalid_input');
      return admissionStorage.claimAdmission(ns, input, undefined, input.view, deadline, registration, sources);
    },
    inspectCaptureEvidence(ns, input) { ready(); return stagedEvidence.inspect(ns, input); },
    discardCaptureEvidence(ns, input) { ready(); return stagedEvidence.discard(ns, input); },
    assertCaptureEvidence(ns, input, deadline) { ready(); return input[captureDispatch]
      ? admissionStorage.beginCaptureDispatch(ns, input, deadline) : admissionStorage.assertCaptureEvidence(ns, input); },
    finishAdmission(ns, input) { ready(); return admissionStorage.finishAdmission(ns, input); },
    finishCapturedAdmission(ns, input, deadline, captureQualifiedDuplicates) {
      ready(); return admissionStorage.finishAdmission(ns, input, { initialClassification: true,
        ...(captureQualifiedDuplicates ? { captureQualifiedDuplicates } : {}) }, deadline);
    },
    beginInitialClassification(ns, input, admitted, selected, deadline) {
      ready(); return classificationJournal.begin(ns, input, admitted, selected, deadline);
    },
    failInitialClassification(ns, input, token) {
      ready(); return classificationJournal.failAttempt(ns, input, token);
    },
    applyInitialPlacement(ns, input, token, proposal, guards, index, deadline) {
      ready(); return mocStorage.applyPlacement(ns, proposal, guards, index,
        { client: input.client, eventId: input.eventId, token, deadline });
    },
    abandonAdmission(ns, input) { ready(); return admissionStorage.abandonAdmission(ns, input); },
    applyPlacement(ns, proposal, guards, index) {
      ready(); return mocStorage.applyPlacement(ns, proposal, guards, index);
    },
    linkMocs(ns, input) { ready(); return mocStorage.linkMocs(ns, input); },
    mapRows(ns, input) { ready(); return mocStorage.mapRows(ns, input); },
    queryCandidateRows(ns, input) { ready(); return mocStorage.queryCandidateRows(ns, input); },
    classificationSnapshot(ns, ids, guards, index) {
      ready(); return mocStorage.classificationSnapshot(ns, ids, guards, index);
    },
    suppressionFence(ns, layoutOnly = false) { ready();
      if (layoutOnly) return cachedContentLayout(db)?.suppressionRevision === 1;
      return mocStorage.suppressionFence(ns); },
    assertEpoch(ns, index, suppressionEpoch) { ready(); return mocStorage.assertEpoch(ns, index, suppressionEpoch); },
    epoch(ns) { ready(); return epoch(ns); },
    close() { if (!closed) { if (db.isOpen) db.close(); closed = true; } },
  }, { check: assertContentScope, noOwner: ['ready','close','assertContentScope','assertContentOutput','contentPortGuard'] });
  }
  const runtime = createRuntimeFacade();
  // Include the facade's entry/delivery attestation in these two error
  // boundaries, without changing any other runtime method's error handling.
  const captureSourceBoundary = method => (...args) => {
    captureSourceDepth++;
    try { return runtime[method](...args); }
    catch (error) {
      if (cachedContentLayout(db)?.suppressionRevision && isStorageBusy(error)) throw captureSourceBusy();
      throw error;
    }
    finally { captureSourceDepth--; }
  };
  const result = Object.freeze({ ...runtime,
    filterCaptureSources: captureSourceBoundary('filterCaptureSources'),
    assertCaptureSources: captureSourceBoundary('assertCaptureSources') });
  recallJournalModes.set(result, { db });
  return bindCommitRuntime(result, db);
  } catch (error) {
    try { db.close(); } catch { /* Preserve the construction failure. */ }
    throw error;
  }
}
