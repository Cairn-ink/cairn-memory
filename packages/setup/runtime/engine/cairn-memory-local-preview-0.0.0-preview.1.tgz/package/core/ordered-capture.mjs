import { readFileSync } from 'node:fs';
import { callModel } from './model-call.mjs';
import { denseArray, fail, object } from './validation.mjs';
import { emitDiagnostic } from './model-diagnostics.mjs';

const system = readFileSync(new URL('./prompts/reconcile-memories.md', import.meta.url), 'utf8');

function decisions(output, items, candidates, messages) {
  object(output, ['transitions']);
  const seen = new Set();
  return denseArray(output.transitions, 0, 5).map(transition => {
    object(transition, ['replacementIndex', 'predecessorIndex', 'evidenceIndices',
      'relation', 'valueChange', 'adoption']);
    const { replacementIndex, predecessorIndex, relation, valueChange, adoption } = transition;
    if (!['supersedes', 'reaffirms', 'historical_context', 'compatible', 'unresolved'].includes(relation) ||
        !['changed', 'unchanged', 'unknown'].includes(valueChange) ||
        !['explicit', 'not_adopted', 'uncertain'].includes(adoption) ||
        (relation === 'supersedes' && (valueChange !== 'changed' || adoption !== 'explicit'))) {
      fail('invalid_model_output');
    }
    if (!Number.isInteger(replacementIndex) || replacementIndex < 0 || replacementIndex >= items.length ||
        !Number.isInteger(predecessorIndex) || predecessorIndex < 0 || predecessorIndex >= candidates.length ||
        seen.has(predecessorIndex)) fail('invalid_model_output');
    seen.add(predecessorIndex);
    const evidence = denseArray(transition.evidenceIndices, 1, 4);
    if (new Set(evidence).size !== evidence.length || evidence.some(index =>
      !Number.isInteger(index) || !items[replacementIndex].sourceIndices.includes(index)) ||
      (relation === 'supersedes' && !evidence.some(index => messages[index]?.role === 'user'))) {
      fail('invalid_model_output');
    }
    if (relation !== 'supersedes') return null;
    return { replacementIndex, predecessorIndex,
      receiptIndices: evidence.map(index => items[replacementIndex].sourceIndices.indexOf(index)) };
  }).filter(decision => decision !== null);
}

export async function reconcileCapture({ model, snapshot, items, discovery, deadline, validateFresh, sourceView }) {
  deadline?.check();
  const { candidates } = discovery;
  if (discovery.reason || !items.length || !candidates.length) {
    return { decisions: [], reason: discovery.reason };
  }
  const input = {
    messages: sourceView ?? snapshot.messages.map(({ role, content }, index) => ({ index, role, content })),
    items: items.map(({ content, kind, sourceIndices }, index) => ({ index, content, kind, sourceIndices })),
    candidates: candidates.map(({ row, receipts }, index) => ({ index, content: row.content,
      kind: row.kind, receipts: receipts.map(({ role, excerpt }) => ({ role, excerpt })) })),
  };
  let output;
  try { output = await callModel(model, 'reconcile', system, input,
    { failureCode: 'reconciliation_failed', deadline, validateFresh }); }
  catch (error) {
    if (error.code === 'context_budget_exceeded') return { decisions: [], reason: 'context_budget' };
    throw error;
  }
  try {
    const result = { decisions: decisions(output, items, candidates, snapshot.messages), reason: null };
    deadline?.check();
    return result;
  }
  catch {
    deadline?.check();
    emitDiagnostic(model, 'reconcile', 'core_validation', 'invalid_reconciliation');
    fail('invalid_model_output');
  }
}
