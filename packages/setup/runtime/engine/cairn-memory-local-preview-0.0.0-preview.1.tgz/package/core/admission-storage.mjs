import { ADMISSION_LEASE_MS } from './episode-schema.mjs';
import { captureSourceBusy, isPreDispatchToken, postDispatchToken, preDispatchToken } from './capture-source-safety.mjs';
import { inContentSuppressionRequestInside } from './content-suppression-storage.mjs';
import { cachedContentLayout } from './content-safety-schema.mjs';
import { contentReadSafety } from './content-safety.mjs';
import { createHash, randomUUID } from "node:crypto";
import { transaction, isStorageBusy } from "./database.mjs";
import { fail, identifier } from "./validation.mjs";
import { localAuthorityGuard } from './local-authority-guard.mjs';

// Existing admission schemas cap each suppressed_count at five. Larger captures
// keep their exact total in source-free supplemental rows in this same table;
// no Memory identities, receipts or schema changes are needed for the counter.
const suppressionCounterKey = (ns, input, part) => createHash('sha256').update(JSON.stringify([
  'capture-suppression-counter-v1', ns.ownerId, ns.scope, ns.projectId ?? '', input.client,
  input.keepActionId ? 'keep' : 'capture', input.keepActionId ?? input.eventId, part,
])).digest('hex');
const counterClient = 'capture-suppression-counter-v1';

export function capturedSuppressedCount(db, ns, input, row) {
  let count = row.suppressed_count;
  if (count !== 5) return count;
  for (let part = 1; part <= 3; part++) {
    const extra = db.prepare(`SELECT state,memory_ids,suppressed_count,payload_digest FROM admission_claims
      WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND event_id=?`)
      .get(ns.ownerId, ns.scope, ns.projectId ?? '', counterClient, suppressionCounterKey(ns, input, part));
    if (!extra) break;
    if (extra.state !== 'completed' || extra.memory_ids !== '[]' || extra.payload_digest !== row.payload_digest ||
        !Number.isInteger(extra.suppressed_count) || extra.suppressed_count < 1 || extra.suppressed_count > 5) fail('storage_error');
    count += extra.suppressed_count;
    if (extra.suppressed_count < 5) break;
  }
  return count;
}

const where = "owner_id = ? AND scope = ? AND project_id = ? AND client = ? AND event_id = ?";
const key = (ns, input) => [ns.ownerId, ns.scope, ns.projectId, input.client, input.eventId];

/** Content-free job state around the shared admission mutation transaction. */
export function createAdmissionStorage({ db, admitMutation, validateReceiptTimes, isSuppressed, activeRow, epoch,
  conflictStorage, stagedEvidence, classificationJournal, episodes, proceduralStorage, assertSources, sourceRoots, memoryAncestry = () => '', privacyMemoryDenied = row => {
    if(!cachedContentLayout(db)?.suppressionRevision)return false;
    const namespace={ownerId:row.owner_id,scope:row.scope,projectId:row.project_id};
    return !contentReadSafety(db,{namespace,selectedMemory:row,intent:'history',ref:{type:'memory',namespace,memoryId:row.id,revision:row.revision}}).allowed;
  } }) {
  // A current feature-off connection may predate another connection's optional
  // migration. Cache presence, never absence, so persisted guards still apply.
  let rawCaptureAvailable = false;
  const hasRawCapture = () => rawCaptureAvailable ||= Boolean(db.prepare("SELECT 1 FROM sqlite_master WHERE name='raw_capture_events'").get());
  function rawGuard(ns, input) {
    if (input.keepActionId || !hasRawCapture()) return null;
    const captured = db.prepare(`SELECT * FROM raw_capture_events WHERE ${where}`).get(...key(ns, input));
    if (!captured) return null;
    const localDenied = localAuthorityGuard(db,captured);
    if (localDenied) return localDenied;
    if (captured.projection_digest !== input.payloadDigest) return 'event_payload_conflict';
    const control = episodes.getControl(ns);
    if (control.paused || !control.enabled || control.generation !== captured.capture_generation) return 'capture_evidence_closed';
    if (db.prepare(`SELECT 1 FROM raw_session_fences WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key=?`)
      .get(ns.ownerId, ns.scope, ns.projectId, input.client, captured.session_key)) return 'capture_evidence_closed';
    if (db.prepare(`SELECT 1 FROM session_episodes WHERE owner_id=? AND scope=? AND project_id=? AND client=? AND session_key=? AND deleted=1`)
      .get(ns.ownerId, ns.scope, ns.projectId, input.client, captured.session_key)) return 'capture_evidence_closed';
    return null;
  }
  const table = input => input.keepActionId ? 'episode_keep_actions' : 'admission_claims';
  const predicate = input => input.keepActionId ? 'owner_id=? AND scope=? AND project_id=? AND admission_key=?' : where;
  const values = (ns, input) => input.keepActionId ? [ns.ownerId, ns.scope, ns.projectId, input.keepActionId] : key(ns, input);
  const read = (ns, input) => db.prepare(`SELECT * FROM ${table(input)} WHERE ${predicate(input)}`)
    .get(...values(ns, input));
  const time = (ns, input, create) => input.keepActionId ? Date.now() : stagedEvidence.admissionTime(ns, input, create);
  const guard = (method, ns, input, ...args) => sourceRoots?.jobGuard(ns, input) || rawGuard(ns, input) || (input.keepActionId ? episodes.guard(ns, input)
    : stagedEvidence[method](ns, input, ...args));
  const live = (row, input, now) => row?.state === "pending" &&
    row.payload_digest === input.payloadDigest && row.token === input.token &&
    row.lease_expires_at > now;

  function inspectAdmission(ns, input) {
    // A deferred read transaction gives claim state and every member one
    // consistent snapshot without acquiring an admission lease or write lock.
    db.exec('BEGIN');
    let result;
    try {
      inContentSuppressionRequestInside(db,()=>{
      const row = db.prepare(`SELECT state, memory_ids, suppressed_count, payload_digest FROM admission_claims WHERE ${where}`)
        .get(...key(ns, input));
      if (!row) result = { status: 'absent', classification: { status: 'unknown' } };
      else if (row.state === 'pending' || row.state === 'reserved') result = { status: 'pending', classification: { status: 'unknown' } };
      else {
        let ids;
        try { ids = JSON.parse(row.memory_ids); } catch { fail('storage_error'); }
        if (!Array.isArray(ids) || ids.length > 20 ||
          !Number.isInteger(row.suppressed_count) || row.suppressed_count < 0 ||
          row.suppressed_count > 5 || new Set(ids).size !== ids.length) fail('storage_error');
        try { ids.forEach(identifier); } catch { fail('storage_error'); }
        const findCurrent = db.prepare(`SELECT memories.*${memoryAncestry()} FROM memories
          WHERE owner_id = ? AND scope = ? AND project_id = ? AND id = ?
            AND deleted = 0 AND review_state != 'awaiting' AND currentness = 'current'`);
        const members = ids.map((id) => {
          const current = findCurrent.get(ns.ownerId, ns.scope, ns.projectId, id);
          if (current && privacyMemoryDenied(current)) fail('evidence_unavailable');
          return current ? { status: 'current', memoryId: id, revision: current.revision,
            filing: { status: current.filing_status } } : { status: 'closed' };
        });
        result = { status: 'completed', classification: { status: 'unknown' },
          suppressedCount: capturedSuppressedCount(db, ns, input, row), members };
      }
      if (input.includeInitialClassification === true) result.initialClassification =
        row?.state === 'completed' ? classificationJournal.inspect(ns, input) : { status: 'unknown' };
      });
      db.exec('COMMIT');
      return result;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }

  function claimAdmission(ns, input, hooks, stagedView, deadline, registration, sources) {
    const pending = retryCleanup.get(cleanupKey(ns, input));
    if (pending) {
      abandonAdmission(ns, pending);
      retryCleanup.delete(cleanupKey(ns, input));
    }
    const serialized = stagedView === undefined ? null : stagedEvidence.serializeView(stagedView);
    let rawRefusal = false;
    const result = transaction(db, () => {
      const registeredRaw = registration?.commit();
      if (registeredRaw?.closed) { rawRefusal = true; return registeredRaw; }
      if (registeredRaw?.observation) return { rawReplay: registeredRaw.observation };
      const now = time(ns, input, serialized !== null);
      const row = read(ns, input);
      const refuse = closed => { if (registration) fail(closed); return { closed }; };
      if (row && row.payload_digest !== input.payloadDigest) return refuse('event_payload_conflict');
      for (const source of sources ?? []) sourceRoots?.assertSession(ns, source.client, source.sessionId);
      const closed = guard('claimGuard', ns, input, row, now, serialized !== null);
      if (closed) return refuse(closed);
      if (row?.state === "completed") {
        const memoryIds=JSON.parse(row.memory_ids);
        if(cachedContentLayout(db)?.suppressionRevision)for(const id of memoryIds){const current=activeRow(ns,id);
          if(!current||!contentReadSafety(db,{namespace:ns,ref:{type:'memory',namespace:ns,memoryId:id,revision:current.revision},intent:'history'}).allowed)fail('memory_suppressed');}
        return { duplicate: true, memoryIds,
          suppressedCount: capturedSuppressedCount(db, ns, input, row), ...hooks?.replay() };
      }
      if (row) sourceRoots?.bindJob(ns, input, sources);
      const prepared = hooks?.prepare(row);
      if (row && row.lease_expires_at > now && !stagedEvidence.isRetryReservation?.(row)) return { processing: true };
      const registered = episodes.event(ns, input);
      // The guard has proved an existing pending safety payload in this same
      // writer transaction. Reuse its capacity and original retention clock.
      const reuseStaged = Boolean(cachedContentLayout(db)?.suppressionRevision && stagedEvidence.isRetryReservation?.(row));
      const capacity = !reuseStaged && !registered && serialized && stagedEvidence.capacityGuard(ns, serialized);
      if (capacity && !registration) return { closed: capacity };
      const id = randomUUID();
      // Preserve the phase on automatic retries even with staging now off.
      // Public manual claims supply no sources and keep their ordinary token.
      const token = (serialized || (reuseStaged && sources)) &&
        !registered && cachedContentLayout(db)?.suppressionRevision ? preDispatchToken(id) : id;
      if (row) {
        db.prepare(`UPDATE ${table(input)} SET state = 'pending', token = ?, lease_expires_at = ? WHERE ${predicate(input)}`)
          .run(token, now + input.leaseMs, ...values(ns, input));
      } else {
        db.prepare(`INSERT INTO admission_claims
          (owner_id, scope, project_id, client, event_id, payload_digest, state, token, lease_expires_at)
          VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?)`)
          .run(...key(ns, input), input.payloadDigest, token, now + input.leaseMs);
      }
      const episodePolicy = registered ? episodes.admissionStarted(ns, input) : undefined;
      if (!row) sourceRoots?.bindJob(ns, input, sources);
      if (!reuseStaged && serialized && !registered && !capacity) stagedEvidence.insert(ns, input, serialized, now);
      if (serialized && !registered) registration?.setStaging(capacity ? 'not-staged' : 'staged');
      return { token, ...prepared, ...(registered ? { episodePolicy } : {}) };
    }, () => { if (!rawRefusal) deadline?.check(); });
    if (result.closed) fail(result.closed);
    registration?.accept();
    return result;
  }

  // Only safety staged claims carry this private phase. The committed token
  // replacement is the dispatch fence: a crash afterwards is conservatively
  // treated as possibly dispatched, even if the provider was never entered.
  function beginCaptureDispatch(ns, input, deadline) {
    if (!isPreDispatchToken(input.token)) return { token: input.token };
    try { return transaction(db, () => {
      const now = time(ns, input);
      const row = read(ns, input);
      if (row?.state !== 'pending' || row.payload_digest !== input.payloadDigest ||
        row.token !== input.token) fail('stale_admission');
      // This exact token still owns a proved pre-dispatch attempt. Its old
      // lease may expire during source validation without closing evidence.
      // Validate the proposed paid lease, then persist both fields atomically.
      const leaseExpiresAt = now + ADMISSION_LEASE_MS;
      const closed = guard('finishGuard', ns, input, { ...row, lease_expires_at: leaseExpiresAt }, now);
      if (closed) fail(closed);
      const token = postDispatchToken(input.token);
      db.prepare(`UPDATE admission_claims SET token=?,lease_expires_at=? WHERE ${where}`)
        .run(token, leaseExpiresAt, ...key(ns, input));
      return { token };
    }, deadline?.check); } catch (error) {
      if (isStorageBusy(error)) throw captureSourceBusy();
      throw error;
    }
  }

  function finishAdmission(ns, input, hooks, deadline) {
    const result = transaction(db, () => {
      const now = time(ns, input);
      const row = read(ns, input);
      const closed = guard('finishGuard', ns, input, row, now);
      if (closed) return { closed };
      if (!live(row, input, now)) fail("stale_admission");
      // The public manual finish cannot bypass ordered capture's private proof.
      if (!input.keepActionId && !hooks?.validate && db.prepare(`SELECT 1 FROM capture_events WHERE ${where}`)
        .get(...key(ns, input))) fail('stale_admission');
      hooks?.validate?.();
      const ids = new Set();
      let suppressedCount = 0;
      const activeItems = [];
      for (const item of input.items) {
        // Timed items use this same instant for validation and created_at, even
        // when suppression would otherwise skip the item without attaching.
        const receiptNow = item.receiptTimes?.some(time => time != null) ? new Date().toISOString() : undefined;
        validateReceiptTimes?.(item, receiptNow);
        assertSources?.(ns, item.receipts);
        // Check before deduplication; one suppressed input contributes one count.
        if (isSuppressed(ns, item.fingerprint)) {
          suppressedCount++;
          continue;
        }
        conflictStorage.validateTargets(ns, item.conflictHints);
        activeItems.push({ item, receiptNow });
      }
      const entries = activeItems.map(({ item, receiptNow }) => {
        const result = admitMutation(ns, item, { automatic: true,
          ...(hooks?.captureQualifiedDuplicates ? { captureQualifiedDuplicates: hooks.captureQualifiedDuplicates } : {}) }, receiptNow);
        const memoryId = result.memory.id;
        if (item.procedural !== undefined) proceduralStorage.write(result.memory, item.procedural, 'model', item.receipts);
        ids.add(memoryId);
        return { memoryId, hints: item.conflictHints, item,
          insertedReceiptIds: result.insertedReceiptIds };
      });
      conflictStorage.insertBatch(ns, entries, "inferred-hint");
      const extra = hooks?.admitted?.(entries);
      const memoryIds = [...ids];
      // Resolve revisions after the entire batch: later exact matches can attach
      // receipts to an earlier result while preserving its first occurrence order.
      const memories = memoryIds.map((id) => ({ id, revision: activeRow(ns, id).revision }));
      db.prepare(`UPDATE ${table(input)} SET state = 'completed', token = NULL,
        lease_expires_at = NULL, memory_ids = ?, suppressed_count = ? WHERE ${predicate(input)}`)
        .run(JSON.stringify(memoryIds), Math.min(5, suppressedCount), ...values(ns, input));
      for (let remaining = suppressedCount - 5, part = 1; remaining > 0; remaining -= 5, part++) {
        db.prepare(`INSERT INTO admission_claims(owner_id,scope,project_id,client,event_id,payload_digest,state,memory_ids,suppressed_count)
          VALUES(?,?,?,?,?,?,'completed','[]',?)`).run(ns.ownerId, ns.scope, ns.projectId, counterClient,
          suppressionCounterKey(ns, input, part), input.payloadDigest, Math.min(5, remaining));
      }
      hooks?.complete?.();
      episodes.admitted(ns, input, entries);
      if (!input.keepActionId) stagedEvidence.mark(ns, input, 'admitted');
      if (hooks?.initialClassification && !input.keepActionId) classificationJournal.insert(ns, input, memories);
      return { duplicate: false, memories, suppressedCount, indexRevision: epoch(ns), ...extra };
    }, deadline?.check);
    if (result.closed) fail(result.closed);
    return result;
  }

  // Retain cleanup for the older protocols. Safety staged pre-dispatch tokens
  // also recover durably without this in-process map or a successful cleanup.
  const retryCleanup = new Map();
  const cleanupKey = (ns, input) => JSON.stringify(values(ns, input));
  function abandonAdmission(ns, input) {
    try { return transaction(db, () => {
      const now = time(ns, input);
      const row = read(ns, input);
      // The expired owner may record its failure, but cannot release a successor.
      if (row?.state !== 'pending' || row.payload_digest !== input.payloadDigest ||
        row.token !== input.token) return { abandoned: false };
      if (!input.keepActionId && !input.retryable) stagedEvidence.mark(ns, input, 'failed');
      if (input.retryable) {
        db.prepare(`UPDATE ${table(input)} SET state='reserved',token=NULL,lease_expires_at=NULL WHERE ${predicate(input)}`)
          .run(...values(ns, input));
        return { abandoned: true };
      }
      if (!live(row, input, now)) return { abandoned: false };
      db.prepare(`UPDATE ${table(input)} SET lease_expires_at = 0 WHERE ${predicate(input)}`)
        .run(...values(ns, input));
      return { abandoned: true };
    }); } catch (error) {
      if (input.retryable && isStorageBusy(error)) retryCleanup.set(cleanupKey(ns, input), { ...input });
      throw error;
    }
  }

  function assertCaptureEvidence(ns, input) {
    const result = transaction(db, () => {
      const now = time(ns, input);
      const row = read(ns, input);
      return guard('finishGuard', ns, input, row, now) ||
        (!live(row, input, now) ? 'capture_evidence_closed' : null);
    });
    if (result) fail(result);
    return null;
  }

  return { claimAdmission, beginCaptureDispatch, finishAdmission, abandonAdmission, assertCaptureEvidence, inspectAdmission };
}
