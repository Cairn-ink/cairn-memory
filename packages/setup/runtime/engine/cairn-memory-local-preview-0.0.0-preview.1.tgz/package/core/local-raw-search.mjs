import { createHash } from 'node:crypto';
import { mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { openRawSearch } from './raw-search-index.mjs';
import { rawNamespace } from './raw-input.mjs';
import { fail, object } from './validation.mjs';
import { rawSearchRequestState } from './raw-search-request-scope.mjs';

const hash = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const success = value => ({ ok: true, value });
const failure = error => ({ ok: false, error: { code: error?.code ?? 'raw_search_unavailable', retryable: true } });
const owners = new WeakMap();
export const localRawSearchManager = port => owners.get(port) ?? null;

let constructionUpkeep;
/** Internal synchronous construction scope; never inherited by another host. */
export function withLocalRawSearchUpkeep(control, build) {
  const previous = constructionUpkeep;
  constructionUpkeep = control;
  try {
    const result = build();
    if (result?.then) throw Error('raw_upkeep_async_construction');
    return result;
  } finally { constructionUpkeep = previous; }
}

/** Attachment policy is owned by the adapter; managers enforce its generation. */
export function createLocalRawSearchUpkeepControl(scheduler = {}) {
  let enabled = false, sealed = false, generation = new AbortController();
  generation.abort();
  const listeners = new Set(), notify = () => { for (const listener of listeners) listener(); };
  return {
    get enabled() { return enabled; }, get signal() { return generation.signal; },
    setTimer: scheduler.setTimer ?? ((...args) => setTimeout(...args)),
    clearTimer: scheduler.clearTimer ?? (timer => clearTimeout(timer)),
    watch(listener) { listeners.add(listener); return () => listeners.delete(listener); },
    resume() { if (enabled || sealed) return; generation = new AbortController(); enabled = true; notify(); },
    suspend() { if (!enabled) return; enabled = false; generation.abort(); notify(); },
    close() { sealed = true; enabled = false; generation.abort(); notify(); },
  };
}

/** Bounded, non-overlapping maintenance turns, owned by the core. */
export function createLocalRawSearch(path, crypto, { embedder, policy } = {}, { semanticDisabledReason = 'disabled' } = {}) {
  const upkeep = constructionUpkeep;
  const nativeSetTimer = (...args) => setTimeout(...args);
  const nativeClearTimer = timer => clearTimeout(timer);
  const setTimer = upkeep?.setTimer ?? nativeSetTimer;
  const clearTimer = upkeep?.clearTimer ?? nativeClearTimer;
  const admitted = signal => !upkeep || upkeep.enabled && signal === upkeep.signal && !signal.aborted;
  const embeddingPolicy = embedder ? rawEmbeddingPolicy(policy) : null;
  const entries = new Map();
  let timer, running, closing, closed = false, unsupported = false, serviced = 0;
  const unsupportedStatus = () => ({ state: 'unavailable', raw: 'unsupported_store', coverage: 'unknown' });
  const unsupportedSearch = () => ({ candidates: [], coverage: { status: 'unsupported_store' } });
  const maintenanceTurn = { version: 1, maxWaitMs: 25, createTurn() {
    return { enter: () => closed ? 'defer' : 'admitted', release() {} };
  } };
  const normalize = namespace => {
    const ns = rawNamespace(namespace);
    return { ...ns, projectId: ns.projectId || null };
  };
  function entryFor(readSet) {
    if (closed) fail('store_closed');
    if (!Array.isArray(readSet) || !readSet.length || readSet.length > 2) fail('invalid_read_set');
    const namespaces = readSet.map(normalize).sort((a,b) => Buffer.compare(Buffer.from(JSON.stringify(a)), Buffer.from(JSON.stringify(b))));
    if (namespaces.some(ns => ns.ownerId !== namespaces[0].ownerId) || new Set(namespaces.map(ns => JSON.stringify(ns))).size !== namespaces.length) fail('invalid_read_set');
    const key = hash(namespaces.length === 1 ? namespaces[0] : namespaces);
    if (!entries.has(key)) entries.set(key, { key, readSet: namespaces, token: {}, grants: new WeakMap(), readers: new Map(), service: null, opening: null, error: null, lastServed: 0, dirty: false });
    return entries.get(key);
  }
  async function serviceFor(entry, lexical = false, signal = upkeep?.signal) {
    // Both readers belong to the same host authority and canonical store.
    // Keep that private identity so their handles can share a final snapshot.
    entry.authority ??= {
      authorize(request, token) {
        if (closed || token !== entry.token) return null;
        const { input, ...binding } = request, grant = {};
        entry.grants.set(grant, { ...binding, accessGeneration: 1 }); return grant;
      },
      isCurrent: grant => closed ? null : entry.grants.get(grant) ?? null,
    };
    if (lexical && embedder) {
      entry.lexical ??= { ...entry, service: null, opening: null, lexicalOnly: true };
      return serviceFor(entry.lexical, false, signal);
    }
    if (closed) fail('store_closed');
    if (entry.service) return entry.service;
    if (entry.opening && entry.openingSignal?.aborted && signal && !signal.aborted) {
      // A status/read opening can predate the first active upkeep turn. Its
      // cancellation belongs to that old generation, not to the new caller.
      await entry.opening.catch(() => {});
      return serviceFor(entry, false, signal);
    }
    if (!entry.opening) {
      entry.openingSignal = signal;
      entry.opening = (async () => {
      if (path === ':memory:') fail('raw_search_backend_unavailable');
      const directory = resolve(path) + '.raw-search/' + entry.key;
      await mkdir(directory, { recursive: true, mode: 0o700 });
      const service = await openRawSearch({ version: 'raw-search-v1', enabled: true, backend: 'local',
        path: resolve(path), directory, ownerId: entry.readSet[0].ownerId, readSet: entry.readSet,
        authority: entry.authority, crypto, maintenanceTurn, ...(embedder && !entry.lexicalOnly ? { embedder, policy: embeddingPolicy } : {}) }, { signal });
      if (closed) { await service.close(); fail('store_closed'); }
      entry.error = null;
      return entry.service = service;
      })().finally(() => { entry.opening = null; entry.openingSignal = null; });
    }
    return entry.opening;
  }
  function clearScheduledTimer() {
    timer?.clear(timer.handle);
    timer = null;
  }
  function arm(delay = 1000, recover = false) {
    const signal = upkeep?.signal;
    if (!admitted(signal) || closed || unsupported || timer || running || path === ':memory:' || !entries.size) return;
    const scheduled = { clear: clearTimer };
    const callback = () => {
      if (timer !== scheduled || !admitted(signal) || closed) return;
      timer = null;
      running = tick(signal).finally(() => {
        running = null;
        arm(signal === upkeep?.signal ? 1000 : 0, true);
      });
      return running;
    };
    try { scheduled.handle = setTimer(callback, delay); }
    catch (error) {
      if (!recover) throw error;
      // This callback has no attach frame left to roll back. A native timer
      // keeps the attached generation scheduled even if the host timer fails.
      scheduled.clear = nativeClearTimer;
      scheduled.handle = nativeSetTimer(callback, delay);
    }
    timer = scheduled;
    scheduled.handle.unref();
  }
  async function tick(signal) {
    if (!admitted(signal) || closed) return;
    const values = [...entries.values()];
    // Oldest service wins; dirty saves break ties without starving polling of
    // other-process writers. A finite namespace population remains required.
    values.sort((a,b)=>a.lastServed-b.lastServed||Number(b.dirty)-Number(a.dirty)||a.key.localeCompare(b.key));
    const entry=values[0];
    if(entry){entry.lastServed=++serviced;entry.dirty=false;}
    if (!entry || closed) return;
    try {
      const service = await serviceFor(entry, false, signal);
      if (!admitted(signal) || closed) { entry.dirty = true; return; }
      await maintain(entry, service, signal);
      if (!admitted(signal)) entry.dirty = true;
    }
    catch (error) {
      if (signal?.aborted || error?.code === 'raw_upkeep_cancelled') { entry.dirty = true; return; }
      entry.error = error?.code ?? 'raw_search_unavailable';
      // Optional indexing cannot fail capture. A fresh next turn recovers from
      // deadline or lock contention without permanently refusing the connection.
      const service = entry.service; entry.service = null;
      await service?.close().catch(() => {});
    }
  }
  async function maintain(entry, service, signal = upkeep?.signal) {
    if (!admitted(signal) || closed) return;
    // Explicit and scheduled maintenance share the same in-flight operation.
    // Capture only schedules a timer and never joins this provider work.
    if (!entry.maintaining) entry.maintaining = service.maintain({ maxItems: 16, maxMs: 25,
      embeddings: Boolean(embedder), upkeepSignal: signal }, entry.token).finally(() => { entry.maintaining = null; });
    return entry.maintaining;
  }
  function readerRoutes(entry) {
    return rawSearchRequestState(entry, () => {
      // Proof keys and reader references only; the invocation owns retention.
      const state = { prepared: new Map(), searches: new Map(), routes: new Map(), close() {
        state.routes.clear();
      } };
      return state;
    })?.routes ?? entry.readers;
  }
  async function search(entry, service, request) {
    const { semantic, ...input } = request;
    if (semantic !== undefined && typeof semantic !== 'boolean') fail('invalid_input');
    const reader = semantic === false ? await serviceFor(entry, true) : service;
    const result = await reader.search(input, entry.token);
    // Native readers each retain four search proofs. Remember which reader
    // issued a proof so copied candidates keep the native preparation contract.
    if (result.candidates.length) {
      const routes = readerRoutes(entry);
      routes.set(result.candidates[0].proof, reader);
      while (routes.size > 8) routes.delete(routes.keys().next().value);
    }
    entry.semantic = embedder ? result.semantic : Object.freeze({ state: 'bm25-only', reason: semanticDisabledReason });
    return embedder ? result : Object.freeze({ ...result, semantic: entry.semantic });
  }
  async function call(method, input) {
    try {
      object(input, ['namespace', ...(method === 'search' ? ['query', 'intent', 'semantic'] : [])]);
      const { namespace, ...request } = input, entry = entryFor([namespace]);
      if (unsupported) return success(method === 'search' ? unsupportedSearch() : unsupportedStatus());
      arm();
      const service = await serviceFor(entry);
      return success(await (method === 'status' ? service.status().then(status => ({ ...status,
        semantic: entry.semantic ?? { state: 'bm25-only', reason: embedder ? 'partial_coverage' : semanticDisabledReason },
        embeddingBudget: embedder ? { scope: 'process', sharedWith: 'memory',
          maxRequests: embeddingPolicy.maxRequests, maxUsd: embeddingPolicy.maxUsd } : null })) : method === 'maintain'
        ? maintain(entry, service) : search(entry, service, request)));
    } catch (error) { return failure(error); }
  }
  const manager = {
    unsupportedStore() { unsupported = true; clearScheduledTimer(); },
    schedule(namespace) {
      const ns = normalize(namespace);
      const entry=[...entries.values()].find(entry=>entry.readSet.some(value=>same(value,ns)))??entryFor([ns]);
      entry.dirty=true;
      arm(0);
    },
    start() { arm(0); },
    /** Fixed read-set port for contextRead; credentials never enter tool input. */
    contextPort(readSet) {
      const entry = entryFor(readSet), handles = new WeakMap();
      const port = {
        async search(input) {
          if (closed) fail('store_closed');
          if (unsupported) return unsupportedSearch();
          arm(0); return search(entry, await serviceFor(entry), input);
        },
        async prepare(candidate, settings) {
          if (!entry.readSet.some(ns => same(ns, candidate?.namespace))) fail('authority_required');
          const service = readerRoutes(entry).get(candidate?.proof);
          if (!service || ![entry.service, entry.lexical?.service].includes(service)) fail('stale_publication');
          const handle = await service.prepare(candidate, settings, entry.token);
          handles.set(handle, service); return handle;
        },
        async prepareMany(candidates, settings = {}) {
          if (closed) fail('store_closed');
          if (!Array.isArray(candidates) || candidates.length > 24) fail('invalid_input');
          if (!candidates.length) return { handles: [], complete: true };
          // Consecutive reader partitions preserve input/progress order. Each
          // native reader authenticates every proof in its own partition.
          const groups = [];
          for (const candidate of candidates) {
            const reader = entry.readSet.some(ns => same(ns, candidate?.namespace)) ? readerRoutes(entry).get(candidate?.proof) : null;
            const service = [entry.service, entry.lexical?.service].includes(reader) ? reader : null;
            if (!groups.length || groups.at(-1).service !== service) groups.push({ service, candidates: [], start: groups.reduce((n, group) => n + group.candidates.length, 0) });
            groups.at(-1).candidates.push(candidate);
          }
          const prepared = [], deadlineAt = Math.min(settings.deadlineAt ?? Infinity, performance.now() + 1000);
          for (const group of groups) {
            if (performance.now() >= deadlineAt) return { handles: prepared, complete: false };
            if (!group.service) {
              for (const [offset] of group.candidates.entries()) { prepared.push(null); settings.onPrepared?.(null, group.start + offset); }
              continue;
            }
            const result = await group.service.prepareMany(group.candidates, { ...settings, deadlineAt, onPrepared(handle, offset) {
              if (handle) handles.set(handle, group.service);
              settings.onPrepared?.(handle, group.start + offset);
            } }, entry.token);
            prepared.push(...result.handles);
            if (!result.complete || result.handles.length !== group.candidates.length) return { handles: prepared, complete: false };
          }
          return { handles: prepared, complete: true };
        },
        revalidate(selected) {
          if (closed) fail('store_closed');
          if (!Array.isArray(selected)) fail('stale_publication');
          let validator;
          for (const handle of selected) {
            const service = handles.get(handle);
            if (!service || ![entry.service, entry.lexical?.service].includes(service)) fail('stale_publication');
            validator ??= service;
          }
          if (!selected.length) {
            if (!entry.service) fail('stale_publication');
            return entry.service.revalidate([]);
          }
          // Issuing-reader callbacks run first. One reader then checks the
          // entire set in one canonical snapshot, preserving input order.
          return validator.revalidate(selected);
        },
      };
      Object.defineProperty(port, 'supportsLexicalSearch', { value: true });
      Object.freeze(port);
      owners.set(port, manager); return port;
    },
    methods: { searchRaw: input => call('search', input), maintainRawSearch: input => call('maintain', input),
      getRawSearchStatus: input => call('status', input) },
    close() {
      if (closing) return closing;
      closed = true; unwatch?.(); clearScheduledTimer();
      return closing = (async () => {
        // Start native cancellation before joining a scheduled provider wait.
        const stopped = [...entries.values()].map(async entry => {
          const current = Promise.allSettled([entry.service?.close(), entry.lexical?.service?.close()]);
          await entry.opening?.catch(() => {}); await entry.lexical?.opening?.catch(() => {});
          await current;
        });
        await Promise.allSettled([running, ...stopped]);
        entries.clear();
      })();
    },
  };
  const unwatch = upkeep?.watch(() => {
    clearScheduledTimer();
    if (upkeep.enabled) arm(0);
  });
  return manager;
}

// Memory's explicit local policy omits maxUsd because local calls are free;
// the native Raw policy requires that field even for local providers.
function rawEmbeddingPolicy(policy) {
  return { ...policy, ...(policy?.family === 'local' ? { maxUsd: 0 } : {}) };
}
