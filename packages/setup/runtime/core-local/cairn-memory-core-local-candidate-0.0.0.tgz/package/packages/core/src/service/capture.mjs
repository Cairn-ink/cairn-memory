import { createCaptureDeadline } from "../capture/deadline.mjs";
import { emitDiagnostic } from "../capture/model-call.mjs";
import { countTokens, MODEL_OUTPUT_TOKENS, modelRequestText } from "../capture/request-size.mjs";
import { detach, identifier, isWellFormedText, validateDenseArray, validateObject } from "../capture/validate.mjs";
import { CoreError, isErrorCode } from "../errors.mjs";
import { plainExtractionSpec, validatePlainCandidates } from "../extraction/extraction.mjs";
import { fingerprintMemoryPassages } from "../privacy/fingerprint.mjs";
import { hasLegacyPassageDigest, legacyPassageMatcher } from "../privacy/legacy-passages.mjs";
import { redactCore } from "../privacy/redact.mjs";
import { cleanContent, normalizeForHash, prepareCoreText } from "../privacy/text.mjs";
import { requiresLegacyMacDomain, withholdsAnyPassage } from "../privacy/withholds.mjs";
import { captureDocumentSteps } from "./capture-documents.mjs";
import { entry, entryError, scopeOf, isHostWriteHookFailure, writeHookResult } from "./entry.mjs";
import { pauseResult } from "./pause.mjs";
import { prepareWriteText, validWriteEmbedding } from "./writes.mjs";

/** @import {CaptureKey, CaptureMessage, FinishItem, RetainedDigester, Tx} from "../ports/index.d.ts" */
/** @import {CallOptions, Scope} from "../ports/common.d.ts" */
/** @import {ModelRequest} from "../ports/model.d.ts" */
/** @import {SuppressionSnapshot} from "../ports/privacy.d.ts" */
/** @typedef {ReturnType<typeof createCaptureDeadline>} CaptureDeadline */
/** @typedef {Awaited<ReturnType<import("../ports/privacy.d.ts").FingerprintKeyProvider["userKey"]>>} FingerprintKey */
/** @typedef {import("./index.d.mts").MemoryServiceDeps} Deps */
/** @typedef {ReturnType<typeof prepareMessage>} CaptureSource */

// Engine core/capture.mjs:144 gives a plain capture a 125-second admission lease.
const DEFAULT_LEASE_MS = 125_000;
const DEFAULT_EXTRACT_MS = 30_000;
// Hosted openai.ts:83–91 leaves the output budget at the default model's 32,768 tokens.
// The port requires an explicit budget. The serialized bound also allows JSON escaping
// of 20 candidates with 600 units each, plus fields and source indices.
const HOSTED_EXTRACT_OUTPUT_TOKENS = 32_768;
// The provider budget allows 1,024 tokens for schema and framing above the local count.
const EXTRACT_FRAMING_TOKENS = 1024;
const MAX_EXTRACT_OUTPUT_UNITS = 80_000;
const RAW_FALLBACK_FAILURE_CODES = new Set([
  "model_timeout", "extraction_failed", "provider_error", "invalid_model_output",
  "token_count_unavailable", "context_budget_exceeded", "embedding_failed",
  "qualification_failed", "reconciliation_failed", "classification_failed", "rationale_failed",
]);

/** @param {unknown} raw @returns {CaptureMessage} */
function validateMessage(raw) {
  const { id, role, content, occurredAtMs } = validateObject(raw, ["id", "role", "content", "occurredAtMs"]);
  if (!isWellFormedText(id) || !id || id.length > 200 ||
      (role !== "user" && role !== "assistant") || typeof content !== "string" || !content || content.length > 20_000 ||
      (occurredAtMs !== null && (typeof occurredAtMs !== "number" || !Number.isSafeInteger(occurredAtMs)))) {
    throw new CoreError("invalid_input");
  }
  return { id, role, content, occurredAtMs };
}

/** @param {string} cleanedContent */
export function prepareMessageContent(cleanedContent) {
  return redactCore(cleanedContent.normalize("NFKC"));
}

/** @param {unknown} raw */
function prepareMessage(raw) {
  const message = validateMessage(raw);
  const originalContent = message.content;
  if (!isWellFormedText(originalContent)) throw new CoreError("invalid_input");
  return { message: { ...message, content: prepareMessageContent(cleanContent(originalContent)) }, originalContent };
}

/** @param {SuppressionSnapshot["passages"]} passages @param {Scope} [scope] */
export function captureTextWithholding(passages, scope) {
  const textFacts = passages.map(({ fact }) => fact);
  if (!scope && textFacts.some(hasLegacyPassageDigest)) throw new CoreError("internal_error");
  const legacyKeyUnavailable = textFacts.some(requiresLegacyMacDomain);
  const legacyWithholds = scope && legacyPassageMatcher(scope, textFacts);
  // Historical aliases are used for suppression only.
  /** @param {string} originalContent @param {string} preparedContent @param {FingerprintKey | null} key */
  const matches = async (originalContent, preparedContent, key) =>
    legacyWithholds?.(originalContent) ||
    withholdsAnyPassage(await fingerprintMemoryPassages(originalContent, preparedContent, key), textFacts);
  return { legacyKeyUnavailable, legacyWithholds, matches: textFacts.length ? matches : null };
}

/**
 * @param {CaptureSource[]} sources
 * @param {FingerprintKey | null} key
 * @param {readonly RetainedDigester[] | undefined} digesters
 */
async function retainedSourceEvidence(sources, key, digesters) {
  return digesters?.length ? Promise.all(sources.map(({ message, originalContent }) =>
    fingerprintMemoryPassages(originalContent, message.content, key, undefined, digesters))) : null;
}

/**
 * @param {Scope} scope
 * @param {CaptureSource[]} sources
 * @param {number[]} positions
 * @param {SuppressionSnapshot["passages"]} passages
 * @param {FingerprintKey | null} preparedKey
 * @param {Awaited<ReturnType<typeof retainedSourceEvidence>>} preparedEvidence
 * @param {FingerprintKey | null} refreshKey
 */
async function filterScopedCaptureSources(scope, sources, positions, passages, preparedKey, preparedEvidence, refreshKey) {
  const { legacyKeyUnavailable, legacyWithholds, matches } = captureTextWithholding(passages, scope);
  if (!matches) return positions;
  const textFacts = preparedEvidence && passages.map(({ fact }) => fact);
  const allowed = await Promise.all(positions.map(async index => {
    const { message, originalContent } = sources[index];
    if (preparedEvidence && textFacts) {
      if (legacyWithholds?.(originalContent)) return false;
      const retained = preparedEvidence[index];
      let evidence = retained;
      if (refreshKey) {
        const current = await fingerprintMemoryPassages(originalContent, message.content, refreshKey);
        // Spelling order is independent of the key. Reuse the retained evidence for each spelling.
        evidence = current.map((passage, position) => {
          const { digests, retainedShingles } = retained[position];
          return { ...passage, digests: [...passage.digests, ...digests.filter(digest => digest.label !== undefined)],
            retainedShingles };
        });
      }
      return !withholdsAnyPassage(evidence, textFacts);
    }
    return !legacyKeyUnavailable && (!message.content ||
      !await matches(originalContent, message.content, refreshKey ?? preparedKey));
  }));
  return positions.filter((_, index) => allowed[index]);
}

/** @param {AbortSignal | undefined} signal @param {CaptureDeadline} [deadline] */
function checkCaptureAbort(signal, deadline) {
  deadline?.check();
  if (signal?.aborted) throw new CoreError("model_cancelled");
}

/** @param {AbortSignal | undefined} caller @param {CaptureDeadline} deadline */
function captureTransport(caller, deadline) {
  checkCaptureAbort(caller, deadline);
  const timeout = AbortSignal.timeout(deadline.remainingMs());
  const signal = caller ? AbortSignal.any([caller, timeout]) : timeout;
  function check() {
    if (timeout.aborted && signal.reason === timeout.reason) throw new CoreError("model_timeout");
    checkCaptureAbort(caller, deadline);
  }
  return { signal, check };
}

/** @template T @param {AbortSignal} signal @param {Promise<T>} pending */
async function untilAborted(signal, pending) {
  let onAbort = () => {};
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(signal.reason);
    if (signal.aborted) onAbort();
    else signal.addEventListener("abort", onAbort, { once: true });
  });
  try { return await Promise.race([pending, aborted]); }
  finally { signal.removeEventListener("abort", onAbort); }
}

/**
 * @param {unknown} raw
 * @param {{sourceCount: number, itemLimit: number}} policy
 * @param {CallOptions["onDiagnostic"]} diagnostics
 * @param {NonNullable<ReturnType<typeof captureDocumentSteps>>["validateExtraction"]} [validate]
 */
function hostedCandidates(raw, policy, diagnostics, validate) {
  let output;
  try {
    output = structuredClone(raw);
    const serialized = JSON.stringify(output);
    if (typeof serialized !== "string" || serialized.length > MAX_EXTRACT_OUTPUT_UNITS) {
      throw new CoreError("invalid_model_output");
    }
  } catch {
    emitDiagnostic(diagnostics, "extract", "core_call", "output_bounds");
    throw new CoreError("invalid_model_output");
  }
  try {
    // Hosted openai.ts:101–109 checks distinct, non-empty, in-range indices.
    // Hosted ingest.ts:122–125 and index.ts:37 apply the inclusive confidence floor.
    const validated = (validate ?? validatePlainCandidates)(output, policy);
    const { items } = /** @type {{items: Array<{content: string}>}} */ (output);
    return validated
      .map((candidate, index) => ({ ...candidate, rawContent: items[index].content }))
      .filter(candidate => candidate.confidence >= 0.5);
  } catch (error) {
    const { code } = /** @type {{code: string}} */ (error);
    emitDiagnostic(diagnostics, "extract", "core_validation", code);
    throw new CoreError("invalid_model_output");
  }
}

/**
 * @param {ReturnType<typeof hostedCandidates>} candidates
 * @param {readonly CaptureMessage[]} messages
 * @param {CaptureKey} key
 * @param {FingerprintKey} fingerprintKey
 * @param {Deps["clock"]} clock
 * @param {readonly RetainedDigester[] | undefined} digesters
 */
function prepareCaptureCandidates(candidates, messages, { client, sessionId }, fingerprintKey, clock, digesters) {
  return Promise.all(candidates.map(async candidate => {
    const { rawContent: raw, kind, confidence } = candidate;
    const content = prepareCoreText(raw);
    if (!content || content === "[REDACTED]" || content.length > 600) throw new CoreError("invalid_model_output");
    const { query: { textHash, digests }, passages } =
      await prepareWriteText(raw, content, fingerprintKey, text => clock.sha256Hex(text), digesters);
    const receipts = candidate.sourceIndices.map(index => {
      const { id: messageId, role, occurredAtMs } = messages[index];
      return { client, sessionId, messageId, role, occurredAtMs };
    });
    return { item: { content, kind, confidence, textHash, ...(digests && { digests }), receipts }, raw, passages };
  }));
}

/** @typedef {Awaited<ReturnType<typeof prepareCaptureCandidates>>[number]} PreparedCandidate */
/**
 * @template {PreparedCandidate} T
 * @param {T[]} candidates
 * @param {SuppressionSnapshot} snapshot
 * @param {CaptureKey["scope"]} scope
 * @param {Set<string>} excludedSources
 */
function filterCaptureCandidates(candidates, snapshot, scope, excludedSources) {
  if (snapshot.blockedSession !== false || snapshot.blockedMessages.length) throw new CoreError("suppressed");
  const facts = snapshot.passages.map(({ fact }) => fact);
  if (facts.some(fact => fact?.owner !== scope.owner || (fact.namespace ?? null) !== scope.namespace)) {
    throw new CoreError("internal_error");
  }
  const legacyWithholds = legacyPassageMatcher(scope, facts);
  return candidates.filter(candidate => {
    if (!legacyWithholds?.(candidate.raw) && !withholdsAnyPassage(candidate.passages, facts)) return true;
    for (const { messageId } of candidate.item.receipts) excludedSources.add(messageId);
    return false;
  });
}

/**
 * @param {PreparedCandidate[]} prepared
 * @param {CaptureKey["scope"]["owner"]} owner
 * @param {Deps} deps
 * @param {CaptureDeadline} deadline
 * @param {AbortSignal | undefined} caller
 */
async function embedCaptureCandidates(prepared, owner, { storage, gate, embedder }, deadline, caller) {
  if (prepared.length === 0) return [];
  if (embedder === null) throw new CoreError("capability_unavailable");
  const texts = prepared.map(({ item }) => normalizeForHash(item.content));
  const { model, dimensions } = embedder;
  const { signal, check } = captureTransport(caller, deadline);
  /** @type {Float32Array[]} */
  let vectors;
  await gate.assertOpen(owner, "dispatch");
  try {
    check();
    vectors = await untilAborted(signal, embedder.embed(texts, { signal }));
  } catch (error) {
    check();
    throw error;
  }
  check();

  return prepared.map(({ item, raw, passages }, index) => {
    const vector = Array.isArray(vectors) && vectors.length <= prepared.length ? vectors[index] : undefined;
    const embedding = validWriteEmbedding(vector, dimensions) ? { model, vector } : null;
    if (storage.capabilities.embeddingRequiredOnInsert && embedding === null) throw new CoreError("embedding_failed");
    return { item: { ...item, embedding }, raw, passages };
  });
}

/**
 * @param {import("./entry.mjs").HookedDeps} deps
 * @returns {Pick<import("../ports/host.d.ts").MemoryService, "enqueueCapture" | "captureStatus"> & import("./index.d.mts").CaptureRunner}
 */
export function captureMethods(deps) {
  const { storage, clock, model, gate, config, diagnostics, embedder, hooks } = deps;
  const { uow, pause, suppressions, capture, sessionLineage, raw, keys, capabilities } = storage;
  const documents = captureDocumentSteps(deps, untilAborted, captureTransport, checkCaptureAbort);
  const rawOnly = model === null && config.rawCapture?.enabled === true && documents === undefined;
  const captureUnavailable = rawOnly
    ? capabilities.rawArchive !== true || typeof raw?.archive !== "function" || typeof capture?.admit !== "function"
    : documents?.captureUnavailable ?? (model === null || embedder === null);
  /** @param {Tx} tx @param {SuppressionSnapshot["passages"]} passages */
  const sourceWriteKey = (tx, passages) =>
    capabilities.fingerprintKey && passages.length && keys.userKeyForWrite ? keys.userKeyForWrite(tx) : null;
  return {
    enqueueCapture: entry(async (inputScope, input) => {
      const scope = scopeOf(inputScope);
      const admit = capture?.admit;
      if (captureUnavailable || typeof admit !== "function") throw new CoreError("capability_unavailable");
      const { client: inputClient, sessionId: inputSession, eventId: inputEvent, messages } =
        validateObject(input, ["client", "sessionId", "eventId", "messages"]);
      const client = identifier(inputClient);
      const sessionId = identifier(inputSession);
      const eventId = identifier(inputEvent);
      const incoming = validateDenseArray(messages, 1, 24).map(prepareMessage);
      const prepared = incoming.map(({ message }) => message);
      if (new Set(prepared.map(message => message.id)).size !== prepared.length) {
        throw new CoreError("invalid_input");
      }
      // Keep the established digest canonicalization for redelivery of existing admissions.
      const payloadDigest = await clock.sha256Hex(JSON.stringify([client, sessionId, eventId,
        prepared.map(({ id, role, content, occurredAtMs }) => [id, role, content.replace(/\s+/gu, " ").trim(), occurredAtMs])]));
      const key = { scope, client, sessionId, eventId, payloadDigest };
      const preparedKey = capabilities.fingerprintKey && !keys.userKeyForWrite ? await keys.userKey(scope.owner) : null;
      const digesters = await keys?.retainedDigesters?.(scope.owner);
      const preparedEvidence = await retainedSourceEvidence(incoming, preparedKey, digesters);
      return uow.run(scope.owner, { pauseLock: true }, async tx => {
        if (pauseResult(await pause.get(tx, scope.owner)).paused) return { status: "paused" };
        const session = { client, sessionId };
        const { blockedSession, passages } = await suppressions.snapshot(tx, scope, session);
        if (blockedSession === true) return { status: "blocked" };
        if (blockedSession !== false) throw new CoreError("internal_error");
        if (capabilities.sessionLineage) {
          if (typeof sessionLineage?.isFenced !== "function") throw new CoreError("capability_unavailable");
          const { fenced } = await sessionLineage.isFenced(tx, scope, session);
          if (fenced === true) return { status: "blocked" };
          if (fenced !== false) throw new CoreError("internal_error");
        }
        const positions = await capture.eligible(tx, key, prepared);
        if (!Array.isArray(positions) ||
            positions.some(position => !Number.isInteger(position) || position < 0 || position >= prepared.length)) {
          throw new CoreError("internal_error");
        }
        const allowed = new Set(await filterScopedCaptureSources(scope, incoming, [...new Set(positions)], passages, preparedKey,
          preparedEvidence, await sourceWriteKey(tx, passages)));
        const admitted = prepared.map((message, index) => allowed.has(index) ? message : { ...message, content: "" });
        const { status } = await admit.call(capture, tx, key, admitted);
        switch (status) {
          case "duplicate": case "processing": case "rawReplay":
            return { status: "duplicate" };
          case "admitted":
            if (capabilities.rawArchive) {
              if (typeof raw?.recordLineage !== "function") throw new CoreError("capability_unavailable");
              await raw.recordLineage(tx, key, admitted);
            }
            return { status: "accepted" };
          default:
            throw new CoreError("internal_error");
        }
      });
    }),
    captureStatus: entry(async (inputScope, inputEvent, options) => {
      const scope = scopeOf(inputScope);
      const readStatus = capture?.status;
      if (typeof readStatus !== "function") throw new CoreError("capability_unavailable");
      const eventId = identifier(inputEvent);
      const { client } = options === undefined ? {} : validateObject(options, ["client"]);
      const selectedClient = client === undefined ? undefined : identifier(client);
      return uow.run(scope.owner, { readOnly: true }, async tx => {
        const result = await readStatus.call(capture, tx, scope, eventId, selectedClient);
        if (result == null) return { status: "unknown" };
        const { status } = result;
        switch (status) {
          case "pending": case "done": case "unknown":
            return { status };
          case "failed": {
            const code = result.code;
            return code === undefined ? { status } : { status, code: isErrorCode(code) ? code : "internal_error" };
          }
          default:
            throw new CoreError("internal_error");
        }
      });
    }),
    runCapture: entry(async (inputScope, input, options) => {
      const scope = scopeOf(inputScope);
      const filterCaptureSources = filterScopedCaptureSources.bind(null, scope);
      const { owner } = scope;
      const { client: inputClient, sessionId: inputSession, eventId: inputEvent } =
        validateObject(input, ["client", "sessionId", "eventId"]);
      const client = identifier(inputClient);
      const sessionId = identifier(inputSession);
      const eventId = identifier(inputEvent);
      const load = capture?.load;
      const readStatus = capture?.status;
      const archive = capabilities.rawArchive ? raw : undefined;
      if (captureUnavailable || typeof load !== "function" || typeof readStatus !== "function" ||
          [capture.claim, capture.beginDispatch, capture.finish, capture.abandon, capture.eligible, capture.assertEligible,
            suppressions?.snapshot, storage.keys?.userKey].some(method => typeof method !== "function") ||
          (capabilities.rawArchive && (typeof archive?.archiveAllowed !== "function" || typeof archive.archive !== "function"))) {
        throw new CoreError("capability_unavailable");
      }
      const readLedgerStatus = readStatus.bind(capture);
      const lock = { pauseLock: true };
      /** @param {Tx} tx */
      const readAdmission = tx => load.call(capture, tx, { scope, client, sessionId, eventId });
      /** @param {Tx} tx */
      const readPause = async tx => pauseResult(await pause.get(tx, owner));
      /** @param {Tx} tx @param {CaptureKey} key @param {readonly CaptureMessage[]} messages */
      const readEligible = async (tx, key, messages) => {
        const eligible = await capture.eligible(tx, key, messages);
        const positions = /** @type {number[]} */ (validateDenseArray(eligible, 0, messages.length));
        if (new Set(positions).size !== positions.length ||
            positions.some(position => !Number.isSafeInteger(position) || position < 0 || position >= messages.length)) {
          throw new CoreError("internal_error");
        }
        return positions;
      };
      const preflight = await uow.run(owner, lock, readPause);
      if (preflight.paused) return { status: "paused" };

      // Status has no FinishResult. A later invocation can obtain it by rawReplay.
      async function resolveUnknownCommit() {
        let failureCode = "commit_outcome_unknown";
        try {
          const result = await uow.run(owner, { readOnly: true }, tx => readLedgerStatus(tx, scope, eventId, client));
          if (result?.status === "failed" && isErrorCode(result.code)) failureCode = result.code;
        } catch { /* Keep the ambiguous outcome when the ledger cannot be read. */ }
        return /** @type {const} */ ({ status: "failed", code: failureCode });
      }

      let claimed;
      try {
        claimed = await uow.run(owner, lock, async tx => {
          if ((await readPause(tx)).paused) return /** @type {const} */ ({ status: "paused" });
          const admission = await readAdmission(tx);
          if (admission === null) return /** @type {const} */ ({ status: "failed", code: "not_found" });
          const { key, messages } = admission;
          if (key?.scope?.owner !== owner || key.scope.namespace !== scope.namespace ||
              key.client !== client || key.sessionId !== sessionId || key.eventId !== eventId) {
            return /** @type {const} */ ({ status: "failed", code: "internal_error" });
          }
          const claim = await capture.claim(tx, key, messages, { leaseMs: config.leaseMs ?? DEFAULT_LEASE_MS });
          switch (claim.status) {
            case "rawReplay": return /** @type {const} */ ({ status: "done", result: claim.result });
            case "duplicate": case "processing": return { status: claim.status };
            case "claimed": {
              const positions = await readEligible(tx, key, messages);
              return { ...claim, key, positions: positions.filter(position => messages[position].content !== ""),
                admittedMessages: messages };
            }
            default: throw new CoreError("internal_error");
          }
        });
      } catch (error) {
        const failure = entryError(error);
        if (failure.code === "commit_outcome_unknown") return resolveUnknownCommit();
        throw failure;
      }
      if (claimed.status !== "claimed") return claimed;
      const { key, admittedMessages } = claimed;
      let { token, positions } = claimed;

      /** @param {Tx} tx */
      async function readCurrentMessages(tx) {
        const current = await readAdmission(tx);
        return current?.key.payloadDigest === key.payloadDigest ? current.messages : [];
      }

      /** @param {CaptureMessage[]} current @param {number} position */
      function sourceUnchanged(current, position) {
        const content = current[position]?.content;
        // Erasure preserves the slot and blanks its content. Compare the stored text verbatim.
        return !!content && content === admittedMessages[position].content;
      }

      /** @param {Tx} tx @param {number[]} positions */
      async function unchangedPositions(tx, positions) {
        const current = await readCurrentMessages(tx);
        return positions.filter(position => sourceUnchanged(current, position));
      }

      /** @param {Tx} tx */
      async function pauseChanged(tx) {
        const state = await readPause(tx);
        return state.paused || state.generation !== preflight.generation;
      }

      async function assertSendGeneration() {
        // Releasing the pause lock before the transport gate leaves a window for a pause
        // and resume between this committed read and the gate's open check.
        if (await uow.run(owner, lock, pauseChanged)) throw new CoreError("capture_paused");
      }

      /** @template T @param {(tx: Tx) => Promise<T>} work @param {boolean} [abandonOnPause] */
      function runAtGeneration(work, abandonOnPause = true) {
        return uow.run(owner, lock, async tx => {
          if (!await pauseChanged(tx)) return work(tx);
          if (abandonOnPause) await capture.abandon(tx, token, { code: "capture_paused", retryable: false });
          return null;
        });
      }

      /** @param {Tx} tx */
      async function abandonKeyMismatch(tx) {
        await capture.abandon(tx, token, { code: "fingerprint_key_mismatch", retryable: true });
        return /** @type {const} */ ({ status: "failed", code: "fingerprint_key_mismatch" });
      }

      /** @param {Tx} tx */
      const selectWriteKey = tx => keys.userKeyForWrite ? keys.userKeyForWrite(tx) : keys.userKey(owner);

      /** @type {Set<string>} */
      const excludedSources = new Set();
      /** @type {WeakMap<import("../ports/index.d.ts").FinishResult, readonly import("../ports/index.d.ts").HostCaptureWrite[]> | undefined} */
      const hookWrites = hooks ? new WeakMap() : undefined;
      /** @param {Tx} tx @param {readonly FinishItem[]} items */
      async function finish(tx, items) {
        // Snapshot the message IDs that identify admitted source positions before handing items to the adapter.
        const itemSourceIds = items.map(({ receipts }) => receipts.map(({ messageId }) => messageId));
        if (hooks) await hooks.port.beginCapture(tx, key);
        const result = await capture.finish(tx, token, items);
        const { suppressedItems } = result;
        if (suppressedItems !== undefined) {
          if (!Array.isArray(suppressedItems) || suppressedItems.length > itemSourceIds.length) {
            throw new CoreError("internal_error");
          }
          const seen = new Set();
          for (let index = 0; index < suppressedItems.length; index++) {
            const position = suppressedItems[index];
            if (!Object.hasOwn(suppressedItems, index) || !Number.isInteger(position) ||
                position < 0 || position >= itemSourceIds.length || seen.has(position)) {
              throw new CoreError("internal_error");
            }
            seen.add(position);
          }
          for (const position of seen) {
            for (const messageId of itemSourceIds[position]) excludedSources.add(messageId);
          }
        }
        if (hooks && hookWrites) hookWrites.set(result, await hooks.port.captureWrites(tx, key, result));
        return result;
      }

      /** @param {Tx} tx @param {import("../ports/index.d.ts").FinishResult} result
       * @param {readonly number[]} positions */
      async function finishHook(tx, result, positions) {
        if (!hooks || !hookWrites) return;
        const writes = hookWrites.get(result);
        if (!writes) throw new CoreError("internal_error");
        /** @type {Map<string, number>} */
        const revisions = new Map();
        for (const { memory: { id } } of writes) {
          if (revisions.has(id)) continue;
          const row = await storage.memories.readRevision?.(tx, scope, id);
          if (!row) throw new CoreError("internal_error");
          revisions.set(id, row.revision);
        }
        const sources = positions.flatMap(position => {
          const { id, role, occurredAtMs } = admittedMessages[position];
          return excludedSources.has(id) ? [] : [{ position, client, sessionId, messageId: id, role, occurredAtMs }];
        });
        const verified = archive && sources.length ? await hooks.port.captureSources(tx, key, sources, admittedMessages) : sources;
        await hooks.invoke("onCaptureFinish", tx, { scope, client, sessionId, eventId, sources: verified,
          writes: writes.map(write => ({
            ...write, memory: { id: write.memory.id, revision: revisions.get(write.memory.id) ?? write.memory.revision },
          })),
        }, writeHookResult);
        const indexRevision = await storage.memories.committedIndexRevision?.(tx);
        if (indexRevision === undefined) throw new CoreError("internal_error");
        await hooks.port.finalizeCapture(tx, key, result, indexRevision);
      }

      let retryableExtraction = false;
      /** @type {((positions: number[], checkDeadline: boolean) => Promise<
       * {status: "done", result: Awaited<ReturnType<typeof finish>>} |
       * Awaited<ReturnType<typeof abandonKeyMismatch>> | null>) | undefined} */
      let finishRaw;
      try {
        if (positions.length === 0) {
          const result = await runAtGeneration(hooks ? async tx => {
            const finished = await finish(tx, []);
            await finishHook(tx, finished, []);
            return finished;
          } : tx => finish(tx, []));
          return result === null ? { status: "paused" } : { status: "done", result };
        }

        // The outbox retains only the prepared text. Use it to derive the available historical spellings.
        const sources = admittedMessages.map(message => ({ message, originalContent: message.content }));
        // Retained signers omit the current Core key. Bind their evidence to that key's generation.
        const sourceKey = capabilities.fingerprintKey ? await keys.userKey(owner) : undefined;
        const digesters = await keys.retainedDigesters?.(owner);
        const sourceEvidence = await retainedSourceEvidence(sources, null, digesters);
        /** @param {Tx} tx @param {number[]} selected */
        const readSourcePassages = async (tx, selected) => {
          const { blockedSession, blockedMessages, passages } = await suppressions.snapshot(tx, scope, {
            client, sessionId, occurredAtMs: selected.map(position => admittedMessages[position].occurredAtMs),
          });
          if (blockedSession !== false || blockedMessages.length) throw new CoreError("suppressed");
          return passages;
        };
        finishRaw = (positions, checkDeadline) => {
          if (!archive) throw new CoreError("capability_unavailable");
          const deadline = checkDeadline ? createCaptureDeadline(config.deadlines?.extract ?? DEFAULT_EXTRACT_MS, clock)
            : undefined;
          return runAtGeneration(async tx => {
            checkCaptureAbort(options?.signal, deadline);
            const stillCurrent = await unchangedPositions(tx, positions);
            await capture.assertEligible(tx, key, stillCurrent);
            const sourcePassages = await readSourcePassages(tx, stillCurrent);
            let currentSourceKey = null;
            if (capabilities.fingerprintKey && sourcePassages.length) {
              currentSourceKey = await selectWriteKey(tx);
              if (sourceKey !== undefined && currentSourceKey?.id !== sourceKey?.id) {
                if (checkDeadline) return abandonKeyMismatch(tx);
                throw new CoreError("fingerprint_key_mismatch");
              }
            }
            const allowedPositions = await filterCaptureSources(sources, stillCurrent, sourcePassages,
              null, sourceEvidence, currentSourceKey);
            if (!checkDeadline) checkCaptureAbort(options?.signal);
            const result = await finish(tx, []);
            const rawMessages = allowedPositions.map(position => admittedMessages[position])
              .filter(({ id }) => !excludedSources.has(id));
            if (rawMessages.length && await archive.archiveAllowed(tx, key) === true) {
              await archive.archive(tx, key, rawMessages);
            }
            if (!checkDeadline) checkCaptureAbort(options?.signal);
            if (hooks) await finishHook(tx, result, allowedPositions);
            return { status: "done", result };
          }, checkDeadline);
        };
        /** @param {Tx} tx @param {number[]} requestedPositions */
        async function screenSourcePositions(tx, requestedPositions) {
          const positions = await unchangedPositions(tx, requestedPositions);
          if (!positions.length) return positions;
          const passages = await readSourcePassages(tx, positions);
          const writeKey = capabilities.fingerprintKey && passages.length ? await selectWriteKey(tx) : null;
          if (passages.length && sourceKey !== undefined && writeKey?.id !== sourceKey?.id) return null;
          const allowed = await filterCaptureSources(sources, positions, passages, null, sourceEvidence, writeKey);
          await capture.assertEligible(tx, key, allowed);
          return allowed;
        }
        const supplemental = documents?.forCapture({ key, messages: admittedMessages, excludedSources, sourceKey,
          readSourcePassages, selectWriteKey, unchangedPositions,
          filterSources: (positions, passages, writeKey) =>
            filterCaptureSources(sources, positions, passages, null, sourceEvidence, writeKey),
          abandonKeyMismatch, readEligible, runAtGeneration, finish, finishHook: hooks ? finishHook : undefined, assertSendGeneration,
          generation: preflight.generation, signal: options?.signal });
        /** @type {{request: ModelRequest, messages: CaptureMessage[], policy: {sourceCount: number, itemLimit: number}} | undefined} */
        let extraction;
        for (;;) {
          const dispatch = await runAtGeneration(async tx => {
            const allowed = await screenSourcePositions(tx, positions);
            if (allowed === null) return abandonKeyMismatch(tx);
            if (!allowed.length) {
              const result = await finish(tx, []);
              if (hooks) await finishHook(tx, result, []);
              return { result };
            }
            if (extraction && allowed.length === positions.length) return capture.beginDispatch(tx, token);
            return { allowed };
          });
          if (dispatch === null) return { status: "paused" };
          if ("status" in dispatch) return dispatch;
          if ("result" in dispatch) return { status: "done", result: dispatch.result };
          if ("token" in dispatch) {
            token = dispatch.token;
            break;
          }

          // Size only screened text, outside the lock. The next check can only shrink the batch.
          positions = dispatch.allowed;
          if (supplemental && documents?.skipExtraction) return await supplemental.finishWithoutExtraction(positions,
            createCaptureDeadline(config.deadlines?.extract ?? DEFAULT_EXTRACT_MS, clock));
          if (rawOnly) {
            const completed = await finishRaw(positions, true);
            return completed === null ? { status: "paused" } : completed;
          }
          if (model === null) throw new CoreError("capability_unavailable");
          const messages = positions.map(position => admittedMessages[position]);
          const { system, input, schema } = (documents?.extractionSpec ?? plainExtractionSpec)(messages);
          const inputTokens = countTokens(model, modelRequestText(system, input, HOSTED_EXTRACT_OUTPUT_TOKENS));
          const maxOutputTokens = Math.min(HOSTED_EXTRACT_OUTPUT_TOKENS,
            model.contextWindow - inputTokens - EXTRACT_FRAMING_TOKENS);
          if (maxOutputTokens < MODEL_OUTPUT_TOKENS) throw new CoreError("context_budget_exceeded");
          const { properties } = /** @type {{properties: {items: {maxItems: number}}}} */ (schema);
          extraction = { messages, request: { system, input, schema, schemaName: "extract_memories", maxOutputTokens },
            policy: { sourceCount: messages.length, itemLimit: properties.items.maxItems } };
        }
        if (!extraction || model === null) throw new CoreError("internal_error");
        const { request, messages, policy } = extraction;
        const signal = options?.signal;
        const deadline = createCaptureDeadline(config.deadlines?.extract ?? DEFAULT_EXTRACT_MS, clock);
        await gate.assertOpen(owner, "pre-send");
        const transport = captureTransport(signal, deadline);
        /** @type {CallOptions} */
        const portOptions = {
          signal: transport.signal,
          onDiagnostic: diagnostics && (event => emitDiagnostic(diagnostics, event.stage, event.layer, event.reason)),
        };
        await assertSendGeneration();
        // Recheck the positions bound to the request before the dispatch gate.
        // As with callBuiltModel, a hide can still commit while the gate is pending.
        // The finish-time source recheck keeps withheld evidence out of storage.
        transport.check();
        try {
          await untilAborted(transport.signal, uow.run(owner, lock, async tx => {
            if (await pauseChanged(tx)) throw new CoreError("capture_paused");
            const allowed = await screenSourcePositions(tx, positions);
            if (allowed?.length !== positions.length) throw new CoreError("ingest_inputs_changed");
          }));
        } catch (error) {
          transport.check();
          const failure = entryError(error);
          if (failure.code === "suppressed") throw new CoreError("ingest_inputs_changed");
          throw failure;
        }
        await gate.assertOpen(owner, "dispatch");
        let output;
        try {
          transport.check();
          output = await untilAborted(transport.signal, model.call("extract", request, portOptions));
        } catch (error) {
          transport.check();
          const failure = entryError(error);
          if (failure.code === "model_timeout" || failure.code === "model_cancelled" ||
              failure.code === "context_budget_exceeded" || failure.code === "token_count_unavailable" ||
              failure.code === "invalid_model_output") throw failure;
          retryableExtraction = failure.kind === "retryable";
          emitDiagnostic(diagnostics, "extract", "core_call", "provider_failure");
          throw new CoreError("extraction_failed");
        } finally {
          await gate.assertOpen(owner, "post-send");
        }
        transport.check();
        const candidates = hostedCandidates(output, policy, diagnostics, documents?.validateExtraction);
        const fingerprintKey = candidates.length ? await keys.userKey(owner) : null;
        const prepared = await prepareCaptureCandidates(candidates, messages, key, fingerprintKey, clock, digesters);
        supplemental?.trackQuantities(candidates, prepared);
        /** @param {Tx} tx @param {PreparedCandidate[]} batch */
        const readFacts = (tx, batch) => suppressions.snapshot(tx, scope, {
          client, sessionId, passages: batch.flatMap(candidate => candidate.passages),
        });
        const preEmbed = await runAtGeneration(async tx => {
          const eligible = new Set(await readEligible(tx, key, admittedMessages));
          const current = await readCurrentMessages(tx);
          const stillEligible = positions.filter(position => eligible.has(position) && sourceUnchanged(current, position));
          const eligibleIds = new Set(stillEligible.map(position => admittedMessages[position].id));
          if (prepared.length && keys.userKeyForWrite && (await keys.userKeyForWrite(tx))?.id !== fingerprintKey?.id) {
            return abandonKeyMismatch(tx);
          }
          const allowedByPassage = prepared.length
            ? filterCaptureCandidates(prepared, await readFacts(tx, prepared), scope, excludedSources) : prepared;
          const survivors = allowedByPassage.filter(({ item }) =>
            item.receipts.every(({ messageId }) => eligibleIds.has(messageId)));
          return { stillEligible, survivors };
        });
        if (preEmbed === null) return { status: "paused" };
        if ("status" in preEmbed) return preEmbed;
        const embedded = await embedCaptureCandidates(preEmbed.survivors, owner, deps, deadline, signal);
        if (supplemental) {
          const embeddingStopped = await supplemental.embed(deadline, preEmbed.stillEligible);
          if (embeddingStopped) return embeddingStopped;
        }

        const completed = await runAtGeneration(async tx => {
          checkCaptureAbort(signal, deadline);
          const stillCurrent = await unchangedPositions(tx, preEmbed.stillEligible);
          await capture.assertEligible(tx, key, stillCurrent);
          let writeKey;
          if (prepared.length && keys.userKeyForWrite) {
            writeKey = await keys.userKeyForWrite(tx);
            if (writeKey?.id !== fingerprintKey?.id) return abandonKeyMismatch(tx);
          }
          const snapshot = await readFacts(tx, embedded);
          if (prepared.length && !keys.userKeyForWrite) {
            writeKey = await keys.userKey(owner);
            if (writeKey?.id !== fingerprintKey?.id) return abandonKeyMismatch(tx);
          }
          const allowedCandidates = filterCaptureCandidates(embedded, snapshot, scope, excludedSources);

          // Source checks need the same unprojected text facts as admission.
          const sourcePassages = await readSourcePassages(tx, stillCurrent);
          let currentSourceKey = null;
          if (capabilities.fingerprintKey && sourcePassages.length) {
            currentSourceKey = writeKey === undefined ? await selectWriteKey(tx) : writeKey;
            if (sourceKey !== undefined && currentSourceKey?.id !== sourceKey?.id) return abandonKeyMismatch(tx);
          }
          const allowedPositions = await filterCaptureSources(sources, stillCurrent, sourcePassages,
            null, sourceEvidence, currentSourceKey);
          // Every allowed position passed sourceUnchanged, so its admitted copy equals the stored content.
          const allowedMessages = allowedPositions.map(position => admittedMessages[position]);
          const allowedIds = new Set(allowedMessages.map(({ id }) => id));
          const items = allowedCandidates.map(({ item }) => item).filter(({ receipts }) =>
            receipts.every(({ messageId }) => allowedIds.has(messageId)));
          checkCaptureAbort(signal, deadline);
          const result = await finish(tx, items);
          const rawMessages = allowedMessages.filter(({ id }) => !excludedSources.has(id));
          if (archive && rawMessages.length && await archive.archiveAllowed(tx, key) === true) {
            await archive.archive(tx, key, rawMessages);
            if (supplemental) await supplemental.finishDocuments(tx, rawMessages, items, result);
          } else if (!archive && supplemental) await supplemental.finishDocuments(tx, rawMessages, items, result);
          if (hooks) await finishHook(tx, result, allowedPositions);
          return /** @type {const} */ ({ status: "done", result, withheld: prepared.length - items.length });
        });
        if (completed === null) return { status: "paused" };
        if (completed.status === "failed") return completed;
        for (let i = 0; i < completed.withheld; i++) emitDiagnostic(diagnostics, "extract", "core_finish", "candidate_withheld");
        if (supplemental) await supplemental.afterCommit();
        return { status: "done", result: completed.result };
      } catch (error) {
        let failure = entryError(error);
        let hookFailure = isHostWriteHookFailure(error);
        if (failure.code === "commit_outcome_unknown") return resolveUnknownCommit();
        if (config.rawCapture?.onModelFailure === true && RAW_FALLBACK_FAILURE_CODES.has(failure.code) &&
            !options?.signal?.aborted) {
          try {
            const completed = await finishRaw?.(positions, false);
            if (completed?.status === "done") return { ...completed, code: failure.code };
          } catch (fallbackError) {
            const fallback = entryError(fallbackError);
            if (fallback.code === "commit_outcome_unknown") return resolveUnknownCommit();
            if (isHostWriteHookFailure(fallbackError)) {
              failure = fallback;
              hookFailure = true;
            }
            // Other fallback failures abandon with the original capture failure.
          }
        }
        let paused = failure.kind === "paused";
        try {
          await uow.run(owner, lock, async tx => {
            if (!hookFailure) paused = await pauseChanged(tx) || paused;
            await capture.abandon(tx, token, paused ? { code: "capture_paused", retryable: false }
              : { code: failure.code, retryable: failure.kind === "retryable" ||
                  (failure.code === "extraction_failed" && retryableExtraction) });
          });
        } catch (cleanupError) {
          if (!hookFailure && entryError(cleanupError).code === "commit_outcome_unknown") return resolveUnknownCommit();
          // A stale or failed cleanup must not replace the original outcome or release a successor.
        }
        return paused ? { status: "paused" } : { status: "failed", code: failure.code };
      }
    }, undefined, ([scope, selection, options]) => {
      // AbortSignal is a live cancellation capability. Snapshot the input data once and
      // derive a signal that follows it without relying on properties on the caller's object.
      const input = detach(/** @type {const} */ ([scope, selection]), "invalid_input");
      if (options === undefined) return [...input, undefined];
      const fields = validateObject(options, ["signal"]);
      const signal = Object.hasOwn(fields, "signal") ? fields.signal : undefined;
      try {
        return [...input, { signal: signal === undefined ? undefined : AbortSignal.any([/** @type {AbortSignal} */ (signal)]) }];
      } catch { throw new CoreError("invalid_input"); }
    }),
  };
}
