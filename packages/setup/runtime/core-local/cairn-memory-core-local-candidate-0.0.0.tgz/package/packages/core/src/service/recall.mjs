import { emitDiagnostic } from "../capture/model-call.mjs";
import { validateObject } from "../capture/validate.mjs";
import { FUSION_PRESETS } from "../decisions.mjs";
import { CoreError } from "../errors.mjs";
import { normalizeForHash, prepareCoreText } from "../privacy/text.mjs";
import { canonicalKey } from "../retrieval/bm25.mjs";
import { fuseHosted, fuseHostedLexicalOnly } from "../retrieval/fusion.mjs";
import { encodeCursor, pageLimit } from "../retrieval/hosted-paging.mjs";
import { entry, scopeOf } from "./entry.mjs";
import { hydrateMemoryRows, prepareRecentPage, readCursor, readSet, readStateToken } from "./reads.mjs";

/** @typedef {import("../ports/common.d.ts").ItemRef} ItemRef */
/** @typedef {import("../ports/common.d.ts").MemoryRow} MemoryRow */
/** @typedef {import("../ports/unit-of-work.d.ts").Tx} Tx */

/** @param {import("../ports/retrieval.d.ts").EmbedQuery} embedQuery
 * @param {string} owner @param {string} query @param {import("../ports/common.d.ts").CallOptions} [options] */
export function embedRecallQuery(embedQuery, owner, query, options) {
  return embedQuery.embedQuery(owner, normalizeForHash(query), { ...options, budgetClass: "recall" });
}

/** @param {import("./index.d.mts").MemoryServiceDeps} deps */
export function recallMethod(deps) {
  const search = recallSearch(deps);
  return entry(async (input, raw, options) => {
    const scope = scopeOf(input);
    if (typeof raw !== "string") throw new CoreError("invalid_input");
    const query = prepareCoreText(raw);
    const { cursor, limit: requestedLimit, mode } = validateObject(options, ["cursor", "limit", "mode"]);
    if (requestedLimit !== undefined && typeof requestedLimit !== "number") throw new CoreError("invalid_input");
    if (mode !== "search" && mode !== "plugin") throw new CoreError("invalid_input");
    const limit = pageLimit(requestedLimit);
    return search(scope, query, { cursor, limit, mode });
  });
}

/** @param {import("./index.d.mts").MemoryServiceDeps} deps */
export function recallSearch(deps) {
  const prepare = prepareRecallSearch(deps);
  /** @type {(...args: Parameters<typeof prepare>) => Promise<{items: MemoryRow[], nextCursor: string | null, scores: number[]}>} */
  return async (scope, ...args) => {
    const { deliver, nextCursor } = await prepare(scope, ...args);
    const { items, scores } = deliver
      ? await deps.storage.uow.run(scope.owner, { readOnly: true }, deliver)
      : { items: [], scores: [] };
    return { items, nextCursor, scores };
  };
}

/** @param {import("./index.d.mts").MemoryServiceDeps} deps
 * @param {boolean} [stablePaging] Use a fixed search order for Find continuations.
 */
export function prepareRecallSearch({ storage, embedQuery, gate, diagnostics, clock }, stablePaging = false) {
  const { uow, snapshot, lexical, vector, capabilities, hydrate, fence } = storage;
  /**
   * @param {import("../ports/common.d.ts").Scope} scope
   * @param {string} query Prepared by the service entry.
   * @param {{ cursor: unknown; limit: number; mode: "search" | "plugin" }} options
   * @param {Pick<import("../ports/retrieval.d.ts").RetrievalScope, "clients" | "window">} [filters] Used by Find.
   */
  return async (scope, query, { cursor, limit, mode }, filters) => {
    // Refuse an unsupported search before any dependency call, as the other placeholders do.
    if (query && (!lexical || !hydrate)) throw new CoreError("capability_unavailable");
    const route = stablePaging && query ? "find-memory-v1" : "recall-v2";
    const binding = [route, scope.owner, scope.namespace, await clock.sha256Hex(query), mode, limit];

    if (!query) {
      const position = readCursor(cursor, binding, 1);
      const [inner] = position ?? [];
      if (position && (typeof inner !== "string" || !inner)) throw new CoreError("cursor_stale");
      const result = await prepareRecentPage(storage, scope, { cursor: inner ?? null, limit }, filters);
      return {
        nextCursor: result.nextCursor === null ? null : encodeCursor([...binding, result.nextCursor]),
        /** @param {Tx} tx */
        async deliver(tx) {
          const items = await result.deliver(tx);
          return { items, scores: items.map(() => 0) };
        },
      };
    }

    const position = readCursor(cursor, binding, 3);
    const [positionToken, offset = 0, positionPath] = position ?? [];
    if (position && (typeof positionToken !== "string" || !positionToken || !Number.isSafeInteger(position[1]) ||
        offset < 0 || offset > Number.MAX_SAFE_INTEGER - limit - 1 ||
        (positionPath !== "hybrid" && positionPath !== "lexical"))) {
      throw new CoreError("cursor_stale");
    }
    if (!lexical || !hydrate) throw new CoreError("capability_unavailable");

    let embedding = null;
    // Why this request ranks lexical-only. A declared difference from hosted, whose hybrid search fails instead.
    /** @type {string | null} */
    let fallback = null;
    if (positionPath !== "lexical") {
      if (!embedQuery || capabilities.semanticRetrieval !== true || !vector) {
        fallback = "semantic_unavailable";
      } else {
        // Hosted search itself has no pause check (index.ts:65–83,119–133).
        // A closed send gate or failed query embed leaves lexical search available on the first page.
        try {
          await gate.assertOpen(scope.owner, "dispatch");
        } catch {
          fallback = "dispatch_closed";
        }
        if (!fallback) {
          try {
            embedding = await embedRecallQuery(embedQuery, scope.owner, query);
          } catch {
            embedding = null;
          }
          if (!embedding) fallback = "embed_failed";
        }
      }
    }
    if (positionPath === "hybrid" && !embedding) throw new CoreError("cursor_stale");

    const readScope = readSet(scope, filters);
    const hostedPool = FUSION_PRESETS.hosted.pool;
    // Fetch enough lexical rows for the hybrid pool and for lexical fallback, including lookahead.
    const lexicalWindow = offset + limit + 1;
    const lexicalDepth = Math.max(embedding ? hostedPool : 0, lexicalWindow);
    /** @param {ItemRef} ref */
    const isScopedMemory = ref => ref.type === "memory" && ref.namespace === scope.namespace;

    const { rows, nextCursor, memories, path } = await uow.run(scope.owner, { readOnly: true }, async tx => {
      const token = await readStateToken(snapshot, tx, readScope, positionToken);
      const words = stablePaging ? null : await lexical.lexical(tx, readScope, query, lexicalDepth, {});
      const semantic = embedding && vector
        ? await vector.vector(tx, readScope, embedding.vector, embedding.model, hostedPool)
        : null;
      const complete = semantic?.coverage.complete === true;
      if (positionPath === "hybrid" && !complete) throw new CoreError("cursor_stale");
      const path = complete ? "hybrid" : "lexical";
      // A growing lexical prefix can promote a tie over a previously delivered
      // row. Find pages the fixed hybrid pool or the full lexical ordering.
      const candidates = words
        ? (!complete && lexicalDepth > lexicalWindow ? words.rows.slice(0, lexicalWindow) : words.rows)
        : (await lexical.lexical(tx, readScope, query, complete ? hostedPool : Number.MAX_SAFE_INTEGER, {})).rows;
      const lexicalRows = candidates.filter(row => isScopedMemory(row.ref));
      const page = { offset, limit, floor: mode === "plugin" };
      const { rows, total } = complete
        ? fuseHosted(lexicalRows, semantic.rows.filter(row => isScopedMemory(row.ref)), page)
        : fuseHostedLexicalOnly(lexicalRows, page);
      const nextOffset = offset + limit;
      const nextCursor = nextOffset < total ? encodeCursor([...binding, token, nextOffset, path]) : null;
      const memories = await hydrateMemoryRows(hydrate, tx, readScope, rows.map(row => row.ref), "recall");
      return { rows, nextCursor, memories, path };
    });
    // One content-free event per first page that ranks lexical-only. Continuations on a lexical cursor
    // were already counted, and a hybrid continuation that loses semantics is cursor_stale instead.
    if (positionPath === undefined && path === "lexical") {
      emitDiagnostic(diagnostics, "recall", "core_retrieval", fallback ?? "coverage_incomplete");
    }

    if (!rows.length) return { nextCursor };
    // Rehydrate beside the fence in the caller's delivery snapshot. A correction can keep the
    // same ref visible while changing the content ranked by the previous run.
    /** @param {Tx} tx */
    async function deliver(tx) {
      const refs = rows.map(row => row.ref);
      const current = await hydrateMemoryRows(hydrate, tx, readScope, refs, "recall");
      const visible = new Set((await fence.assertVisible(tx, readScope, refs)).map(canonicalKey));
      /** @type {MemoryRow[]} */
      const items = [];
      /** @type {number[]} */
      const scores = [];
      for (const { ref, score } of rows) {
        const key = canonicalKey(ref);
        const memory = current.get(key);
        if (memory && memory.revision === memories.get(key)?.revision && visible.has(key)) {
          items.push(memory);
          scores.push(score);
        }
      }
      return { items, scores };
    }
    return { nextCursor, deliver };
  };
}
