import { CoreError } from "../errors.mjs";
import { planDigest, renderDigest } from "../ledger/digest.mjs";
import { ledgerRowDeliverable, ledgerRowInRange, ledgerRowKey, parseWindow, readIntent } from "../ledger/index.mjs";
import { weekStart, yearStart } from "../ledger/window.mjs";
import { documentCardAmendmentVisible, selectVisibleAmendmentsForRead } from "../routing/amendment-read.mjs";
import { compareUtf8 } from "../utf8.mjs";
import { assertContextVisible, contextCardVerdict, hasContextCardLoader, legacyContextCard, qualifyEvidence } from "./context-read-evidence.mjs";
import { canonicalGenerations, checkRow, evidenceFence, fetchResponseBytes, snapshotRefs } from "./context-read-fetch.mjs";
import { COMPACT_MEMORY_REPRESENTATION, FETCH_RESPONSE_MAX_BYTES, itemRef, namespaceSlot, readSetBinding } from "./context-read-input.mjs";
import { readTokenSigner } from "./context-read-tokens.mjs";

/** @import { ContextEvidenceRow, ContextLedgerDigest, ContextLedgerErrorStage, ContextMemoryRef, ContextRawTurn, ContextReadRef,
  ContextReadSelection, ContextReadSet, ContextReadStore, DocumentCardAmendment, MemoryStore, QuantityLedgerRow,
  QuantityLedgerStore, ReadContractStorage, StoredDocumentCardRecord, Tx, VisibilityFence } from "../ports/index.d.ts" */
/** @import { LedgerMemoryState, LedgerReadState } from "../ledger/index.mjs" */
/** @import { LedgerLine, LedgerPlan } from "../ledger/digest.mjs" */
/** @typedef {Awaited<ReturnType<ContextReadStore["snapshotState"]>>} Generations */
/** @typedef {ReturnType<typeof readTokenSigner>} Signer */

/** @typedef {Pick<DocumentCardAmendment, "date" | "sentence" | "quote">} ReadAmendment */
/** @typedef {{ query: string, asOfMs: number, calendarReading: boolean }} LedgerRequest */
/** @typedef {{ keys: readonly string[], trimmed: boolean }} LedgerSelection */
/** @typedef {{ value: ContextLedgerDigest, witness: () => string }} LedgerProjection */
/** @typedef {{ lines: LedgerLine[], project: (lines: readonly LedgerLine[], trimmed: boolean) => LedgerProjection }} LedgerReading */
/** @typedef {{ selected: readonly AssemblyEvidence[], rawTurns: readonly ContextRawTurn[],
 * current: boolean }} OrdinaryFence */
/** @typedef {{ active: () => void, onError: (stage: ContextLedgerErrorStage) => void,
 * onScan: () => void, ordinary: OrdinaryFence }} LedgerAttempt */
/** @typedef {LedgerAttempt & { witness: string, calendar: boolean, selection: LedgerSelection }} LedgerCheck */

const MIN_EVENT_MS = -8_640_000_000_000_000;
export const staleLedger = new Error("stale quantity ledger");

/** @param {ContextReadStore} store @param {Pick<MemoryStore, "readRevision">} memories @param {QuantityLedgerStore} ledger
 * @param {VisibilityFence} fence @param {Tx} tx @param {Signer} signer @param {ContextReadSet} readSet
 * @param {LedgerRequest} request @param {LedgerAttempt} attempt @param {boolean} includeCalendar
 * @param {LedgerCheck} [check] */
async function readLedgerDigest(store, memories, ledger, fence, tx, signer, readSet, { query, asOfMs, calendarReading }, { active, onError, onScan }, includeCalendar, check) {
  /** @type {ContextLedgerErrorStage} */
  let stage = "scan";
  try {
    const range = parseWindow(query, asOfMs);
    const start = Math.min(range.fromMs, weekStart(range.toMs - 1), yearStart(range.toMs - 1));
    const earlier = { fromMs: MIN_EVENT_MS, toMs: range.fromMs };
    /** @type {QuantityLedgerRow[]} */
    const checked = [];
    /** @type {Map<string, ContextEvidenceRow & { type: "memory" }>} */
    const sourceRows = new Map();
    for (const namespace of readSet.namespaces) {
      active();
      const scope = { owner: readSet.owner, namespace };
      stage = "terms";
      const terms = await ledger.terms(tx, scope);
      active();
      if (!readIntent(query, terms)) continue;
      active();
      stage = "scan";
      const inWindow = await ledger.list(tx, scope, { fromMs: range.fromMs, toMs: range.toMs });
      active();
      const beforeWindow = await ledger.list(tx, scope, earlier);
      active();
      onScan();
      const rows = [...inWindow.filter(row => ledgerRowInRange(row, range)),
        ...beforeWindow.filter(row => ledgerRowInRange(row, earlier) && (row.kind === "goal" || row.date >= start))];
      stage = "evidence";
      /** @type {ContextMemoryRef[]} */
      const refs = [];
      const memoryTextHashes = new Map();
      for (const id of new Set(rows.map(row => row.memoryId))) {
        active();
        const current = await memories.readRevision(tx, scope, id);
        if (!current) continue;
        refs.push({ type: "memory", scope, id, revision: current.revision });
        memoryTextHashes.set(id, current.textHash);
      }
      if (!refs.length) continue;
      active();
      const evidence = structuredClone(await store.evidence(tx, readSet, refs, "current"));
      active();
      const visible = await fence.assertVisible(tx, { owner: readSet.owner, namespaces: [namespace] }, refs.map(itemRef));
      active();
      const visibleIds = new Set(visible.flatMap(ref =>
        ref.type === "memory" && ref.namespace === namespace ? [ref.id] : []));
      /** @type {Map<string, LedgerMemoryState>} */
      const memoryStates = new Map();
      const retainedReceipts = new Map();
      const ns = namespaceSlot(readSet, scope);
      const scopedId = (/** @type {string} */ id) => JSON.stringify([ns, id]);
      for (const [i, ref] of refs.entries()) {
        const row = evidence[i];
        if (row?.type !== "memory" || checkRow(ref, row) || !visibleIds.has(ref.id) ||
            row.metadata.state !== "active" || row.sourceAccess !== "available") continue;
        memoryStates.set(ref.id, "current_visible");
        retainedReceipts.set(ref.id, new Set(row.receipts.slice(0, 16)
          .filter(receipt => receipt.role === "user").map(receipt => receipt.id)));
        sourceRows.set(scopedId(ref.id), row);
      }
      /** @type {LedgerReadState} */
      const state = { memoryStates, retainedReceipts, memoryTextHashes };
      const deliverable = rows.filter(row => ledgerRowDeliverable(row, state));
      // Earlier records support calendar goals but cannot trigger a digest on their own.
      if (!readIntent(query, deliverable.flatMap(row => row.kind === "goal" || ledgerRowInRange(row, range)
        ? [row.measure, row.group, row.category] : []))) continue;
      const ordered = deliverable.map(row => ({ row, key: JSON.stringify([ns, ledgerRowKey(row), row.group, row.date, row.textHash]) }))
        .sort((a, b) => compareUtf8(a.key, b.key));
      for (const { row } of ordered) {
        active();
        checked.push({ ...row, memoryId: scopedId(row.memoryId) });
      }
    }
    active();
    const records = checked.filter(row => row.kind === "record");
    const goals = checked.filter(row => row.kind === "goal");
    /** @type {Map<string, { memory: ContextLedgerDigest["sources"][number]["memory"], mac: string }>} */
    const qualified = new Map();
    /** @param {LedgerPlan | null} plan @param {LedgerSelection} [selection] @returns {Promise<LedgerReading | null>} */
    async function seal(plan, selection) {
      if (!plan) return null;
      const keys = selection && new Set(selection.keys);
      const lines = keys ? plan.lines.filter(line => keys.has(line.key)) : plan.lines;
      if (keys && keys.size !== lines.length) return null;
      const sourceIds = new Set(lines.flatMap(line => line.rows.map(row => row.memoryId)));
      for (const id of sourceIds) {
        active();
        if (!qualified.has(id)) {
          const row = sourceRows.get(id);
          if (!row) throw new Error("missing ledger source evidence");
          const evidence = await qualifyEvidence(row, signer);
          active();
          const mac = await evidenceFence(signer, evidence, row, false);
          const { scope, id: memoryId, revision } = row.ref;
          qualified.set(id, { mac, memory: { ns: namespaceSlot(readSet, scope), type: "memory",
            id: memoryId, rev: revision, f: mac.slice(0, 8) } });
        }
      }
      active();
      const sealedPlan = plan;
      return { lines, project(selected, trimmed) {
        const { body, sources, rows } = renderDigest(sealedPlan, selected, trimmed);
        const evidence = sources.map(id => /** @type {NonNullable<ReturnType<typeof qualified.get>>} */ (qualified.get(id)));
        const value = { body, sources: evidence.map(({ memory }, index) => ({ index, role: /** @type {const} */ ("user"), memory })) };
        return { value, witness: () => {
          const rowKeys = rows.map(row => JSON.stringify([ledgerRowKey(row), row.group, row.date, row.textHash])).sort(compareUtf8);
          return JSON.stringify([value, rowKeys, evidence.map(source => source.mac)]);
        } };
      } };
    }
    stage = "seal";
    if (check) {
      const rolling = await seal(planDigest(records, goals, range, check.calendar, query), check.selection);
      return rolling && { rolling, calendar: null };
    }
    const rolling = await seal(planDigest(records, goals, range, false, query));
    if (!rolling) return null;
    const comparison = calendarReading && range.calendar && includeCalendar
      ? await seal(planDigest(records, goals, range, true, query)).catch(() => { active(); onError(stage); return null; }) : null;
    return { rolling, calendar: comparison };
  } catch {
    active();
    onError(stage);
    return null;
  }
}

/** @param {ContextEvidenceRow} row @param {Signer} signer @param {boolean} lineageEnabled
 * @param {readonly ReadAmendment[]} amendments @param {boolean} documentCard */
async function qualifyForAssembly(row, signer, lineageEnabled, amendments, documentCard) {
  const item = await qualifyEvidence(row, signer);
  const receipts = row.type === "memory" && item.type === "memory" && item.provenance.sourceAccess === "available"
    ? item.provenance.sources.map(source => row.receipts.find(receipt => receipt.id === source.receiptId))
    : [];
  const sources = receipts.flatMap(receipt => receipt ? [receipt] : []);
  // Keep the public fetch fence replayable. The assembly-only witness also
  // protects the event times and lineage carried by those qualified receipts.
  return { item, sources, amendments, documentCard, fence: await evidenceFence(signer, item, row, lineageEnabled),
    witness: JSON.stringify(sources.map(({ id, occurredAtMs, sourceTimesMs, rawTurns }) =>
      [id, occurredAtMs, sourceTimesMs, rawTurns])) + JSON.stringify(amendments) };
}

/** @typedef {Awaited<ReturnType<typeof qualifyForAssembly>>} AssemblyEvidence */
/** @param {Pick<ReadContractStorage<StoredDocumentCardRecord>, "contextRead" | "uow" | "fence" | "documentCards" |
 * "quantityLedger"> & { memories?: Pick<MemoryStore, "readRevision"> }} storage */
export function fetchForAssembly({ contextRead: store, uow, fence, documentCards, memories, quantityLedger }) {
  const cardsEnabled = hasContextCardLoader(documentCards);
  /** @param {ContextReadSet} readSet @param {ContextReadSelection} selection @param {Generations} observed
   * @param {readonly ContextReadRef[]} refs @param {LedgerRequest} [ledgerRequest] @param {boolean} [compact] */
  return async (readSet, { intent, types }, observed, refs, ledgerRequest, compact = false) => {
    if (!store) throw new CoreError("capability_unavailable");
    const readStore = store;
    /** @param {Tx} tx @param {Signer} signer @param {LedgerAttempt} attempt
     * @param {boolean} includeCalendar @param {LedgerCheck} [check] */
    const ledgerFor = (tx, signer, attempt, includeCalendar, check) => ledgerRequest && quantityLedger && memories
      ? readLedgerDigest(readStore, memories, quantityLedger, fence, tx, signer, readSet, ledgerRequest, attempt, includeCalendar, check) : null;
    const cards = types.includes("card");
    const expected = canonicalGenerations(observed, cards);
    /** @param {Tx} tx */
    async function checkState(tx) {
      const current = canonicalGenerations(await readStore.snapshotState(tx, readSet, types), cards);
      if (expected.length !== readSet.namespaces.length || JSON.stringify(current) !== JSON.stringify(expected)) {
        throw new CoreError("snapshot_stale");
      }
    }
    /** @param {Tx} tx @param {Signer} signer @param {readonly ContextReadRef[]} requested */
    async function evidence(tx, signer, requested) {
      const rows = requested.length ? structuredClone(await readStore.evidence(tx, readSet, requested, intent)) : [];
      return Promise.all(requested.map(async (ref, i) => {
        const row = rows[i];
        if (!row || checkRow(ref, row)) return null;
        /** @type {ReadAmendment[]} */
        const amendments = [];
        const lineage = expected[namespaceSlot(readSet, ref.scope)].lineage !== undefined;
        const legacy = !cardsEnabled && legacyContextCard(row, lineage);
        const documentCard = row.type === "card" && !legacy;
        if (documentCard) {
          const cardVisibility = await contextCardVerdict(documentCards, tx, ref, row.item);
          if (!cardVisibility) return null;
          const card = readStore.documentCardAmendmentSource && documentCards
            ? await Promise.resolve().then(() => documentCards.get(tx, ref.scope, ref.id)).catch(() => null) : null;
          const stored = card?.id === ref.id && card.scope.owner === ref.scope.owner && card.scope.namespace === ref.scope.namespace
            ? card.amendments : [];
          const visible = await selectVisibleAmendmentsForRead(stored, async ({ sourceMessage, quote }) => {
            try {
              const projection = await readStore.documentCardAmendmentSource?.(tx, readSet, ref.scope, { sourceMessage, quote });
              return !!projection && documentCardAmendmentVisible({ ...projection, scope: ref.scope, cardVisibility });
            } catch {
              return false;
            }
          });
          for (const { date, sentence, quote } of visible) amendments.push({ date, sentence, quote });
        }
        return qualifyForAssembly(row, signer, lineage, amendments, documentCard);
      }));
    }
    const prepared = await uow.run(readSet.owner, { readOnly: true }, async tx => {
      await checkState(tx);
      const signer = readTokenSigner(await store.identity(tx));
      const scope = await signer.bind("snapshot-scope", readSetBinding(readSet));
      const rows = await evidence(tx, signer, refs);
      const selection = { owner: readSet.owner, namespaces: readSet.namespaces };
      const fenceRefs = cardsEnabled ? refs.filter(ref => ref.type !== "card") : refs;
      const visible = fenceRefs.length ? await fence.assertVisible(tx, selection, fenceRefs.map(itemRef),
        intent === "history" ? "read" : undefined) : [];
      return { scope, rows: rows.map((row, i) => row?.documentCard || visible.some(({ id, type, namespace }) =>
        id === refs[i].id && type === refs[i].type && namespace === refs[i].scope.namespace) ? row : null) };
    });
    /** @param {readonly AssemblyEvidence[]} selected */
    const payload = selected => ({
      v: 1, scope: prepared.scope, intent, refs: snapshotRefs(readSet, selected.map(({ item }) => item.ref)),
      generations: canonicalGenerations(expected, selected.some(({ item }) => item.type === "card")),
      access: readSet.accessGenerations, fences: selected.map(row => row.fence),
      ...(compact && { representation: COMPACT_MEMORY_REPRESENTATION }),
    });
    /** @param {Tx} tx @param {Signer} signer @param {readonly AssemblyEvidence[]} selected
     * @param {readonly ContextRawTurn[]} rawTurns */
    async function checkDelivery(tx, signer, selected, rawTurns) {
      const delivered = selected.map(({ item }) => item.ref);
      const current = await evidence(tx, signer, delivered);
      if (selected.some((row, i) => row.fence !== current[i]?.fence || row.witness !== current[i]?.witness)) {
        throw new CoreError("snapshot_stale");
      }
      await assertContextVisible(fence, tx, readSet,
        selected.flatMap(({ item, documentCard }) => documentCard ? [] : [item.ref]), intent, "snapshot_stale");
      if (!rawTurns.length) return true;
      try {
        return await readStore.raw?.revalidate(tx, readSet, rawTurns) === true;
      } catch {
        return false;
      }
    }
    /** @param {Tx} tx @param {Signer} signer @param {OrdinaryFence} ordinary */
    async function fenceOrdinary(tx, signer, ordinary) {
      try {
        ordinary.current = await checkDelivery(tx, signer, ordinary.selected, ordinary.rawTurns);
      } catch (error) {
        if (!(error instanceof CoreError) || error.code !== "snapshot_stale") throw error;
      }
    }
    return {
      rows: prepared.rows,
      payload,
      /** @param {LedgerAttempt} attempt @param {boolean} includeCalendar */
      prepareLedger(attempt, includeCalendar) {
        const { active, ordinary } = attempt;
        // The deadline can race the snapshot request before the callback starts.
        ordinary.current = false;
        return uow.run(readSet.owner, { readOnly: true }, async tx => {
          active();
          await checkState(tx);
          active();
          const signer = readTokenSigner(await readStore.identity(tx));
          active();
          if (await signer.bind("snapshot-scope", readSetBinding(readSet)) !== prepared.scope) return null;
          // Fence the ordinary response before any optional store call can
          // hold a serialized reader past the ledger deadline.
          await fenceOrdinary(tx, signer, ordinary);
          active();
          return ledgerFor(tx, signer, attempt, includeCalendar);
        });
      },
      /** @param {readonly AssemblyEvidence[]} selected @param {readonly ContextRawTurn[]} rawTurns
       * @param {AbortSignal} [signal] @param {LedgerCheck} [ledgerCheck]
       * @returns {Promise<string | null | undefined | typeof staleLedger>} Undefined indicates a stale Raw witness. */
      async deliver(selected, rawTurns, signal, ledgerCheck) {
        // Legacy context-read-facade.mjs:918–937. All final predicates share
        // this snapshot, after the host formatter and counter have finished.
        // A deadline can race this transaction, so retire the earlier fallback
        // before asking for the final snapshot.
        if (ledgerCheck) ledgerCheck.ordinary.current = false;
        return uow.run(readSet.owner, { readOnly: true }, async tx => {
          ledgerCheck?.active();
          await checkState(tx);
          ledgerCheck?.active();
          const signer = readTokenSigner(await store.identity(tx));
          if (await signer.bind("snapshot-scope", readSetBinding(readSet)) !== prepared.scope) {
            throw new CoreError("snapshot_stale");
          }
          if (!await checkDelivery(tx, signer, selected, rawTurns)) {
            if (signal?.aborted) throw new CoreError("snapshot_stale");
            return undefined;
          }
          if (ledgerCheck) {
            const { ordinary } = ledgerCheck;
            if ((rawTurns === ordinary.rawTurns || !rawTurns.length && !ordinary.rawTurns.length) &&
                selected.length === ordinary.selected.length && selected.every((row, i) => row === ordinary.selected[i])) {
              ordinary.current = true;
            } else {
              await fenceOrdinary(tx, signer, ordinary);
            }
            const current = await ledgerFor(tx, signer, ledgerCheck, false, ledgerCheck);
            const reading = current?.rolling;
            if (reading?.project(reading.lines, ledgerCheck.selection.trimmed).witness() !== ledgerCheck.witness) return staleLedger;
          }
          ledgerCheck?.active();
          let snapshot = null;
          try {
            if (selected.length) snapshot = await signer.encode("snapshot", payload(selected));
          } catch (error) {
            if (!compact || !(error instanceof CoreError) || error.code !== "context_item_too_large") throw error;
          }
          if (signal?.aborted) throw new CoreError("snapshot_stale");
          if (compact && snapshot && fetchResponseBytes(selected.map(row => row.item), snapshot) > FETCH_RESPONSE_MAX_BYTES) {
            return null;
          }
          return snapshot;
        });
      },
    };
  };
}
