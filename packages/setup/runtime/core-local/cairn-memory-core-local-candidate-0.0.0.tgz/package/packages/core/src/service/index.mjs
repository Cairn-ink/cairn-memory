import {
  assertHostWriteHookCapability, assertReadContractCapabilities, CAPABILITIES, READ_CONTRACT_CAPABILITIES, WRITE_PARITY_CAPABILITIES,
} from "../capabilities.mjs";
import { identifier, validateObject } from "../capture/validate.mjs";
import { FUSION_PRESETS, NEAR_DUPLICATE_DISTANCE } from "../decisions.mjs";
import { CoreError } from "../errors.mjs";
import { captureMethods } from "./capture.mjs";
import { fetchForAssembly } from "./context-read-assembly-evidence.mjs";
import { fetchEvidenceMethod } from "./context-read-fetch.mjs";
import { findCandidatesMethod } from "./context-read-find.mjs";
import { readContextMethod } from "./context-read.mjs";
import { findMethod, readCardMethod, readMethod } from "./find.mjs";
import { bindHostWriteHooks, entryError } from "./entry.mjs";
import { forgetMethod } from "./forget.mjs";
import { importMethod, importRawMethod } from "./import.mjs";
import { inspectMethod } from "./inspect.mjs";
import { pauseMethods } from "./pause.mjs";
import { recallMethod } from "./recall.mjs";
import { listRawMessagesMethod, readMethods } from "./reads.mjs";
import { relationJudgeMethods } from "./relations-judge.mjs";
import { writeMethods } from "./writes.mjs";

/** @param {unknown} value */
function positiveInteger(value) {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 1) {
    throw new CoreError("invalid_input");
  }
}

/** @param {import("./index.d.mts").MemoryServiceConfig["quantityLedger"]} quantityLedger */
function freezeQuantityLedger(quantityLedger) {
  if (quantityLedger === undefined) return undefined;
  const { enabled, calendarReading } = validateObject(quantityLedger, ["enabled", "calendarReading"]);
  if (typeof enabled !== "boolean" || (calendarReading !== undefined && typeof calendarReading !== "boolean")) {
    throw new CoreError("invalid_input");
  }
  return Object.freeze({ enabled, calendarReading });
}

/** @param {import("./index.d.mts").MemoryServiceConfig} input */
function freezeConfig(input) {
  const config = {
    nearDuplicateDistance: NEAR_DUPLICATE_DISTANCE,
    lexicalWeight: FUSION_PRESETS.hosted.lexicalWeight,
    vectorWeight: FUSION_PRESETS.hosted.vectorWeight,
    rowShingles: true,
  };
  validateObject(input, [
    ...Object.keys(config), "leaseMs", "deadlines", "documentCards", "quantityLedger", "rawCapture", "explicitWindowFence",
  ]);
  const {
    nearDuplicateDistance = config.nearDuplicateDistance,
    lexicalWeight = config.lexicalWeight,
    vectorWeight = config.vectorWeight,
    rowShingles = config.rowShingles,
    leaseMs,
    deadlines,
    documentCards,
    quantityLedger,
    rawCapture,
    explicitWindowFence,
  } = input;
  for (const weight of [nearDuplicateDistance, lexicalWeight, vectorWeight]) {
    if (!Number.isFinite(weight) || weight < 0) throw new CoreError("invalid_input");
  }
  if (nearDuplicateDistance > 2 || typeof rowShingles !== "boolean") throw new CoreError("invalid_input");
  if (leaseMs !== undefined) positiveInteger(leaseMs);
  if (deadlines !== undefined) {
    validateObject(deadlines, ["extract", "qualify", "reconcile", "classify", "rationale"]);
  }
  const stages = { ...deadlines };
  for (const duration of Object.values(stages)) {
    positiveInteger(duration);
    // Match the capture runner's deadline range.
    if (duration > 120_000) throw new CoreError("invalid_input");
  }
  let cards;
  if (documentCards !== undefined) {
    const { enabled, amendments } = validateObject(documentCards, ["enabled", "amendments"]);
    if (typeof enabled !== "boolean" || (amendments !== undefined && typeof amendments !== "boolean")) {
      throw new CoreError("invalid_input");
    }
    cards = Object.freeze({ enabled, amendments });
  }
  let raw;
  if (rawCapture !== undefined) {
    const fields = validateObject(rawCapture, ["enabled", "onModelFailure"]);
    // Read enabled as in the base validator, and read the fallback option only when own.
    const { enabled } = fields;
    const onModelFailure = Object.hasOwn(fields, "onModelFailure") ? fields.onModelFailure : undefined;
    const keys = Reflect.ownKeys(fields);
    if (!keys.length || keys.some(key => key !== "enabled" && key !== "onModelFailure") ||
        keys.some(key => !Object.hasOwn(fields, key))) {
      throw new CoreError("invalid_input");
    }
    const hasEnabled = keys.includes("enabled");
    const hasOnModelFailure = keys.includes("onModelFailure");
    if ((hasEnabled && typeof enabled !== "boolean") || (hasOnModelFailure && typeof onModelFailure !== "boolean")) {
      throw new CoreError("invalid_input");
    }
    raw = Object.freeze({ enabled: hasEnabled && enabled === true, onModelFailure: hasOnModelFailure && onModelFailure === true });
  }
  let windowFence;
  if (explicitWindowFence !== undefined) {
    const fields = validateObject(explicitWindowFence, ["enabled"]);
    const { enabled } = fields;
    if (Reflect.ownKeys(fields).length !== 1 || !Object.hasOwn(fields, "enabled") || typeof enabled !== "boolean") {
      throw new CoreError("invalid_input");
    }
    windowFence = Object.freeze({ enabled });
  }
  return Object.freeze({
    nearDuplicateDistance, lexicalWeight, vectorWeight, rowShingles, leaseMs,
    deadlines: Object.freeze(stages),
    documentCards: cards, quantityLedger: freezeQuantityLedger(quantityLedger), rawCapture: raw,
    explicitWindowFence: windowFence,
  });
}

/** @param {object | undefined} port @param {...string} methods */
function requireMethods(port, ...methods) {
  if (!port || typeof port !== "object" || methods.some(method => typeof Reflect.get(port, method) !== "function")) {
    throw new CoreError("invalid_input");
  }
}

/**
 * @param {import("./index.d.mts").KeylessInspectServiceDeps["storage"] &
 *   Pick<import("../ports/index.d.ts").StorageAdapter, "proceduralTags">} storage
 */
function validateReadRegistration(storage) {
  validateObject(storage.capabilities, [...CAPABILITIES, ...READ_CONTRACT_CAPABILITIES, ...WRITE_PARITY_CAPABILITIES]);
  if (Object.values(storage.capabilities).some(value => typeof value !== "boolean")) {
    throw new CoreError("invalid_input");
  }
  assertReadContractCapabilities(storage);
  if (storage.capabilities.proceduralTags === true) requireMethods(storage.proceduralTags, "write", "clear", "read");
}

/** @param {import("./index.d.mts").MemoryServiceRegistrationDeps} input */
function freezeDeps(input) {
  const deps = { ...input };
  const { storage, model: configuredModel, embedder: configuredEmbedder, gate, clock, tokens, embedQuery, diagnostics } = deps;
  identifier(storage?.name);
  validateReadRegistration(storage);
  // Validate the storage methods this slice uses. Optional ports are checked at adapter registration.
  requireMethods(storage.uow, "run");
  requireMethods(storage.pause, "get", "set");
  requireMethods(storage.snapshot, "stateToken", "assertUnchanged");
  requireMethods(storage.fence, "assertVisible");
  requireMethods(storage.recent, "recent");
  requireMethods(storage.memories, "exportPage");

  const model = configuredModel ?? null;
  if (model === null && storage.capabilities.fingerprintKey === true) throw new CoreError("invalid_input");
  if (model !== null) {
    requireMethods(model, "call", "countTokens");
    if (typeof model.model !== "string" || !model.model ||
        (model.fits !== undefined && typeof model.fits !== "function")) throw new CoreError("invalid_input");
    positiveInteger(model.contextWindow);
  }
  if (configuredEmbedder === undefined && storage.capabilities.embeddingRequiredOnInsert !== false) {
    throw new CoreError("invalid_input");
  }
  const embedder = configuredEmbedder ?? null;
  if (embedder !== null) {
    requireMethods(embedder, "embed");
    if (typeof embedder.model !== "string" || !embedder.model) throw new CoreError("invalid_input");
    positiveInteger(embedder.dimensions);
  }
  requireMethods(gate, "assertOpen");
  requireMethods(clock, "nowMs", "monotonicMs", "sha256Hex", "hmacHex");
  requireMethods(tokens, "countTokens");
  if (embedQuery !== undefined) requireMethods(embedQuery, "embedQuery");
  if (diagnostics !== undefined && typeof diagnostics !== "function") throw new CoreError("invalid_input");
  if (deps.documentCardSessionKey !== undefined && typeof deps.documentCardSessionKey !== "function") {
    throw new CoreError("invalid_input");
  }

  assertHostWriteHookCapability(storage.capabilities, storage.hostWriteHookPort);
  const hooks = bindHostWriteHooks(deps.hostWriteHooks, storage.hostWriteHookPort);
  if (hooks) requireMethods(storage.memories, "committedIndexRevision", "readRevision");
  return Object.freeze({ ...deps, model, embedder, config: freezeConfig(deps.config), hooks });
}

/** @param {import("./index.d.mts").KeylessMemoryServiceDeps["storage"] | import("./index.d.mts").MemoryServiceDeps["storage"]} storage
 * @param {import("../ports/index.d.ts").ClockAndHash} clock
 * @param {Pick<import("./index.d.mts").MemoryServiceDeps, "contextReadCounter" | "contextReadFormat" | "embedQuery"> &
 *   Partial<Pick<import("./index.d.mts").MemoryServiceDeps, "gate">>} host
 * @param {import("./index.d.mts").MemoryServiceConfig["quantityLedger"]} [quantityLedger]
 * @returns {Required<Pick<import("../ports/index.d.ts").MemoryService, "findCandidates" | "fetchEvidence" | "readContext" | "inspect">>}
 */
function readContractMethods(storage, clock, host, quantityLedger) {
  const { findCandidates, findForAssembly, startAssemblyEmbedding } =
    findCandidatesMethod({ storage, clock, embedQuery: host.embedQuery, gate: host.gate });
  return {
    findCandidates,
    fetchEvidence: fetchEvidenceMethod(storage),
    readContext: readContextMethod({ storage, clock, find: findForAssembly, startEmbedding: startAssemblyEmbedding,
      fetch: fetchForAssembly(storage),
      counter: host.contextReadCounter, format: host.contextReadFormat,
      calendarReading: quantityLedger?.enabled === true && quantityLedger.calendarReading === true }),
    inspect: inspectMethod(storage, clock),
  };
}

/**
 * @param {import("./index.d.mts").MemoryServiceRegistrationDeps | import("./index.d.mts").KeylessInspectServiceDeps |
 * import("./index.d.mts").KeylessMemoryServiceDeps} input
 */
export function createMemoryService(input) {
  try {
    if ("profile" in input && input.profile === "keyless-local") {
      const { storage, clock } = input;
      requireMethods(storage.uow, "run");
      requireMethods(clock, "hmacHex");
      validateReadRegistration(storage);
      if ("hostWriteHooks" in input) throw new CoreError("invalid_input");
      if (!storage.inspect) throw new CoreError("capability_unavailable");
      if (storage.capabilities.contextRead === true) {
        if (!("fence" in storage)) throw new CoreError("invalid_input");
        requireMethods(storage.fence, "assertVisible");
        requireMethods(clock, "nowMs", "monotonicMs");
        return readContractMethods(storage, clock, { contextReadCounter: input.contextReadCounter, contextReadFormat: input.contextReadFormat },
          freezeQuantityLedger("config" in input ? input.config?.quantityLedger : undefined));
      }
      return { inspect: inspectMethod(storage, clock) };
    }
    const deps = freezeDeps(input);
    if (deps.model !== null && deps.config.rawCapture?.enabled === true) throw new CoreError("invalid_input");
    if (deps.model === null && deps.config.rawCapture?.onModelFailure === true) throw new CoreError("invalid_input");
    return {
      ...pauseMethods(deps.storage),
      ...readMethods(deps.storage, deps.tokens),
      ...writeMethods(deps),
      ...relationJudgeMethods(deps),
      ...captureMethods(deps),
      ...readContractMethods(deps.storage, deps.clock, deps, deps.config.quantityLedger),
      forget: forgetMethod(deps),
      recall: recallMethod(deps),
      find: findMethod(deps),
      read: readMethod(deps.storage),
      readCard: readCardMethod(deps.storage),
      listRawMessages: listRawMessagesMethod(deps.storage),
      importMemories: importMethod(deps),
      importRawMessages: importRawMethod(deps),
    };
  } catch (error) {
    throw entryError(error);
  }
}
